﻿using ReyBanPac.ModeloCanonico.Type;
using Microsoft.AspNetCore.Mvc;

namespace ReyBanPac.ArchivoConsentimientoES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<Object>> Guardar(ArchivoConsentimientoType EntityType);

        public Task<ActionResult<Object>> Actualizar(ArchivoConsentimientoType EntityType);

        public Task<ActionResult<Object>> Eliminar(int Id);

        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(int Id);



    }
}
