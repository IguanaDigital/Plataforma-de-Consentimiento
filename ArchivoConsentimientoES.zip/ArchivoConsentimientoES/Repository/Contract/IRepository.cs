﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ArchivoConsentimientoES.Repository.Contract
{
    public interface IRepository
    {
        public Task<ArchivoConsentimientoModel> Guardar(ArchivoConsentimientoModel EntityModel);

        public Task<ArchivoConsentimientoModel> Actualizar(ArchivoConsentimientoModel EntityModel);

        public Task<int> Eliminar(int Id);

        public Task<List<ArchivoConsentimientoModel>> Consultar();

        public Task<ArchivoConsentimientoModel> ConsultarPorId(int Id);

        public Task<bool> ValidarExistencia(int Id);
    }
}
