﻿using ReyBanPac.ArchivoConsentimientoES.Constans;
using ReyBanPac.ArchivoConsentimientoES.Repository.Contract;
using ReyBanPac.ArchivoConsentimientoES.Repository.Context;
using ReyBanPac.ModeloCanonico.Model;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using ReyBanPac.ModeloCanonico.Constans;

namespace ReyBanPac.ArchivoConsentimientoES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            _logger = logger;
        }

        public async Task<ArchivoConsentimientoModel> Guardar(ArchivoConsentimientoModel EntityModel)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");
            try
            {
                EntityModel.Fecha_Creacion = DateTime.Now;
                var Item = db.Models.Add(EntityModel);
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<ArchivoConsentimientoModel> Actualizar(ArchivoConsentimientoModel EntityModel)
        {
            try
            {
                EntityModel.Fecha_Actualizacion = DateTime.Now;
                var Item = db.Models.Add(EntityModel);
                db.Entry(EntityModel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                var Reg = await db.Models.FindAsync(Id)?? new ArchivoConsentimientoModel();
                Reg.Estado = Estados.ELIMINADO;
                Reg.Fecha_Actualizacion = DateTime.Now;
                return await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<List<ArchivoConsentimientoModel>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await db.Models.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<ArchivoConsentimientoModel> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await db.Models.FindAsync(Id) ?? new ArchivoConsentimientoModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<bool> ValidarExistencia(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await db.Models.AnyAsync(item => item.Id == Id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

    }
}
