﻿using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ArchivoConsentimientoES.Service.Contract
{
    public interface IService
    {
        public Task<ArchivoConsentimientoType> Guardar(ArchivoConsentimientoType EntityType);

        public Task<ArchivoConsentimientoType> Actualizar(ArchivoConsentimientoType EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<ArchivoConsentimientoType>> Consultar();

        public Task<ArchivoConsentimientoType> ConsultarPorId(int Id);

    }
}
