﻿using ReyBanPac.ArchivoConsentimientoES.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ArchivoConsentimientoES.Repository.Contract;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ArchivoConsentimientoES.Service.Contract;
using ReyBanPac.ArchivoConsentimientoES.Utils;
using System.Reflection;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.ArchivoConsentimientoES.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository _repository;

        public ServiceImpl(IRepository repositorio, ILogger<ServiceImpl> logger)
        {
            _repository = repositorio;
            _logger = logger;
        }

        public async Task<ArchivoConsentimientoType> Guardar(ArchivoConsentimientoType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                ArchivoConsentimientoModel EntityModel = Converts.ConvertirTypeAModel(EntityType);
                EntityModel = await _repository.Guardar(EntityModel);
                return Converts.ConvertirModelAType(EntityModel);
            }
            catch (ServiceException Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {Ex.Message}");
                throw;
            }
            catch (Exception Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }

        public async Task<ArchivoConsentimientoType> Actualizar(ArchivoConsentimientoType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                bool Existe = await _repository.ValidarExistencia(EntityType.Id);
                if (Existe)
                {
                    ArchivoConsentimientoModel EntityModel = Converts.ConvertirTypeAModel(EntityType);
                    EntityModel = await _repository.Actualizar(EntityModel);
                    return Converts.ConvertirModelAType(EntityModel);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {Ex.Message}");
                throw;
            }
            catch (Exception Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }



        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                bool Existe = await _repository.ValidarExistencia(Id);
                if (Existe)
                {
                    return await _repository.Eliminar(Id);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {Ex.Message}");
                throw;
            }
            catch (Exception Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }



        }

        public async Task<List<ArchivoConsentimientoType>> Consultar()
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                List<ArchivoConsentimientoModel> ListadoModel = await _repository.Consultar();
                List<ArchivoConsentimientoType> ListadoType = Converts.ConvertirListModelToListType(ListadoModel);
                return ListadoType;
            }
            catch (ServiceException Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {Ex.Message}");
                throw;
            }
            catch (Exception Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }


        }

        public async Task<ArchivoConsentimientoType> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                ArchivoConsentimientoModel EntityModel = await _repository.ConsultarPorId(Id);

                return Converts.ConvertirModelAType(EntityModel);
            }
            catch (ServiceException Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {Ex.Message}");
                throw;
            }
            catch (Exception Ex)
            {
                _logger.LogError(Ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }

        }


    }
}
