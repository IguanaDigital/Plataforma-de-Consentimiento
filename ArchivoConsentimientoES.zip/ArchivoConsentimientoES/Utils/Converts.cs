﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ArchivoConsentimientoES.Utils
{
    public static class Converts
    {
        public static ArchivoConsentimientoType ConvertirModelAType(ArchivoConsentimientoModel model)
        {
            ArchivoConsentimientoType EntityType = new ArchivoConsentimientoType();

            if (model != null)
            {
                EntityType.Id = model.Id;
                EntityType.Id_Consentimiento = model.Id_Consentimiento;
                EntityType.Dir_Archivo = model.Dir_Archivo;
                EntityType.Nombre_Archivo = model.Nombre_Archivo;
                EntityType.Fecha_Transferencia = model.Fecha_Transferencia;
                EntityType.MD5 = model.MD5;
                EntityType.Estado = model.Estado;
            }

            return EntityType;
        }

        public static ArchivoConsentimientoModel ConvertirTypeAModel(ArchivoConsentimientoType entityType)
        {
            ArchivoConsentimientoModel Model = new ArchivoConsentimientoModel();
            if (entityType != null)
            {
                Model.Id = entityType.Id;
                Model.Id_Consentimiento = entityType.Id_Consentimiento;
                Model.Dir_Archivo = entityType.Dir_Archivo;
                Model.Nombre_Archivo = entityType.Nombre_Archivo;
                Model.Fecha_Transferencia = entityType.Fecha_Transferencia;
                Model.MD5 = entityType.MD5;
                Model.Estado = entityType.Estado;
            }

            return Model;
        }

        public static List<ArchivoConsentimientoType> ConvertirListModelToListType(List<ArchivoConsentimientoModel> listadoModel)
        {
            List<ArchivoConsentimientoType> ListadoType = new List<ArchivoConsentimientoType>();
            if (listadoModel != null)
            {
                foreach (ArchivoConsentimientoModel Item in listadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
