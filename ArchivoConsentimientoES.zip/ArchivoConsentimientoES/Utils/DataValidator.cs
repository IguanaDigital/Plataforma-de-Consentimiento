﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.ArchivoConsentimientoES.Utils
{
    public static class DataValidator
    {
        public static string ValidarResultadoByCreate(ArchivoConsentimientoType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al crear el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "Registro creado con id: " + EntityType.Id;
        }

        public static string ValidarResultadoByUpdate(ArchivoConsentimientoType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al actualizar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "El registro con id: " + EntityType.Id + " fue actualizado de forma exitosa";
        }

        public static string ValidarResultadoByDelete(int confirmacion)
        {
            if (confirmacion == 0)
            {
                throw new ServiceException("Error al eliminar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            else
            {
                return "Registro eliminado de forma exitosa";
            }

        }
        public static Object ValidarResultadoConsulta(List<ArchivoConsentimientoType> configuracion)
        {
            if (configuracion != null)
            {
                return configuracion;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }

        public static Object ValidarResultadoConsulta(ArchivoConsentimientoType entityType)
        {
            if (entityType != null && entityType.Id != 0)
            {
                return entityType;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }
    }
}
