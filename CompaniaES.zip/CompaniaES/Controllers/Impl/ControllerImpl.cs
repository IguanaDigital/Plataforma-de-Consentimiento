﻿using CompaniaES.Constans;
using CompaniaES.Controllers.Contract;
using CompaniaES.Service.Contract;
using CompaniaES.Utils;
using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

using Microsoft.AspNetCore.Authorization;
using System.Text.Json;

namespace CompaniaES.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
	 //[Authorize]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;

        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger)
        {
            Svc = Servicio;
            _logger = logger;
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<CompaniaType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<CompaniaType> Listado;
                Listado = await Svc.Consultar();
                return Ok(DataValidator.ValidarResultadoConsulta(Listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("{Id}")]
        [ProducesResponseType(typeof(CompaniaType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarPorId(string Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                CompaniaType EntityType;
                EntityType = await Svc.ConsultarPorId(Id);
                return Ok(DataValidator.ValidarResultadoConsulta(EntityType));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

    }
}
