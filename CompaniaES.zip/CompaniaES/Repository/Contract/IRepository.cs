﻿using ReyBanPac.ModeloCanonico.Type;

namespace CompaniaES.Repository.Contract
{
    public interface IRepository
    {
        public Task<List<CompaniaType>> Consultar();

        public Task<CompaniaType> ConsultarPorId(string Id);

    }
}
