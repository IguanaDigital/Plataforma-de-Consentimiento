﻿using CompaniaES.Constans;
using CompaniaES.Repository.Context;
using CompaniaES.Repository.Contract;
using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Type;


namespace CompaniaES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            _logger = logger;
        }


        public async Task<List<CompaniaType>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await (from c in db.Models
                              join cc in db.CompaniaCaracteristicaModel on c.Id equals cc.Id_Compania into ccl
                              from cclj in ccl.DefaultIfEmpty()
                              select new CompaniaType
                              {
                                  Id = c.Id,
                                  Nombre = c.Nombre,
                                  Logo = cclj.Logo,
                                  Color_Bg = cclj.Color_Bg,
                                  Color_Fg = cclj.Color_Fg
                              }).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<CompaniaType> ConsultarPorId(string Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await (from c in db.Models
                              join cc in db.CompaniaCaracteristicaModel on c.Id equals cc.Id_Compania into ccl
                              from cclj in ccl.DefaultIfEmpty()
                              where c.Id == Id
                              select new CompaniaType
                              {
                                  Id = c.Id,
                                  Nombre = c.Nombre,
                                  Logo = cclj.Logo,
                                  Color_Bg = cclj.Color_Bg,
                                  Color_Fg = cclj.Color_Fg
                              }).FirstOrDefaultAsync() ?? new CompaniaType();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

    }
}
