﻿using ReyBanPac.ModeloCanonico.Type;

namespace CompaniaES.Service.Contract
{
    public interface IService
    {

        public Task<List<CompaniaType>> Consultar();

        public Task<CompaniaType> ConsultarPorId(string Id);

    }
}
