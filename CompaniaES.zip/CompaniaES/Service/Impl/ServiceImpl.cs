﻿using CompaniaES.Constans;
using CompaniaES.Repository.Contract;
using CompaniaES.Service.Contract;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;


namespace CompaniaES.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository Repository;

        public ServiceImpl(IRepository repositorio, ILogger<ServiceImpl> logger)
        {
            Repository = repositorio;
            _logger = logger;
        }

        public async Task<List<CompaniaType>> Consultar()
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                return await Repository.Consultar();
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }


        }

        public async Task<CompaniaType> ConsultarPorId(string Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                return await Repository.ConsultarPorId(Id);

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }

        }


    }
}
