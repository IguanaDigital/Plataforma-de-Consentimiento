﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace CompaniaES.Utils
{
    public static class DataValidator
    {

        public static Object ValidarResultadoConsulta(List<CompaniaType> Configuracion)
        {
            if (Configuracion != null)
            {
                return Configuracion;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }

        public static Object ValidarResultadoConsulta(CompaniaType EntityType)
        {
            if (EntityType != null && !string.IsNullOrEmpty(EntityType.Id))
            {
                return EntityType;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }
    }
}
