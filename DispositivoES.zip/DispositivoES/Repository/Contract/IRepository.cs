﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.DispositivoES.Repository.Contract
{
    public interface IRepository
    {
        public Task<DispositivoModel> Guardar(DispositivoModel EntityModel);

        public Task<DispositivoModel> Actualizar(DispositivoModel EntityModel);

        public Task<int> Eliminar(int Id);

        public Task<List<DispositivoModel>> Consultar();

        public Task<DispositivoModel> ConsultarPorId(int Id);

        public Task<DispositivoModel> ConsultarPorIdentificador(string Id);

        public Task<List<DispositivoModel>> ConsultarDiponibilidadPorIdEncuesta(int Id);

        public Task<bool> ValidarExistencia(int Id);

        public Task<bool> ValidarExistencia(string Identificador);

        public Task<bool> ValidarExistenciaPermiso(int Id);


        public Task<PermisoDispositivoModel> GuardarPermiso(PermisoDispositivoModel EntityModel);

        public Task<PermisoDispositivoModel> ActualizarPermiso(PermisoDispositivoModel EntityModel);

        public Task<List<PermisoDispositivoType>> ConsultarPermiso();

        public Task<List<PermisoDispositivoType>> ConsultarPermiso(string Identificador);

        public Task<List<DetallePermisoDispositivoType>> ConsultarPermisoPorEncuestayDispositivoId(int Id_Encuesta, int Id_Dispositivo);

        public Task<int> EliminarPermiso(int Id);
    }
}
