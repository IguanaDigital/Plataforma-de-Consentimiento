﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.DispositivoES.Service.Contract
{
    public interface IService
    {
        public Task<DispositivoType> Guardar(DispositivoType EntityType);

        public Task<DispositivoType> Actualizar(DispositivoType EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<DispositivoType>> Consultar();

        public Task<DispositivoType> ConsultarPorId(int Id);

        public Task<DispositivoType> ConsultarPorIdentificador(string Id);

        public Task<List<DispositivoType>> ConsultarDiponibilidadPorIdEncuesta(int Id);

        public Task<PermisoDispositivoType> GuardarPermiso(PermisoDispositivoType EntityType);

        public Task<PermisoDispositivoType> ActualizarPermiso(PermisoDispositivoType EntityType);

        public Task<List<PermisoDispositivoType>> ConsultarPermiso();

        public Task<List<PermisoDispositivoType>> ConsultarPermiso(string Identificador);

        public Task<List<DetallePermisoDispositivoType>> ConsultarPermisoPorEncuestayDispositivoId(int Id_Encuesta, int Id_Dispositivo);

        public Task<int> EliminarPermiso(int Id);
    }
}
