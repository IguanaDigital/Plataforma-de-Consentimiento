﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.DispositivoES.Utils
{
    public static class Converts
    {
        public static DispositivoType ConvertirModelAType(DispositivoModel Model)
        {
            DispositivoType EntityType = new DispositivoType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Identificador = Model.Identificador;
                EntityType.Nombre = Model.Nombre;
                EntityType.Estado = Model.Estado;
            }

            return EntityType;
        }


        public static PermisoDispositivoType ConvertirModelAType(PermisoDispositivoModel Model)
        {
            PermisoDispositivoType EntityType = new PermisoDispositivoType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Id_Hacienda = Model.Id_Hacienda;
                EntityType.Id_Encuesta = Model.Id_Encuesta;
                EntityType.Id_Dispositivo = Model.Id_Dispositivo;
                EntityType.Estado = Model.Estado;
            }

            return EntityType;
        }


        public static DispositivoModel ConvertirTypeAModel(DispositivoType EntityType)
        {
            DispositivoModel Model = new DispositivoModel();
            if (EntityType != null)
            {
                Model.Id = EntityType.Id;
                Model.Identificador = EntityType.Identificador;
                Model.Nombre = EntityType.Nombre;
                Model.Estado = EntityType.Estado;
            }

            return Model;
        }

        public static PermisoDispositivoModel ConvertirTypeAModel(PermisoDispositivoType EntityType)
        {
            PermisoDispositivoModel Model = new PermisoDispositivoModel();
            if (EntityType != null)
            {
                Model.Id = EntityType.Id;
                Model.Id_Hacienda = EntityType.Id_Hacienda;
                Model.Id_Encuesta = EntityType.Id_Encuesta;
                Model.Id_Dispositivo = EntityType.Id_Dispositivo;
                Model.Estado = EntityType.Estado;
            }

            return Model;
        }


        public static List<DispositivoType> ConvertirListModelToListType(List<DispositivoModel> ListadoModel)
        {
            List<DispositivoType> ListadoType = new List<DispositivoType>();
            if (ListadoModel != null)
            {
                foreach (DispositivoModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }

        public static List<PermisoDispositivoType> ConvertirListModelToListType(List<PermisoDispositivoModel> ListadoModel)
        {
            List<PermisoDispositivoType> ListadoType = new List<PermisoDispositivoType>();
            if (ListadoModel != null)
            {
                foreach (PermisoDispositivoModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }


    }
}
