﻿using ReyBanPac.ModeloCanonico.Type;
using Microsoft.AspNetCore.Mvc;

namespace ReyBanPac.EncuestaES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<object>> Guardar(EncuestaType EntityType);

        public Task<ActionResult<object>> Actualizar(EncuestaType EntityType);

        public Task<ActionResult<object>> Eliminar(int Id);

        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(int Id);



    }
}
