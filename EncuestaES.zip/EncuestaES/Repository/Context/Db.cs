﻿using ReyBanPac.ModeloCanonico.Model;
using Microsoft.EntityFrameworkCore;

namespace ReyBanPac.EncuestaES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<EncuestaModel> Models => Set<EncuestaModel>();
    }
}
