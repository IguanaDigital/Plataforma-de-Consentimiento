﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.EncuestaES.Repository.Contract
{
    public interface IRepository
    {
        public Task<EncuestaModel> Guardar(EncuestaModel EntityModel);

        public Task<EncuestaModel> Actualizar(EncuestaModel EntityModel);

        public Task<int> Eliminar(int Id);

        public Task<List<EncuestaModel>> Consultar();

        public Task<EncuestaModel> ConsultarPorId(int Id);

        public Task<bool> ValidarExistencia(int Id);
    }
}
