﻿using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.EncuestaES.Service.Contract
{
    public interface IService
    {
        public Task<EncuestaType> Guardar(EncuestaType EntityType);

        public Task<EncuestaType> Actualizar(EncuestaType EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<EncuestaType>> Consultar();

        public Task<EncuestaType> ConsultarPorId(int Id);

    }
}
