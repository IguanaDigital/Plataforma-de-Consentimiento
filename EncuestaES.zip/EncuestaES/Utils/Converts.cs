﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.EncuestaES.Utils
{
    public static class Converts
    {
        public static EncuestaType ConvertirModelAType(EncuestaModel Model)
        {
            EncuestaType EntityType = new EncuestaType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Id_Plantilla = Model.Id_Plantilla;
                EntityType.Id_Tipo_Campania = Model.Id_Tipo_Campania;
                EntityType.Nombre = Model.Nombre;
                EntityType.Habilitar_NoAceptar = Model.Habilitar_NoAceptar;
                EntityType.Fecha_Inicio = Model.Fecha_Inicio;
                EntityType.Fecha_Fin = Model.Fecha_Fin;
                EntityType.Estado = Model.Estado;
                
            }

            return EntityType;
        }

        public static EncuestaModel ConvertirTypeAModel(EncuestaType EntityType)
        {
            EncuestaModel Model = new EncuestaModel();
            if (EntityType != null)
            {
                Model.Id= EntityType.Id;
                Model.Id_Plantilla = EntityType.Id_Plantilla;
                Model.Id_Tipo_Campania = EntityType.Id_Tipo_Campania;
                Model.Nombre = EntityType.Nombre;
                Model.Habilitar_NoAceptar = EntityType.Habilitar_NoAceptar;
                Model.Fecha_Inicio = EntityType.Fecha_Inicio;
                Model.Fecha_Fin = EntityType.Fecha_Fin;
                Model.Estado = EntityType.Estado;
            }

            return Model;
        }

        public static List<EncuestaType> ConvertirListModelToListType(List<EncuestaModel> ListadoModel)
        {
            List<EncuestaType> ListadoType = new List<EncuestaType>();
            if (ListadoModel != null)
            {
                foreach (EncuestaModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
