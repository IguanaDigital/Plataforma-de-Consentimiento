﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.EncuestaES.Utils
{
    public static class DataValidator
    {
        public static string ValidarResultadoByCreate(EncuestaType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al crear el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "Registro creado con id: " + EntityType.Id;
        }

        public static string ValidarResultadoByUpdate(EncuestaType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al actualizar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "El registro con id: " + EntityType.Id + " fue actualizado de forma exitosa";
        }

        public static string ValidarResultadoByDelete(int Confirmacion)
        {
            if (Confirmacion == 0)
            {
                throw new ServiceException("Error al eliminar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            else
            {
                return "Registro eliminado de forma exitosa";
            }

        }
        public static Object ValidarResultadoConsulta(List<EncuestaType> Configuracion)
        {
            if (Configuracion != null)
            {
                return Configuracion;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }

        public static Object ValidarResultadoConsulta(EncuestaType EntityType)
        {
            if (EntityType != null && EntityType.Id != 0)
            {
                return EntityType;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }
    }
}
