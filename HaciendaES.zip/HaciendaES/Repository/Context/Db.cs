﻿using ReyBanPac.ModeloCanonico.Model;
using Microsoft.EntityFrameworkCore;

namespace ReyBanPac.HaciendaES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<HaciendaModel> Models => Set<HaciendaModel>();
        public DbSet<EmpleadoHaciendaModel> EmpleadoHaciendaModels => Set<EmpleadoHaciendaModel>();

        public DbSet<PermisoDispositivoModel> PermisoDispositivoModel => Set<PermisoDispositivoModel>();
        public DbSet<EncuestaModel> EncuestaModel => Set<EncuestaModel>();
    }
}
