﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.HaciendaES.Utils
{
    public static class Converts
    {
        public static HaciendaType ConvertirModelAType(HaciendaModel Model)
        {
            HaciendaType EntityType = new HaciendaType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Nombre = Model.Nombre;
                EntityType.Aban8 = Model.Aban8 ?? 0;
                EntityType.Estado = Model.Estado;
            }

            return EntityType;
        }

        public static HaciendaModel ConvertirTypeAModel(HaciendaType EntityType)
        {
            HaciendaModel Model = new HaciendaModel();
            if (EntityType != null)
            {
                Model.Id = EntityType.Id;
                Model.Nombre = EntityType.Nombre;
                Model.Aban8 = EntityType.Aban8 ?? 0;
                Model.Estado = EntityType.Estado;
            }

            return Model;
        }

        public static List<HaciendaType> ConvertirListModelToListType(List<HaciendaModel> ListadoModel)
        {
            List<HaciendaType> ListadoType = new List<HaciendaType>();
            if (ListadoModel != null)
            {
                foreach (HaciendaModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
