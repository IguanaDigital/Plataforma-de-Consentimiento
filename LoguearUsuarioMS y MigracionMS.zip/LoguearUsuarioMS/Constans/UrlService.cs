﻿namespace ReyBanPac.LoguearUsuarioMS.Constans
{
    public class UrlService
    {
        public string CONSULTAR_PERMISO_DISPOSITIVO { get; set; } = string.Empty;
        public string CONSULTAR_KEY { get; set; } = string.Empty;

        public string CONSULTAR_PARAMETRO { get; set; } = string.Empty;

        public string CONSULTAR_PERMISO { get; set; } = string.Empty;

        public string CONSULTAR_PERMISO_MENU { get; set; } = string.Empty;

        public string CONSULTAR_PERMISO_MENU_LOGIN { get; set; } = string.Empty;

    }
}
