﻿
using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.LoguearUsuarioMS.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<SessionType>> Login(LoguearUsuarioType EntityType);

    }
}
