﻿using ReyBanPac.ModeloCanonico.Type;
using System.Text.Json.Serialization;

namespace ReyBanPac.LoguearUsuarioMS.Controllers.Dto
{
    public class SessionWebType : SessionType
    {
        [JsonPropertyName("permiso")]
        public List<PermisoMenuType>? Permiso { set; get; }

        [JsonPropertyName("menu")]
        public List<MenuItemType>? Menu { set; get; }


        public SessionWebType() {

            Menu = null;
            Permiso = null;
        }
    }
}
