using Microsoft.OpenApi.Models;
using ReyBanPac.LoguearUsuarioMS.Constans;
using ReyBanPac.LoguearUsuarioMS.Controllers.Contract;
using ReyBanPac.LoguearUsuarioMS.Controllers.Impl;
using ReyBanPac.LoguearUsuarioMS.Service.Command;
using ReyBanPac.LoguearUsuarioMS.Service.Contract;
using ReyBanPac.LoguearUsuarioMS.Service.Impl;
using ReyBanPac.LoguearUsuarioMS.Utils;

var builder = WebApplication.CreateBuilder(args);

#region Cors

// Configurar la politica CORS con la configuracion cargada
builder.Services.AddCors(options =>
{
    options.AddPolicy("NUXT", builder =>
    {
        builder.AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader();
    });
});
#endregion
#region Logger File

var DirLogs = builder.Configuration.GetSection("Parametros:DirLogs").Value;
builder.Logging.AddFile($"{DirLogs}Logs_{General.Nombre_Servicio}{General.Tipo_Servicio}-{{Date}}.txt");

#endregion

// Add services to the container.
builder.Services.AddScoped<IController, ControllerImpl>();
builder.Services.AddScoped<IService, ServiceImpl>();
builder.Services.AddSingleton<Provider>();
builder.Services.AddTransient<ConsultarPermisoDispositivoCommand>();
builder.Services.AddTransient<ConsultarParametroCommand>();
builder.Services.AddTransient<ConsultarKeyCommand>();
builder.Services.AddTransient<GenerarTokenCommand>();
builder.Services.AddTransient<ConsultarPermisoCommand>();
builder.Services.AddTransient<ConsultarPermisoMenuCommand>();
builder.Services.AddTransient<ConsultarPermisoMenuLoginCommand>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = General.Nombre_Servicio + "-" + General.Tipo_Servicio, Version = "v1" });

});

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("v1/swagger.json", General.Nombre_Servicio + "-" + General.Tipo_Servicio + " v1");
});


app.UseCors("NUXT");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
