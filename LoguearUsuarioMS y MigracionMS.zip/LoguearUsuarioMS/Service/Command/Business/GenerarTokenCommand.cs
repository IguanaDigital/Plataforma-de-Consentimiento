﻿using Microsoft.IdentityModel.Tokens;
using ReyBanPac.LoguearUsuarioMS.Constans;
using ReyBanPac.LoguearUsuarioMS.Utils;
using ReyBanPac.ModeloCanonico.Type;
using System.IdentityModel.Tokens.Jwt;

using System.Security.Claims;
using System.Text;

namespace ReyBanPac.LoguearUsuarioMS.Service.Command
{
    public class GenerarTokenCommand
    {
        private readonly IConfiguration _config;
        private readonly ILogger<GenerarTokenCommand> _logger;
        private readonly Provider Provider;
        public GenerarTokenCommand(IConfiguration config, 
                                    Provider _provider, 
                                    ILogger<GenerarTokenCommand> logger)
        {
            _config = config;
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(LoguearUsuarioType User, int Minutos)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Command");
            try
            {

                #region Generar Token

                var claims = new[]
                {
                    new Claim(ClaimTypes.Name,User.Usuario)
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_config["Jwt:Secret"]);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(claims),
                    Expires = DateTime.UtcNow.AddMinutes(Minutos),
                    Issuer = _config["Jwt:Issuer"],
                    Audience = _config["Jwt:Audience"],
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);
                return  tokenHandler.WriteToken(token);

                #endregion

            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Servicio no disponible para consultar token");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Command");
            }
        }
    }
}
