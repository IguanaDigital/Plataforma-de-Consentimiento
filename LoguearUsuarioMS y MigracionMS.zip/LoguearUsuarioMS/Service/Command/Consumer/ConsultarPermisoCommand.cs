﻿using ReyBanPac.LoguearUsuarioMS.Constans;
using ReyBanPac.LoguearUsuarioMS.Utils;

using System.Text;

namespace ReyBanPac.LoguearUsuarioMS.Service.Command
{
    public class ConsultarPermisoCommand
    {
        private readonly ILogger<ConsultarPermisoCommand> _logger;
        private readonly Provider Provider;
        public ConsultarPermisoCommand(Provider _provider, ILogger<ConsultarPermisoCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string Usuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Command");
            try
            {

                using (var client = new HttpClient(ModeloCanonico.Utils.Utils.OffSSLClient()))
                {
                    client.Timeout = TimeSpan.FromMinutes(5);
                    var Content = new StringContent("{}", Encoding.UTF8, "application/json");
                    var Url = string.Concat(Provider.HostApi, Provider.Api.CONSULTAR_PERMISO.Replace("{Usuario}", Usuario));

                    var Response = await client.PostAsync(Url, Content);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Servicio no disponible para consultar token");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Command");
            }
        }
    }
}
