﻿
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.LoguearUsuarioMS.Service.Contract
{
    public interface IService
    {
        public Task<SessionType> Login(LoguearUsuarioType EntityType, bool Canal);


    }
}
