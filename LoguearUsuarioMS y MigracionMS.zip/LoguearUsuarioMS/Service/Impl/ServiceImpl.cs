﻿using ReyBanPac.LoguearUsuarioMS.Constans;
using ReyBanPac.LoguearUsuarioMS.Controllers.Dto;
using ReyBanPac.LoguearUsuarioMS.Service.Command;
using ReyBanPac.LoguearUsuarioMS.Service.Contract;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

using System.Security.Claims;
using System.Text;
using System.Text.Json;

namespace ReyBanPac.LoguearUsuarioMS.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly ConsultarPermisoDispositivoCommand _consultarPermisoDispositivoCommand;
        private readonly ConsultarParametroCommand _consultarParametroCommand;
        private readonly ConsultarKeyCommand _consultarKeyCommand;
        private readonly GenerarTokenCommand _generarTokenCommand;
        private readonly ConsultarPermisoMenuCommand _consultarPermisoMenuCommand;
        private readonly ConsultarPermisoCommand _consultarPermisoCommand;

        private readonly ConsultarPermisoMenuLoginCommand _consultarPermisoMenuLoginCommand;



        public ServiceImpl(ILogger<ServiceImpl> logger,
                            ConsultarPermisoDispositivoCommand consultarPermisoDispositivoCommand,
                            ConsultarParametroCommand consultarParametroCommand,
                            ConsultarKeyCommand consultarKeyCommand,
                            GenerarTokenCommand generarTokenCommand,
                            ConsultarPermisoMenuCommand consultarPermisoMenuCommand,
                            ConsultarPermisoCommand consultarPermisoCommand,
                            ConsultarPermisoMenuLoginCommand consultarPermisoMenuLoginCommand
                            )
        {
            _logger = logger;
            _consultarPermisoDispositivoCommand = consultarPermisoDispositivoCommand;
            _consultarParametroCommand = consultarParametroCommand;
            _consultarKeyCommand = consultarKeyCommand;
            _generarTokenCommand = generarTokenCommand;
            _consultarPermisoMenuCommand = consultarPermisoMenuCommand;
            _consultarPermisoCommand = consultarPermisoCommand;
            _consultarPermisoMenuLoginCommand = consultarPermisoMenuLoginCommand;
        }

        public async Task<SessionType> Login(LoguearUsuarioType EntityType, bool Canal)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {

                #region Consultar Permisos

                //Declara Variables
                List<PermisoDispositivoType> PermisoDispositivo = new List<PermisoDispositivoType>();

                if (!string.IsNullOrEmpty(EntityType.Identificador))
                {
                    try
                    {

                        //Consumir servicio para obtener la informacion de configuracion SFTP
                        string JsonPermisoDispositivo = await _consultarPermisoDispositivoCommand.ExecuteAsync(EntityType.Identificador);

                        //Mapping 
                        PermisoDispositivo = JsonSerializer.Deserialize<List<PermisoDispositivoType>>(JsonPermisoDispositivo);

                        //Valida
                        if (PermisoDispositivo == null || PermisoDispositivo.Count == 0)
                        {
                            throw new ServiceException("Dispositivo no tiene Permisos")
                            { Codigo = StatusCodes.Status400BadRequest };
                        }

                        //Solo Activos
                        PermisoDispositivo = PermisoDispositivo.Where(x => x.Estado == Estados.ACTIVO).ToList();

                    }
                    catch (ServiceException ex) //Error personalizado
                    {
                        _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                        throw;
                    }
                }

                #endregion

                #region Consultar Key
                //Declara Variables
                CredencialType CredencialType = new CredencialType();
                if (!string.IsNullOrEmpty(EntityType.Identificador))
                {
                    try
                    {

                        //Consumir servicio para obtener el key
                        string JsonKey = await _consultarKeyCommand.ExecuteAsync();

                        //Mapping 
                        CredencialType = JsonSerializer.Deserialize<CredencialType>(JsonKey);

                        //Valida
                        if (CredencialType == null || string.IsNullOrEmpty(CredencialType.Pass))
                        {
                            throw new ServiceException("No hay Key") { Codigo = StatusCodes.Status400BadRequest };
                        }


                    }
                    catch (ServiceException ex) //Error personalizado
                    {
                        _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                        throw;
                    }
                }

                #endregion

                #region Consultar Time Session

                //Declara Variables
                ParametroType Parametro = new ParametroType();


                try
                {

                    //Consumir servicio para obtener la informacion
                    string JsonParametro = await _consultarParametroCommand.ExecuteAsync();

                    //Mapping 
                    Parametro = JsonSerializer.Deserialize<ParametroType>(JsonParametro);

                    //Valida
                    if (Parametro == null || string.IsNullOrEmpty(Parametro.Valor))
                    {
                        throw new ServiceException("No tiene limite de sesion") { Codigo = StatusCodes.Status400BadRequest };
                    }

                }
                catch (ServiceException ex) //Error personalizado
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                    throw;
                }


                #endregion

                #region Generar Token

                //Declara Variables


                string Token = string.Empty;
                try
                {

                    //Consumir servicio para obtener la informacion de configuracion SFTP
                    Token = await _generarTokenCommand.ExecuteAsync(EntityType, int.Parse(Parametro.Valor));


                    //Valida
                    if (string.IsNullOrEmpty(Token))
                    {
                        throw new ServiceException("No se genero el Token") { Codigo = StatusCodes.Status400BadRequest };
                    }

                }
                catch (ServiceException ex) //Error personalizado
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                    throw;
                }


                #endregion



                #region Consultar Permisos Menu

                ////Declara Variables
                //List<MenuItemType> MenuItemType = new List<MenuItemType>();

                //if (Canal)
                //{
                //    try
                //    {

                //        //Consumir servicio para obtener la informacion de configuracion SFTP
                //        string JsonPermisoPerfil = await _consultarPermisoMenuCommand.ExecuteAsync(EntityType.Usuario);

                //        //Mapping 
                //        MenuItemType = JsonSerializer.Deserialize<List<MenuItemType>>(JsonPermisoPerfil);

                //        //Valida
                //        if (MenuItemType == null || MenuItemType.Count == 0)
                //        {
                //            throw new ServiceException("Dispositivo no tiene Permisos")
                //            { Codigo = StatusCodes.Status400BadRequest };
                //        }


                //    }
                //    catch (ServiceException ex) //Error personalizado
                //    {
                //        _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                //        throw;
                //    }
                //}

                #endregion

                #region Consultar Permisos

                ////Declara Variables
                //List<PermisoPerfilType> PermisoPerfilType = new List<PermisoPerfilType>();

                //if (Canal)
                //{
                //    try
                //    {

                //        //Consumir servicio para obtener la informacion de configuracion SFTP
                //        string JsonPermisoPerfil = await _consultarPermisoCommand.ExecuteAsync(EntityType.Usuario);

                //        //Mapping 
                //        PermisoPerfilType = JsonSerializer.Deserialize<List<PermisoPerfilType>>(JsonPermisoPerfil);

                //        //Valida
                //        if (PermisoPerfilType == null || PermisoPerfilType.Count == 0)
                //        {
                //            throw new ServiceException("Dispositivo no tiene Permisos")
                //            { Codigo = StatusCodes.Status400BadRequest };
                //        }


                //    }
                //    catch (ServiceException ex) //Error personalizado
                //    {
                //        _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                //        throw;
                //    }
                //}

                #endregion


                #region Consultar Permisos

                //Declara Variables
                SessionWebType SessionWebType = new SessionWebType();

                if (Canal)
                {
                    try
                    {

                        //Consumir servicio para obtener la informacion de configuracion SFTP
                        string JsonPermiso = await _consultarPermisoMenuLoginCommand.ExecuteAsync(EntityType.Usuario);

                        //Mapping 
                        SessionWebType = JsonSerializer.Deserialize<SessionWebType>(JsonPermiso);

                        //Valida
                        if (SessionWebType == null)
                        {
                            throw new ServiceException("Usuario no tiene Permisos")
                            { Codigo = StatusCodes.Status400BadRequest };
                        }


                    }
                    catch (ServiceException ex) //Error personalizado
                    {
                        _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                        throw;
                    }
                }

                #endregion





                if (Canal)
                {
                    SessionWebType.Key = "";
                    SessionWebType.Expires = int.Parse(Parametro.Valor);
                    SessionWebType.Token = Token;

                    return SessionWebType;

                    //return new SessionWebType()
                    //{
                    //    Permisos = PermisoDispositivo,
                    //    Key = "",
                    //    Expires = int.Parse(Parametro.Valor),
                    //    Token = Token,
                    //    Permiso = PermisoPerfilType.Select(x=> x.Programas).FirstOrDefault(),
                    //    Menu = MenuItemType

                    //};
                }
                else
                {

                    return new SessionType()
                    {
                        Permisos = PermisoDispositivo,
                        Key = CredencialType.Pass,
                        Expires = int.Parse(Parametro.Valor),
                        Token = Token
                    };
                }

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }
        }


    }
}
