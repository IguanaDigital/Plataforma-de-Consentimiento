﻿namespace ReyBanPac.MigracionMS.Constans
{
    public class UrlService
    {
        public string CONSULTAR_PERMISO_DISPOSITIVO { get; set; } = string.Empty;
        public string CONSULTAR_KEY { get; set; } = string.Empty;

    }
}
