﻿
using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.MigracionMS.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<RespuestaType>> Migracion();

    }
}
