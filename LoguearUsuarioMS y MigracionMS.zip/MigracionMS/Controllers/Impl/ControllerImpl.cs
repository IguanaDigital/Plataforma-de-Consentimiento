﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.MigracionMS.Constans;
using ReyBanPac.MigracionMS.Controllers.Contract;
using ReyBanPac.MigracionMS.Service.Contract;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using System.Reflection;

namespace ReyBanPac.MigracionMS.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;

        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger)
        {
            Svc = Servicio;
            _logger = logger;
        }

        [HttpPost]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<RespuestaType>> Migracion()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                RespuestaType Resultado;
                Resultado = await Svc.Migracion();
                return Ok(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}",General.Nombre_Servicio,MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "",ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

    }
}
