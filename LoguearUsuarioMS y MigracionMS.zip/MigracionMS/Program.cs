using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using ReyBanPac.MigracionMS.Constans;
using ReyBanPac.MigracionMS.Controllers.Contract;
using ReyBanPac.MigracionMS.Controllers.Impl;
using ReyBanPac.MigracionMS.Repository.Context;
using ReyBanPac.MigracionMS.Repository.Contract;
using ReyBanPac.MigracionMS.Repository.Impl;
using ReyBanPac.MigracionMS.Service.Command;
using ReyBanPac.MigracionMS.Service.Contract;
using ReyBanPac.MigracionMS.Service.Impl;
using ReyBanPac.MigracionMS.Utils;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);


#region Consumer Key DB
var Host = builder.Configuration.GetSection("Parametros:HostApi").Value;
var Path = builder.Configuration.GetSection("ApiUrls:CONSULTAR_DB").Value;

var Url = string.Concat(Host, Path);

CredencialType? CredentialType = new CredencialType();

try
{
    using (var client = new HttpClient(Utils.OffSSLClient()))
    {
        var Response = await client.GetAsync(Url);
        Response.EnsureSuccessStatusCode();
        var Json = await Response.Content.ReadAsStringAsync();
        //Mapping
        CredentialType = JsonSerializer.Deserialize<CredencialType>(Json);
        //Valida
        if (CredentialType == null)
        {
            throw new ArgumentException("Error al obtener la credencial");
        }
    }
}

catch (Exception)
{
    throw new ArgumentException("Error al obtener la credencial");
}

var Connection = builder.Configuration.GetConnectionString("SQLConnection");
if (!string.IsNullOrEmpty(Connection))
{
    Connection = Connection.Replace("{User}", CredentialType.User)
        .Replace("{Pass}", Utils.Base64Decode(CredentialType.Pass));
}

builder.Services.AddDbContext<Db>(options => options.UseSqlServer(Connection));

var ConnectionLg = builder.Configuration.GetConnectionString("SQLConnectionLg");
if (!string.IsNullOrEmpty(ConnectionLg))
{
    ConnectionLg = ConnectionLg.Replace("{User}", CredentialType.User)
        .Replace("{Pass}", Utils.Base64Decode(CredentialType.Pass));
}
builder.Services.AddDbContext<LgDb>(options => options.UseSqlServer(ConnectionLg));
#endregion


#region Cors

// Configurar la politica CORS con la configuracion cargada
builder.Services.AddCors(options =>
{
    options.AddPolicy("NUXT", builder =>
    {
        builder.AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader();
    });
});
#endregion


// Add services to the container.
builder.Services.AddScoped<IController, ControllerImpl>();
builder.Services.AddScoped<IService, ServiceImpl>();
builder.Services.AddScoped<IRepository, RepositoryImpl>();
builder.Services.AddSingleton<Provider>();
builder.Services.AddTransient<ConsultarKeyCommand>();


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = General.Nombre_Servicio + "-" + General.Tipo_Servicio, Version = "v1" });

});

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("v1/swagger.json", General.Nombre_Servicio + "-" + General.Tipo_Servicio + " v1");
});


app.UseCors("NUXT");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
