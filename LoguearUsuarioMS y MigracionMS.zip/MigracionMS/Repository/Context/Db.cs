﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.MigracionMS.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<HaciendaModel> HaciendaModel => Set<HaciendaModel>();
        public DbSet<ZonaModel> ZonaModel => Set<ZonaModel>();
        public DbSet<CompaniaModel> CompaniaModel => Set<CompaniaModel>();

        public DbSet<PersonaModel> PersonaModel => Set<PersonaModel>();

        public DbSet<PersonaEmpresaModel> PersonaEmpresaModel => Set<PersonaEmpresaModel>();

        public DbSet<EmpleadoHaciendaModel> EmpleadoHaciendaModel => Set<EmpleadoHaciendaModel>();


    }
}
