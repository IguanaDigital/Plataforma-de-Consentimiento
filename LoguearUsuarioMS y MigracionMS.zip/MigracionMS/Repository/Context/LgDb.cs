﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.MigracionMS.Repository.Context
{
    public class LgDb : DbContext
    {
        public LgDb(DbContextOptions<LgDb> options) : base(options)
        {

        }
        public DbSet<LegadoControlETLModel> LegadoControlETLModel => Set<LegadoControlETLModel>();
        public DbSet<LegadoHaciendaModel> LegadoHaciendaModel => Set<LegadoHaciendaModel>();
        public DbSet<LegadoZonaModel> LegadoZonaModel => Set<LegadoZonaModel>();
        public DbSet<LegadoCompaniaModel> LegadoCompaniaModel => Set<LegadoCompaniaModel>();

        public DbSet<LegadoPersonaModel> LegadoPersonaModel => Set<LegadoPersonaModel>();

        public DbSet<LegadoPersonaEmpresaModel> LegadoPersonaEmpresaModel => Set<LegadoPersonaEmpresaModel>();

        public DbSet<LegadoEmpleadoHaciendaModel> LegadoEmpleadoHaciendaModel => Set<LegadoEmpleadoHaciendaModel>();


    }
}
