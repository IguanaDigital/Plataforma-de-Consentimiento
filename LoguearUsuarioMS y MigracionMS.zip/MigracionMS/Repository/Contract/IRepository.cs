﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.MigracionMS.Repository.Contract
{
    public interface IRepository
    {
        #region Legado

        public Task<LegadoControlETLModel?> ConsultarControlEtl();
        public Task<LegadoControlETLModel> ActualizarControlEtl(LegadoControlETLModel EntityModel);

        public Task<List<LegadoHaciendaModel>> ConsultarLegadoHacienda();
        public Task<List<LegadoZonaModel>> ConsultarLegadoZona();
        public Task<List<LegadoCompaniaModel>> ConsultarLegadoCompania();

        public Task<List<LegadoPersonaModel>> ConsultarLegadoPersona();
        public Task<List<LegadoPersonaEmpresaModel>> ConsultarLegadoPersonaEmpresa();
        public Task<List<LegadoEmpleadoHaciendaModel>> ConsultarLegadoEmpleadoHacienda();

        #endregion

        #region Local

        public Task<List<HaciendaModel>> InsertarHacienda(List<HaciendaModel> HaciendaNuevas);
        public Task<List<HaciendaModel>> ConsultarHacienda();

        public Task<List<ZonaModel>> InsertarZona(List<ZonaModel> ZonaNuevas);
        public Task<List<ZonaModel>> ConsultarZona();

        public Task<List<CompaniaModel>> InsertarCompania(List<CompaniaModel> CompaniaNuevas);
        public Task<List<CompaniaModel>> ConsultarCompania();


        public Task<List<PersonaModel>> InsertarPersona(List<PersonaModel> PersonaNuevas);
        public Task<List<PersonaModel>> ActualizarPersona(List<PersonaModel> PersonaModel);
        public Task<List<PersonaModel>> ConsultarPersona();

        public Task<List<PersonaEmpresaModel>> InsertarPersonaEmpresa(List<PersonaEmpresaModel> PersonaEmpresaNuevas);
        public Task<List<PersonaEmpresaModel>> ActualizarPersonaEmpresa(List<PersonaEmpresaModel> PersonaEmpresaModel);
        public Task<List<PersonaEmpresaType>> ConsultarPersonaEmpresa();

        public Task<List<EmpleadoHaciendaModel>> InsertarEmpleadoHacienda(List<EmpleadoHaciendaModel> EmpleadoHaciendaNuevas);
        public Task<List<EmpleadoHaciendaModel>> ActualizarEmpleadoHacienda(List<EmpleadoHaciendaModel> EmpleadoHaciendaModel);
        public Task<List<EmpleadoHaciendaType>> ConsultarEmpleadoHacienda();

        #endregion


    }
}
