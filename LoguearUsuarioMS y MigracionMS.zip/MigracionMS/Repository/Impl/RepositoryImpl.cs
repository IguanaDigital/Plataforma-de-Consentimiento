﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.MigracionMS.Constans;
using ReyBanPac.MigracionMS.Repository.Contract;
using ReyBanPac.MigracionMS.Repository.Context;
using ReyBanPac.ModeloCanonico.Model;
using System.Reflection;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.MigracionMS.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly LgDb lg;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, LgDb lgdbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            this.lg = lgdbContex;
            _logger = logger;
        }

        public async Task<LegadoControlETLModel?> ConsultarControlEtl()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await lg.LegadoControlETLModel.FirstOrDefaultAsync(x=> x.Fecha_Ejecucion_App == null && x.Estado_App == null);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<LegadoControlETLModel> ActualizarControlEtl(LegadoControlETLModel EntityModel)
        {
            try
            {
                var Item = lg.LegadoControlETLModel.Add(EntityModel);
                lg.Entry(EntityModel).State = EntityState.Modified;
                await lg.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<LegadoHaciendaModel>> ConsultarLegadoHacienda()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await lg.LegadoHaciendaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<LegadoZonaModel>> ConsultarLegadoZona()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await lg.LegadoZonaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<LegadoCompaniaModel>> ConsultarLegadoCompania()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await lg.LegadoCompaniaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }


        public async Task<List<LegadoPersonaModel>> ConsultarLegadoPersona()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await lg.LegadoPersonaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }


        public async Task<List<LegadoPersonaEmpresaModel>> ConsultarLegadoPersonaEmpresa()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await lg.LegadoPersonaEmpresaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<LegadoEmpleadoHaciendaModel>> ConsultarLegadoEmpleadoHacienda()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await lg.LegadoEmpleadoHaciendaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }













        public async Task<List<HaciendaModel>> InsertarHacienda(List<HaciendaModel> HaciendaNuevas)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                db.HaciendaModel.AddRange(HaciendaNuevas);
                await db.SaveChangesAsync();
                return HaciendaNuevas;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<HaciendaModel>> ConsultarHacienda()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await db.HaciendaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<ZonaModel>> InsertarZona(List<ZonaModel> ZonaNuevas)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                db.ZonaModel.AddRange(ZonaNuevas);
                await db.SaveChangesAsync();
                return ZonaNuevas;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<ZonaModel>> ConsultarZona()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await db.ZonaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<CompaniaModel>> InsertarCompania(List<CompaniaModel> CompaniaNuevas)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                db.CompaniaModel.AddRange(CompaniaNuevas);
                await db.SaveChangesAsync();
                return CompaniaNuevas;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<CompaniaModel>> ConsultarCompania()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await db.CompaniaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<PersonaModel>> InsertarPersona(List<PersonaModel> PersonaNuevas)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                db.PersonaModel.AddRange(PersonaNuevas);
                await db.SaveChangesAsync();
                return PersonaNuevas;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<PersonaModel>> ActualizarPersona(List<PersonaModel> PersonaModel)
        {
            try
            {
                await db.PersonaModel.AddRangeAsync(PersonaModel);
                db.Entry(PersonaModel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return PersonaModel;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<PersonaModel>> ConsultarPersona()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await db.PersonaModel.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }


        public async Task<List<PersonaEmpresaModel>> InsertarPersonaEmpresa(List<PersonaEmpresaModel> PersonaEmpresaNuevas)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                db.PersonaEmpresaModel.AddRange(PersonaEmpresaNuevas);
                await db.SaveChangesAsync();
                return PersonaEmpresaNuevas;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<PersonaEmpresaModel>> ActualizarPersonaEmpresa(List<PersonaEmpresaModel> PersonaEmpresaModel)
        {
            try
            {
                await db.PersonaEmpresaModel.AddRangeAsync(PersonaEmpresaModel);
                db.Entry(PersonaEmpresaModel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return PersonaEmpresaModel;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<PersonaEmpresaType>> ConsultarPersonaEmpresa()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await (from pe in db.PersonaEmpresaModel
                              join p in db.PersonaModel on pe.Id equals p.Id
                              select new PersonaEmpresaType
                              {
                                  Id = pe.Id,
                                  Cedula =p.Cedula,
                                  Id_Empresa_Jde = pe.Id_Empresa_Jde,
                                  Origen = pe.Origen,
                                  Tipo_Origen = pe.Tipo_Origen,
                                  Estado = pe.Estado
                              }).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<EmpleadoHaciendaModel>> InsertarEmpleadoHacienda(List<EmpleadoHaciendaModel> EmpleadoHaciendaNuevas)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                db.EmpleadoHaciendaModel.AddRange(EmpleadoHaciendaNuevas);
                await db.SaveChangesAsync();
                return EmpleadoHaciendaNuevas;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<EmpleadoHaciendaModel>> ActualizarEmpleadoHacienda(List<EmpleadoHaciendaModel> EmpleadoHaciendaModel)
        {
            try
            {
                await db.EmpleadoHaciendaModel.AddRangeAsync(EmpleadoHaciendaModel);
                db.Entry(EmpleadoHaciendaModel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return EmpleadoHaciendaModel;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
        public async Task<List<EmpleadoHaciendaType>> ConsultarEmpleadoHacienda()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                return await (from ph in db.EmpleadoHaciendaModel
                              join p in db.PersonaModel on ph.Id equals p.Id
                              select new EmpleadoHaciendaType
                              {
                                  Id = ph.Id,
                                  Cedula = p.Cedula,
                                  Id_Empresa = ph.Id_Empresa,
                                  Id_Hacienda = ph.Id_Hacienda,
                                  Id_Zona = ph.Id_Zona,
                                  Estado = ph.Estado
                              }).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }


    }
}
