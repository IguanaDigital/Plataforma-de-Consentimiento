﻿using ReyBanPac.MigracionMS.Constans;
using ReyBanPac.MigracionMS.Utils;
using System.Reflection;

namespace ReyBanPac.MigracionMS.Service.Command
{
    public class ConsultarKeyCommand
    {
        private readonly ILogger<ConsultarKeyCommand> _logger;
        private readonly Provider Provider;
        public ConsultarKeyCommand(Provider _provider, ILogger<ConsultarKeyCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Command", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {

                using (var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient()))
                {
                    var Url = string.Concat(Provider.HostApi, Provider.Api.CONSULTAR_KEY);

                    var Response = await client.GetAsync(Url);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Servicio no disponible para consultar key", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Command", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }
    }
}
