﻿
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.MigracionMS.Service.Contract
{
    public interface IService
    {
        public Task<RespuestaType> Migracion();


    }
}
