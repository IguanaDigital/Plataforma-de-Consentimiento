﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ReyBanPac.MigracionMS.Constans;
using ReyBanPac.MigracionMS.Repository.Contract;
using ReyBanPac.MigracionMS.Service.Command;
using ReyBanPac.MigracionMS.Service.Contract;
using ReyBanPac.MigracionMS.Utils;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using System.Reflection;
using System.Text.Json;

namespace ReyBanPac.MigracionMS.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository Repository;
        private readonly ConsultarKeyCommand _consultarKeyCommand;
        public ServiceImpl(ILogger<ServiceImpl> logger, 
            IRepository repositorio, 
            ConsultarKeyCommand consultarKeyCommand)
        {
            _logger = logger;
            Repository = repositorio;
            _consultarKeyCommand = consultarKeyCommand;
        }

        public async Task<RespuestaType> Migracion()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {

                #region Datos Iniciales
                DateTime Fecha = DateTime.Today;
                #endregion


                #region Consulta Control ETL
                LegadoControlETLModel? ControlEtl = await Repository.ConsultarControlEtl();

                if (ControlEtl == null)
                {
                    throw new ServiceException("No hay registro en Control ETL") { Codigo = StatusCodes.Status400BadRequest };
                }
                #endregion

                #region Validar Control ETL

                if (ControlEtl.Estado_Etl != "P") //Procesado
                {
                    throw new ServiceException("El estado en el Control ETL es distinto de 'P'") { Codigo = StatusCodes.Status400BadRequest };
                }


                #endregion

                //Ejecutar Migracion

                #region Procesar Hacienda

                try
                {
                    List<LegadoHaciendaModel> LegadoHacienda = await Repository.ConsultarLegadoHacienda();
                    List<HaciendaModel> Hacienda = await Repository.ConsultarHacienda();

                    // Identificar registros que están en Legado pero no en Local
                    var HaciendaNuevas = LegadoHacienda.Where(legado => !Hacienda.Exists(hacienda => hacienda.Id.Trim() == legado.Id.Trim())).ToList();


                    //Maping
                    List<HaciendaModel> HaciendaMaping = Converts.ConvertirListModelLegadoToListModelLocal(HaciendaNuevas);

                    await Repository.InsertarHacienda(HaciendaMaping);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error al migrar haciendas", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                }

                #endregion

                #region Procesar Zona
                try
                {
                    List<LegadoZonaModel> LegadoZona = await Repository.ConsultarLegadoZona();

                    List<ZonaModel> Zona = await Repository.ConsultarZona();

                    // Identificar registros que están en Legado pero no en Local
                    var ZonaNuevas = LegadoZona.Where(legado => !Zona.Exists(zona => zona.Id.Trim() == legado.Id.Trim())).ToList();


                    //Maping
                    List<ZonaModel> ZonaMaping = Converts.ConvertirListModelLegadoToListModelLocal(ZonaNuevas);

                    await Repository.InsertarZona(ZonaMaping);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error al migrar zonas", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                }
                #endregion

                #region Procesar Compania
                try
                {
                    List<LegadoCompaniaModel> LegadoCompania = await Repository.ConsultarLegadoCompania();

                    List<CompaniaModel> Compania = await Repository.ConsultarCompania();

                    // Identificar registros que están en Legado pero no en Local
                    var CompaniaNuevas = LegadoCompania.Where(legado => !Compania.Exists(compania => compania.Id.Trim() == legado.Id.Trim())).ToList();


                    //Maping
                    List<CompaniaModel> CompaniaMaping = Converts.ConvertirListModelLegadoToListModelLocal(CompaniaNuevas);

                    await Repository.InsertarCompania(CompaniaMaping);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Error al migrar compañias", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                }
                #endregion

                #region Consultar Key
                //Declara Variables
                CredencialType CredencialType = new CredencialType();

                try
                {

                    //Consumir servicio para obtener el key
                    string JsonKey = await _consultarKeyCommand.ExecuteAsync();

                    //Mapping 
                    CredencialType = JsonSerializer.Deserialize<CredencialType>(JsonKey) ?? new CredencialType();

                    //Valida
                    if (CredencialType == null || string.IsNullOrEmpty(CredencialType.Pass))
                    {
                        throw new ServiceException("No hay Key") { Codigo = StatusCodes.Status400BadRequest };
                    }


                }
                catch (ServiceException ex) //Error personalizado
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}",General.Nombre_Servicio,MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "",ex.Message);

                }


                #endregion


                #region Procesar Persona

                try
                {
                    List<LegadoPersonaModel> LegadoPersona = await Repository.ConsultarLegadoPersona();

                    List<PersonaModel> Persona = await Repository.ConsultarPersona();

                    //Desencriptar
                    Persona = Converts.Desencriptar(Persona, ModeloCanonico.Utils.Utils.Base64Decode(CredencialType.Pass));


                    // Identificar registros que están en Legado pero no en Local
                    var PersonaNueva = LegadoPersona.Where(legado => !Persona.Exists(cedula => cedula.Cedula.Trim() == legado.Cedula.Trim())).ToList();


                    //Maping
                    List<PersonaModel> PersonaMapingIns = Converts.ConvertirListModelLegadoToListModelLocal(PersonaNueva, ModeloCanonico.Utils.Utils.Base64Decode(CredencialType.Pass));

                    await Repository.InsertarPersona(PersonaMapingIns);


                    // Identificar registros que están en Local pero no en Legado
                    //var PersonaActualiza = Persona.Where(legado => !LegadoPersona.Any(cedula => cedula.Cedula == legado.Cedula)).ToList();


                    //Maping
                    //List<PersonaModel> PersonaMapingUpd = Converts.ConvertirListModelLegadoToListModelLocal(PersonaActualiza);

                    //await Repository.ActualizarPersona(PersonaMapingUpd);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Error al migrar personas", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                }
                #endregion

                #region Consulta Persona
                List<PersonaModel> ConsultaPersona = new List<PersonaModel>();
                try
                {
                    ConsultaPersona = await Repository.ConsultarPersona();

                    //Desencriptar
                    ConsultaPersona = Converts.Desencriptar(ConsultaPersona, ModeloCanonico.Utils.Utils.Base64Decode(CredencialType.Pass));

                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Error al consultar personas", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                }
                #endregion

                #region Procesar Persona Empresa


                try
                {
                    List<LegadoPersonaEmpresaModel> LegadoPersonaEmpresa = await Repository.ConsultarLegadoPersonaEmpresa();

                    List<PersonaEmpresaType> PersonaEmpresa = await Repository.ConsultarPersonaEmpresa();

                    //Desencriptar
                    PersonaEmpresa = Converts.Desencriptar(PersonaEmpresa, ModeloCanonico.Utils.Utils.Base64Decode(CredencialType.Pass));


                    // Identificar registros que están en Legado pero no en Local
                    var PersonaNueva = LegadoPersonaEmpresa.Where(legado => !PersonaEmpresa.Exists(cedula => cedula.Cedula.Trim() == legado.Cedula.Trim())).ToList();


                    //Maping
                    List<PersonaEmpresaModel> PersonaMapingIns = Converts.ConvertirListModelLegadoToListModelLocal(PersonaNueva, ConsultaPersona);

                    await Repository.InsertarPersonaEmpresa(PersonaMapingIns);


                    // Identificar registros que están en Local pero no en Legado
                    //var PersonaActualiza = Persona.Where(legado => !LegadoPersona.Any(cedula => cedula.Cedula == legado.Cedula)).ToList();


                    //Maping
                    //List<PersonaEmpresaModel> PersonaMapingUpd = Converts.ConvertirListModelLegadoToListModelLocal(PersonaActualiza);

                    //await Repository.ActualizarPersona(PersonaMapingUpd);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Error al migrar personas empresa", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                }
                #endregion

                #region Procesar Empleado Hacienda
                try
                {
                    List<LegadoEmpleadoHaciendaModel> LegadoEmpleadoHacienda = await Repository.ConsultarLegadoEmpleadoHacienda();

                    List<EmpleadoHaciendaType> EmpleadoHacienda = await Repository.ConsultarEmpleadoHacienda();

                    //Desencriptar
                    EmpleadoHacienda = Converts.Desencriptar(EmpleadoHacienda, ModeloCanonico.Utils.Utils.Base64Decode(CredencialType.Pass));


                    // Identificar registros que están en Legado pero no en Local
                    var PersonaNueva = LegadoEmpleadoHacienda.Where(legado => !EmpleadoHacienda.Exists(cedula => cedula.Cedula.Trim() == legado.Cedula.Trim())).ToList();


                    //Maping
                    List<EmpleadoHaciendaModel> PersonaMapingIns = Converts.ConvertirListModelLegadoToListModelLocal(PersonaNueva, ConsultaPersona);

                    await Repository.InsertarEmpleadoHacienda(PersonaMapingIns);


                    // Identificar registros que están en Local pero no en Legado
                    //var PersonaActualiza = Persona.Where(legado => !LegadoPersona.Any(cedula => cedula.Cedula == legado.Cedula)).ToList();


                    //Maping
                    //List<PersonaEmpresaModel> PersonaMapingUpd = Converts.ConvertirListModelLegadoToListModelLocal(PersonaActualiza);

                    //await Repository.ActualizarPersona(PersonaMapingUpd);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Error al migrar empleado hacienda", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                }
                #endregion

                #region Actualizar Control ETL
                ControlEtl.Estado_App = "P";
                ControlEtl.Fecha_Ejecucion_App = Fecha;

                ControlEtl = await Repository.ActualizarControlEtl(ControlEtl);

                if (ControlEtl == null)
                {
                    throw new ServiceException("No hay registro en Control ETL") { Codigo = StatusCodes.Status400BadRequest };
                }
                #endregion


                return new RespuestaType();
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}",General.Nombre_Servicio,MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "",ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }


    }
}
