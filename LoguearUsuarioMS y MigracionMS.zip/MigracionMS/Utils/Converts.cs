﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Utils;
using System.Text.Json;
using System.Linq;

namespace ReyBanPac.MigracionMS.Utils
{
    public static class Converts
    {

        public static CompaniaModel ConvertirModelLegadoAModelLocal(LegadoCompaniaModel Model)
        {
            CompaniaModel Entity = new CompaniaModel();

            if (Model != null && !string.IsNullOrEmpty(Model.Id))
            {
                Entity.Id = Model.Id.Trim();
                Entity.Nombre = Model.Nombre.Trim();
                Entity.Estado = Estados.ACTIVO;
                Entity.Fecha_Creacion = DateTime.Now;
            }

            return Entity;
        }
        public static PersonaModel ConvertirModelLegadoAModelLocal(LegadoPersonaModel Model, string Key)
        {
            PersonaModel Entity = new PersonaModel();

            if (Model != null && !string.IsNullOrEmpty(Model.Cedula))
            {
                Entity.Cedula = Security.CryptoAes.Cifrar(Model.Cedula.Trim(), Key);
                Entity.Nombre = Security.CryptoAes.Cifrar(Model.Nombre.Trim(), Key);
                Entity.Subledger = Model.Subledger;
                Entity.Correo = Model.Correo;
                Entity.Telefono = Model.Telefono;
                Entity.Estado = Estados.ACTIVO;
                Entity.Fecha_Creacion = DateTime.Now;
            }

            return Entity;
        }
        public static PersonaModel Desencriptar(PersonaModel Model, string Key)
        {
            PersonaModel Entity = new PersonaModel();

            if (Model != null && !string.IsNullOrEmpty(Model.Cedula))
            {
                Entity.Id = Model.Id;
                Entity.Cedula = Security.CryptoAes.Descifrar(Model.Cedula, Key);
                Entity.Nombre = Security.CryptoAes.Descifrar(Model.Nombre, Key);
                Entity.Subledger = Model.Subledger;
                Entity.Correo = Model.Correo;
                Entity.Telefono = Model.Telefono;
                Entity.Estado = Model.Estado;
                Entity.Fecha_Creacion = Model.Fecha_Creacion;
                Entity.Fecha_Actualizacion = Model.Fecha_Actualizacion;
            }

            return Entity;
        }
        public static PersonaEmpresaModel ConvertirModelLegadoAModelLocal(LegadoPersonaEmpresaModel Model, int Id)
        {
            PersonaEmpresaModel Entity = new PersonaEmpresaModel();

            if (Model != null && !string.IsNullOrEmpty(Model.Cedula))
            {
                Entity.Id = Id;
                Entity.Id_Empresa_Jde = Model.Id_Empresa_Jde;
                Entity.Origen = Model.Origen;
                Entity.Tipo_Origen = Model.Tipo_Origen;
                Entity.Estado = Estados.ACTIVO;
                Entity.Fecha_Creacion = DateTime.Now;
            }

            return Entity;
        }
        public static EmpleadoHaciendaModel ConvertirModelLegadoAModelLocal(LegadoEmpleadoHaciendaModel Model, int Id)
        {
            EmpleadoHaciendaModel Entity = new EmpleadoHaciendaModel();

            if (Model != null && !string.IsNullOrEmpty(Model.Cedula))
            {
                Entity.Id = Id;
                Entity.Id_Empleado = Model.Id_Empleado;
                Entity.Id_Hacienda = Model.Id_Hacienda.Trim();
                Entity.Id_Zona = Model.Id_Zona.Trim();
                Entity.Id_Empresa = Model.Id_Empresa.Trim();
                Entity.Estado = Estados.ACTIVO;
                Entity.Fecha_Creacion = DateTime.Now;
            }

            return Entity;
        }
        public static HaciendaModel ConvertirModelLegadoAModelLocal(LegadoHaciendaModel Model)
        {
            HaciendaModel Entity = new HaciendaModel();

            if (Model != null && !string.IsNullOrEmpty(Model.Id))
            {
                Entity.Id = Model.Id.Trim();
                Entity.Aban8 = Model.Aban8;
                Entity.Nombre = Model.Nombre.Trim();
                Entity.Estado = Estados.ACTIVO;
                Entity.Fecha_Creacion = DateTime.Now;
            }

            return Entity;
        }
        public static ZonaModel ConvertirModelLegadoAModelLocal(LegadoZonaModel Model)
        {
            ZonaModel Entity = new ZonaModel();

            if (Model != null && !string.IsNullOrEmpty(Model.Id))
            {
                Entity.Id = Model.Id.Trim();
                Entity.Nombre = Model.Nombre.Trim();
                Entity.Ubicacion = Model.Ubicacion.Trim();
                Entity.Estado = Estados.ACTIVO;
                Entity.Fecha_Creacion = DateTime.Now;
            }

            return Entity;
        }
        public static List<HaciendaModel> ConvertirListModelLegadoToListModelLocal(List<LegadoHaciendaModel> ListadoModel)
        {
            List<HaciendaModel> Listado = new List<HaciendaModel>();
            if (ListadoModel != null)
            {
                foreach (LegadoHaciendaModel Item in ListadoModel)
                {
                    if (!string.IsNullOrEmpty(Item.Id))
                        Listado.Add(ConvertirModelLegadoAModelLocal(Item));
                }
            }
            return Listado;
        }
        public static List<ZonaModel> ConvertirListModelLegadoToListModelLocal(List<LegadoZonaModel> ListadoModel)
        {
            List<ZonaModel> Listado = new List<ZonaModel>();
            if (ListadoModel != null)
            {
                foreach (LegadoZonaModel Item in ListadoModel)
                {
                    Listado.Add(ConvertirModelLegadoAModelLocal(Item));
                }
            }
            return Listado;
        }
        public static List<CompaniaModel> ConvertirListModelLegadoToListModelLocal(List<LegadoCompaniaModel> ListadoModel)
        {
            List<CompaniaModel> Listado = new List<CompaniaModel>();
            if (ListadoModel != null)
            {
                foreach (LegadoCompaniaModel Item in ListadoModel)
                {
                    Listado.Add(ConvertirModelLegadoAModelLocal(Item));
                }
            }
            return Listado;
        }
        public static List<PersonaModel> ConvertirListModelLegadoToListModelLocal(List<LegadoPersonaModel> ListadoModel, string Key)
        {


            List<PersonaModel> Listado = new List<PersonaModel>();
            if (ListadoModel != null)
            {
                //Separardor de objero ref por encriptacion
                var Json = JsonSerializer.Serialize(ListadoModel);
                var EntityNew = JsonSerializer.Deserialize<List<LegadoPersonaModel>>(Json) ?? new List<LegadoPersonaModel>();

                foreach (LegadoPersonaModel Item in EntityNew)
                {
                    Listado.Add(ConvertirModelLegadoAModelLocal(Item, Key));
                }
            }
            return Listado;
        }
        public static List<PersonaModel> Desencriptar(List<PersonaModel> ListadoModel, string Key)
        {


            List<PersonaModel> Listado = new List<PersonaModel>();
            if (ListadoModel != null)
            {
                //Separardor de objero ref por encriptacion
                var Json = JsonSerializer.Serialize(ListadoModel);
                var Entity = JsonSerializer.Deserialize<List<PersonaModel>>(Json) ?? new List<PersonaModel>();

                foreach (PersonaModel Item in Entity)
                {
                    Listado.Add(Desencriptar(Item, Key));
                }
            }
            return Listado;
        }
        public static List<PersonaEmpresaType> Desencriptar(List<PersonaEmpresaType> ListadoModel, string Key)
        {
            if (ListadoModel != null)
            {
                //Separardor de objero ref por encriptacion
                var Json = JsonSerializer.Serialize(ListadoModel);
                var Entity = JsonSerializer.Deserialize<List<PersonaEmpresaType>>(Json) ?? new List<PersonaEmpresaType>();
                Entity.ForEach(x => x.Cedula = Security.CryptoAes.Descifrar(x.Cedula, Key));

                return Entity;
            }
            else
                throw new ServiceException("El listado no puede ser null");

        }
        public static List<EmpleadoHaciendaType> Desencriptar(List<EmpleadoHaciendaType> ListadoModel, string Key)
        {
            if (ListadoModel != null)
            {
                //Separardor de objero ref por encriptacion
                var Json = JsonSerializer.Serialize(ListadoModel);
                var Entity = JsonSerializer.Deserialize<List<EmpleadoHaciendaType>>(Json) ?? new List<EmpleadoHaciendaType>();
                Entity.ForEach(x => x.Cedula = Security.CryptoAes.Descifrar(x.Cedula, Key));

                return Entity;
            }
            else
                throw new ServiceException("El listado no puede ser null");

        }
        public static List<PersonaEmpresaModel> ConvertirListModelLegadoToListModelLocal(List<LegadoPersonaEmpresaModel> ListadoModel, List<PersonaModel> Persona)
        {
            List<PersonaEmpresaModel> Listado = new List<PersonaEmpresaModel>();
            if (ListadoModel != null)
            {
                foreach (LegadoPersonaEmpresaModel Item in ListadoModel)
                {
                    var Id = Persona.Where(x => x.Cedula.Trim() == Item.Cedula.Trim()).Select(t => t.Id).FirstOrDefault();
                    if (Id != 0)
                        Listado.Add(ConvertirModelLegadoAModelLocal(Item, Id));

                }
            }
            return Listado;
        }
        public static List<EmpleadoHaciendaModel> ConvertirListModelLegadoToListModelLocal(List<LegadoEmpleadoHaciendaModel> ListadoModel, List<PersonaModel> Persona)
        {
            List<EmpleadoHaciendaModel> Listado = new List<EmpleadoHaciendaModel>();
            if (ListadoModel != null)
            {
                foreach (LegadoEmpleadoHaciendaModel Item in ListadoModel)
                {
                    var Id = Persona.Where(x => x.Cedula.Trim() == Item.Cedula.Trim()).Select(t => t.Id).FirstOrDefault();
                    if (Id != 0)
                        Listado.Add(ConvertirModelLegadoAModelLocal(Item,Id));
                }
            }
            return Listado;
        }

    }
}
