﻿namespace ReyBanPac.ModeloCanonico.Constans
{
    public static class Estados
    {
        public const string ACTIVO = "A";
        public const string INACTIVO = "I";
        public const string ELIMINADO = "E";
    }

    public enum Frecuencias
    {
        Diaria = 1,
        Semanal = 2,
        Mensual = 3,
    }
}
