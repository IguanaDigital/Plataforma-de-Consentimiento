﻿namespace ReyBanPac.ModeloCanonico.Constans
{
    public static class MimeType
    {
        public const String JSON = "application/json";
        public const String FILE = "multipart/form-data";
    }
}
