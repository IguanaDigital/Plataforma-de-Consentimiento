﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Archivos_Consentimiento")]
    public class ArchivoConsentimientoModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("id_consentimiento", TypeName = "int")]
        public int Id_Consentimiento { get; set; }

        [Column("dir_archivo", TypeName = "nvarchar(500)")]
        public string Dir_Archivo { get; set; }

        [Column("nombre_archivo", TypeName = "nvarchar(50)")]
        public string Nombre_Archivo { get; set; }

        [Column("fecha_transferencia", TypeName = "datetime")]
        public DateTime Fecha_Transferencia { get; set; }

        [Column("md5", TypeName = "nvarchar(50)")]
        public string MD5 { get; set; }

        public ArchivoConsentimientoModel()
        {
            Id_Consentimiento = 0;
            Dir_Archivo = string.Empty;
            Nombre_Archivo = string.Empty;
            Fecha_Transferencia = DateTime.Now;
            MD5 = string.Empty;

        }
    }
}
