﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    public class AuditoriaModel
    {
        [Column("estado", TypeName = "nvarchar(1)")]
        public string Estado { get; set; }

        [Column("fecha_creacion", TypeName = "datetime")]
        public DateTime Fecha_Creacion { get; set; }

        [Column("fecha_actualizacion", TypeName = "datetime")]
        public DateTime? Fecha_Actualizacion { get; set; }

        public AuditoriaModel()
        {
            Fecha_Creacion = DateTime.Now;
            Fecha_Actualizacion = null;
            Estado = Estados.ACTIVO;
        }
    }
}
