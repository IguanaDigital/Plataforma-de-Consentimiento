﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Compania_Caracteristicas")]
    public class CompaniaCaracteristicaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("id_compania", TypeName = "nvarchar(5)")]
        public string Id_Compania { get; set; }

        [Column("logo", TypeName = "ntext")]
        public string Logo { get; set; }

        [Column("color_bg", TypeName = "nvarchar(10)")]
        public string Color_Bg { get; set; }

        [Column("color_fg", TypeName = "nvarchar(10)")]
        public string Color_Fg { get; set; }


        public CompaniaCaracteristicaModel()
        {
            Id_Compania = string.Empty;
            Logo = string.Empty;
            Color_Bg = string.Empty;
            Color_Fg = string.Empty;
        }
    }
}
