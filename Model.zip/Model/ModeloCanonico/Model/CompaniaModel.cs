﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Compania")]
    public class CompaniaModel : AuditoriaModel
    {
        [Column("id", TypeName = "nvarchar(5)")]
        [Key]
        public string Id { get; set; }

        [Column("nombre", TypeName = "nvarchar(30)")]
        public string? Nombre { get; set; }


        public CompaniaModel()
        {
            Id = string.Empty;
            Nombre = string.Empty;
        }
    }
}
