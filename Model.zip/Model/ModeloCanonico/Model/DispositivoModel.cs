﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Dispositivo")]
    public class DispositivoModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("identificador", TypeName = "nvarchar(50)")]
        public string Identificador { get; set; }

        [Column("nombre", TypeName = "nvarchar(50)")]
        public string Nombre { get; set; }

        public DispositivoModel()
        {
            Identificador = string.Empty;
            Nombre = string.Empty;

        }
    }
}
