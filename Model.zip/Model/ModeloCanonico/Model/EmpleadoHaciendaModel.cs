﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Empleado_Hacienda")]
    public class EmpleadoHaciendaModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("id_empleado_jaff", TypeName = "numeric(18, 0)")]
        public decimal Id_Empleado { get; set; }

        [Column("id_hacienda_jaff", TypeName = "nvarchar(12)")]
        public string Id_Hacienda { get; set; }

        [Column("cod_zona_sector_jaff", TypeName = "nvarchar(3)")]
        public string Id_Zona { get; set; }

        [Column("cod_empresa_jaff", TypeName = "nvarchar(5)")]
        public string Id_Empresa { get; set; }


        public EmpleadoHaciendaModel()
        {
            Id_Hacienda = string.Empty;
            Id_Zona = string.Empty;
            Id_Empresa = string.Empty;
        }
    }
}
