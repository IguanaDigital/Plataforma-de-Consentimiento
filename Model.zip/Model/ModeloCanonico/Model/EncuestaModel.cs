﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Encuesta")]
    public class EncuestaModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("id_plantilla", TypeName = "int")]
        public int Id_Plantilla { get; set; }

        [Column("id_tipo_campania", TypeName = "int")]
        public int Id_Tipo_Campania { get; set; }

        [Column("nombre", TypeName = "nvarchar(500)")]
        public string Nombre { get; set; }

        [Column("habilitar_noaceptar", TypeName = "bit")]
        public bool Habilitar_NoAceptar { get; set; }

        [Column("fecha_inicio", TypeName = "datetime")]
        public DateTime Fecha_Inicio { get; set; }

        [Column("fecha_fin", TypeName = "datetime")]
        public DateTime Fecha_Fin { get; set; }


        public EncuestaModel()
        {
            Nombre = string.Empty;
            Habilitar_NoAceptar = false;
            Fecha_Inicio = DateTime.Now;
            Fecha_Fin = DateTime.Now;
        }
    }
}
