﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Hacienda")]
    public class HaciendaModel : AuditoriaModel
    {
        [Column("id", TypeName = "nvarchar(12)")]
        [Key]
        public string Id { get; set; }

        [Column("nombre", TypeName = "nvarchar(20)")]
        public string Nombre { get; set; }

        [Column("aban8", TypeName = "float")]
        public float? Aban8 { get; set; }

        public HaciendaModel()
        {
            Id = string.Empty;
            Nombre = string.Empty;
            Aban8 = 0;
        }
    }
}
