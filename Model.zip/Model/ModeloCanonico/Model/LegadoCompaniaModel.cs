﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("JAW_MCompania")]
    public class LegadoCompaniaModel
    {
        [Column("JAWCIA_ID", TypeName = "nvarchar(5)")]
        [Key]
        public string Id { get; set; }

        [Column("JAWCIA_nombre", TypeName = "nvarchar(30)")]
        public string? Nombre { get; set; }


        public LegadoCompaniaModel()
        {
            Id = string.Empty;
            Nombre = string.Empty;
        }
    }
}
