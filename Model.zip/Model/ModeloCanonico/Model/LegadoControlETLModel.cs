﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("CONTROL_ETL")]
    public class LegadoControlETLModel
    {
        [Column("ID", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("FECHA", TypeName = "nvarchar(8)")]
        public string? Fecha { get; set; }

        [Column("ENTIDAD", TypeName = "nvarchar(25)")]
        public string? Entidad { get; set; }

        [Column("FECHA_EJECUCION_ETL", TypeName = "datetime")]
        public DateTime? Fecha_Ejecucion_Etl { get; set; }

        [Column("ESTADO_ETL", TypeName = "nvarchar(1)")]
        public string? Estado_Etl { get; set; }

        [Column("FECHA_EJECUCION_APP", TypeName = "datetime")]
        public DateTime? Fecha_Ejecucion_App { get; set; }

        [Column("ESTADO_APP", TypeName = "nvarchar(1)")]
        public string? Estado_App { get; set; }

        public LegadoControlETLModel()
        {
            Fecha = string.Empty;
            Entidad = string.Empty;
            Estado_Etl = string.Empty;
            Estado_App = string.Empty;
        }
    }

}
