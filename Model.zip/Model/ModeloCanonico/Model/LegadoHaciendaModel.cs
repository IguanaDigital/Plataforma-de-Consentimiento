﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("EMHACDAS")]
    public class LegadoHaciendaModel
    {
        [Column("EMCODHAC", TypeName = "nvarchar(12)")]
        [Key]
        public string Id { get; set; }

        [Column("EMNOMHAC", TypeName = "nvarchar(20)")]
        public string Nombre { get; set; }

        [Column("ABAN8", TypeName = "float")]
        public float? Aban8 { get; set; }

        public LegadoHaciendaModel()
        {
            Id = string.Empty;
            Nombre = string.Empty;
            Aban8 = 0;
        }
    }
}
