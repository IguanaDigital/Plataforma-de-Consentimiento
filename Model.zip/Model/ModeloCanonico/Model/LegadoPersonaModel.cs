﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Persona")]
    public class LegadoPersonaModel
    {
        [Column("cedula", TypeName = "nvarchar(20)")]
        [Key]
        public string Cedula { get; set; }

        [Column("nombre", TypeName = "nvarchar(200)")]
        public string Nombre { get; set; }

        [Column("subledger", TypeName = "nvarchar(30)")]
        public string? Subledger { get; set; }

        [Column("correo", TypeName = "nvarchar(50)")]
        public string? Correo { get; set; }

        [Column("telefono", TypeName = "nvarchar(30)")]
        public string? Telefono { get; set; }

        public LegadoPersonaModel()
        {
            Cedula = string.Empty;
            Nombre = string.Empty;
            Subledger = string.Empty;
            Correo = string.Empty;
            Telefono = string.Empty;
        }
    }
}
