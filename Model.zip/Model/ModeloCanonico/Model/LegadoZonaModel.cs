﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("LFZONAS")]
    public class LegadoZonaModel
    {
        [Column("LFCODZON", TypeName = "nvarchar(3)")]
        [Key]
        public string Id { get; set; }

        [Column("LFDESZON", TypeName = "nvarchar(30)")]
        public string? Nombre { get; set; }

        [Column("LFUBIZON", TypeName = "nvarchar(50)")]
        public string? Ubicacion { get; set; }

        public LegadoZonaModel()
        {
            Id = string.Empty;
            Nombre = string.Empty;
            Ubicacion = string.Empty;
        }
    }
}
