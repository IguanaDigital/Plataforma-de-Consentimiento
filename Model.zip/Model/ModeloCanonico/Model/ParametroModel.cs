﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Parametro")]
    public class ParametroModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("codigo", TypeName = "nvarchar(15)")]
        public string Codigo { get; set; }

        [Column("valor", TypeName = "nvarchar(500)")]
        public string Valor { get; set; }

        public ParametroModel()
        {
            Codigo = string.Empty;
            Valor = string.Empty;
        }
    }
}
