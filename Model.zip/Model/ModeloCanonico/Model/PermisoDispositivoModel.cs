﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Permiso_Dispositivo")]
    public class PermisoDispositivoModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("id_hacienda", TypeName = "nvarchar(12)")]
        public string Id_Hacienda { get; set; }

        [Column("id_dispositivo", TypeName = "int")]
        public int Id_Dispositivo { get; set; }

        [Column("id_encuesta", TypeName = "int")]
        public int Id_Encuesta { get; set; }

        public PermisoDispositivoModel()
        {
            Id_Hacienda = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
