﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Persona_Empresa")]
    public class PersonaEmpresaModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("id_empresa_jde", TypeName = "numeric(18,0)")]
        public decimal Id_Empresa_Jde { get; set; }

        [Column("origen", TypeName = "varchar(50)")]
        public string Origen { get; set; }

        [Column("tipo_origen", TypeName = "varchar(50)")]
        public string Tipo_Origen { get; set; }

        public PersonaEmpresaModel()
        {
            Id_Empresa_Jde = 0;
            Origen = string.Empty;
            Tipo_Origen = string.Empty;
        }
    }
}
