﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Persona")]
    public class PersonaModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("cedula", TypeName = "nvarchar(100)")]
        public string Cedula { get; set; }

        [Column("nombre", TypeName = "nvarchar(500)")]
        public string Nombre { get; set; }

        [Column("subledger", TypeName = "nvarchar(30)")]
        public string? Subledger { get; set; }

        [Column("correo", TypeName = "nvarchar(50)")]
        public string? Correo { get; set; }

        [Column("telefono", TypeName = "nvarchar(30)")]
        public string? Telefono { get; set; }

        public PersonaModel()
        {
            Cedula = string.Empty;
            Nombre = string.Empty;
            Subledger = string.Empty;
            Correo = string.Empty;
            Telefono = string.Empty;
        }
    }
}
