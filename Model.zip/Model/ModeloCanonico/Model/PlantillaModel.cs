﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Plantilla")]
    public class PlantillaModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("titulo", TypeName = "nvarchar(50)")]
        public string Titulo { get; set; }

        [Column("contenido", TypeName = "ntext")]
        public string Contenido { get; set; }

        [Column("contenido_video", TypeName = "ntext")]
        public string Contenido_Video { get; set; }

        public PlantillaModel()
        {
            Titulo = string.Empty;
            Contenido = string.Empty;
            Contenido_Video = string.Empty;
        }
    }
}
