﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Proceso")]
    public class ProcesoModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("codigo", TypeName = "nvarchar(5)")]
        public string Codigo { get; set; }

        [Column("proceso", TypeName = "nvarchar(200)")]
        public string Proceso { get; set; }

        [Column("frecuencia", TypeName = "int")]
        public Frecuencias Frecuencia { get; set; }

        [Column("hora", TypeName = "nvarchar(200)")]
        public string Hora { get; set; }

        [Column("diasemana", TypeName = "nvarchar(50)")]
        public string DiaSemana { get; set; }

        [Column("diasmes", TypeName = "int")]
        public int DiaMes { get; set; }

        [Column("aplica_feriado", TypeName = "bit")]
        public bool AplicaFeriado { get; set; }


        public ProcesoModel()
        {
            Codigo = string.Empty;
            Proceso = string.Empty;
            Hora = string.Empty;
            Frecuencia = Frecuencias.Diaria;
            DiaSemana = string.Empty;
            AplicaFeriado = false;
            Estado = Estados.ACTIVO;
        }
    }
}