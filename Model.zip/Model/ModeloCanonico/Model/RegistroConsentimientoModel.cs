﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Registro_Consentimiento")]
    public class RegistroConsentimientoModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("id_persona", TypeName = "int")]
        public int Id_Persona { get; set; }

        [Column("id_encuesta", TypeName = "int")]
        public int Id_Encuesta { get; set; }

        [Column("aceptado", TypeName = "bit")]
        public bool Aceptado { get; set; }

        [Column("latitud", TypeName = "float")]
        public float Latitud { get; set; }

        [Column("longitud", TypeName = "float")]
        public float Longitud { get; set; }

        [Column("fecha", TypeName = "datetime")]
        public DateTime Fecha { get; set; }

        [Column("hora", TypeName = "nvarchar(5)")]
        public string Hora { get; set; }

        public RegistroConsentimientoModel()
        {
            Aceptado = false;
            Latitud = 0;
            Longitud = 0;
            Fecha = DateTime.Today;
            Hora = string.Empty;
        }
    }
}
