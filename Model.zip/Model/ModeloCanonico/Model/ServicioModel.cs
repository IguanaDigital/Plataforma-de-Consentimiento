﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Servicio")]
    public class ServicioModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("id_proceso", TypeName = "int")]
        public int Id_Proceso { get; set; }

        [Column("descripcion", TypeName = "nvarchar(200)")]
        public string Descripcion { get; set; }

        [Column("url", TypeName = "nvarchar(200)")]
        public string Url { get; set; }

        [Column("tipo_peticion", TypeName = "nvarchar(20)")]
        public string TipoPeticion { get; set; }

        public ServicioModel()
        {
            Id_Proceso = 0;
            Descripcion = string.Empty;
            Url = string.Empty;
            TipoPeticion = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
