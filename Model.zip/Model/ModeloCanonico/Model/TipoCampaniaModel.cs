﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Tipo_Campania")]
    public class TipoCampaniaModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("nombre", TypeName = "nvarchar(50)")]
        public string Nombre { get; set; }

        [Column("codigo", TypeName = "nvarchar(5)")]
        public string Codigo { get; set; }

        public TipoCampaniaModel()
        {
            Nombre = string.Empty;
            Codigo = string.Empty;
        }
    }
}
