﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Token")]
    public class TokenModel : AuditoriaModel
    {
        [Column("id", TypeName = "int")]
        [Key]
        public int Id { get; set; }

        [Column("token", TypeName = "ntext")]
        public string Token { get; set; }

        [Column("vigencia", TypeName = "datetime")]
        public DateTime Vigencia { get; set; }

        [Column("canal", TypeName = "int")]
        public int Canal { get; set; }

        public TokenModel()
        {
            Id = 0;
            Token = string.Empty;
            Vigencia = DateTime.Now;
            Canal = 0;
        }
    }
}
