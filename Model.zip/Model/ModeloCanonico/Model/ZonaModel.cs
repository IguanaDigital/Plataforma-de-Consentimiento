﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReyBanPac.ModeloCanonico.Model
{
    [Table("Zona")]
    public class ZonaModel : AuditoriaModel
    {
        [Column("id", TypeName = "nvarchar(3)")]
        [Key]
        public string Id { get; set; }

        [Column("nombre", TypeName = "nvarchar(30)")]
        public string? Nombre { get; set; }

        [Column("ubicacion", TypeName = "nvarchar(50)")]
        public string? Ubicacion { get; set; }

        public ZonaModel()
        {
            Id = string.Empty;
            Nombre = string.Empty;
            Ubicacion = string.Empty;
        }
    }
}
