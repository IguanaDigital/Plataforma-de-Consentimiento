﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class ArchivoConsentimientoType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("id_consentimiento")]
        public int Id_Consentimiento { get; set; }

        [JsonPropertyName("dir_archivo"), MaxLength(500)]
        public string Dir_Archivo { get; set; }

        [JsonPropertyName("Nombre_Archivo"), MaxLength(50)]
        public string Nombre_Archivo { get; set; }

        [JsonPropertyName("fecha_transferencia")]
        public DateTime Fecha_Transferencia { get; set; }

        [JsonPropertyName("md5"), MaxLength(50)]
        public string MD5 { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }


        public ArchivoConsentimientoType()
        {
            Id_Consentimiento = 0;
            Dir_Archivo = string.Empty;
            Nombre_Archivo = string.Empty;
            Fecha_Transferencia = DateTime.Now;
            MD5 = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
