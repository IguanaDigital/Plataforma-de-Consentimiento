﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class CompaniaType
    {
        [JsonPropertyName("id"), MaxLength(5)]
        public string Id { get; set; }

        [JsonPropertyName("nombre"), MaxLength(30)]
        public string? Nombre { get; set; }

        [JsonPropertyName("logo")]
        public string Logo { get; set; }

        [JsonPropertyName("color_bg"), MaxLength(10)]
        public string Color_Bg { get; set; }

        [JsonPropertyName("color_fg"), MaxLength(10)]
        public string Color_Fg { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public CompaniaType()
        {
            Id = string.Empty;
            Nombre = string.Empty;
            Logo = string.Empty;
            Color_Bg = string.Empty;
            Color_Fg = string.Empty;
            Estado = string.Empty;
        }
    }
}
