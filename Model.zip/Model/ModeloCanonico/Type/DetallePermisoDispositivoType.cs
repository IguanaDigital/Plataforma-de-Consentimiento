﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class DetallePermisoDispositivoType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("id_hacienda"), MaxLength(12)]
        public string Id_Hacienda { get; set; }

        [JsonPropertyName("hacienda")]
        public string Hacienda { get; set; }

        [JsonPropertyName("id_dispositivo")]
        public int Id_Dispositivo { get; set; }

        [JsonPropertyName("dispositivo")]
        public string Dispositivo { get; set; }

        [JsonPropertyName("identificador")]
        public string Identificador { get; set; }

        [JsonPropertyName("id_encuesta")]
        public int Id_Encuesta { get; set; }

        [JsonPropertyName("encuesta")]
        public string Encuesta { get; set; }

        [JsonPropertyName("id_zona"), MaxLength(3)]
        public string Id_Zona { get; set; }

        [JsonPropertyName("zona")]
        public string Zona { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }


        public DetallePermisoDispositivoType()
        {
            Id_Hacienda = string.Empty;
            Hacienda = string.Empty;
            Dispositivo = string.Empty;
            Identificador = string.Empty;
            Encuesta = string.Empty;
            Id_Zona = string.Empty;
            Zona = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
