﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class DispositivoType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("identificador"), MaxLength(50)]
        public string Identificador { get; set; }

        [JsonPropertyName("nombre"), MaxLength(50)]
        public string Nombre { get; set; }

        //[JsonPropertyName("wifi")]
        //public string Wifi { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }


        public DispositivoType()
        {
            Identificador = string.Empty;
            Nombre = string.Empty;
            //Wifi = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
