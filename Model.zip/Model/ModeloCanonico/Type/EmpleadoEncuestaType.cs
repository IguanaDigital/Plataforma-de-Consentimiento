﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class EmpleadoEncuestaType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("cedula"), MaxLength(50)]
        public string Cedula { get; set; }

        [JsonPropertyName("nombre"), MaxLength(200)]
        public string Nombre { get; set; }

        [JsonPropertyName("id_hacienda"), MaxLength(12)]
        public string Id_Hacienda { get; set; }

        [JsonPropertyName("id_zona"), MaxLength(3)]
        public string Id_Zona { get; set; }

        [JsonPropertyName("id_empresa"), MaxLength(5)]
        public string Id_Empresa { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public EmpleadoEncuestaType()
        {
            Cedula = string.Empty;
            Nombre = string.Empty;
            Id_Hacienda = string.Empty;
            Id_Zona = string.Empty;
            Id_Empresa = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
