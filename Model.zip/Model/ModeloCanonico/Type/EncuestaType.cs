﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class EncuestaType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("id_plantilla")]
        public int Id_Plantilla { get; set; }

        [JsonPropertyName("id_tipo_campania")]
        public int Id_Tipo_Campania { get; set; }

        [JsonPropertyName("nombre"), MaxLength(50)]
        public string Nombre { get; set; }

        [JsonPropertyName("habilitar_noaceptar")]
        public bool Habilitar_NoAceptar { get; set; }

        [JsonPropertyName("fecha_inicio")]
        public DateTime Fecha_Inicio { get; set; }

        [JsonPropertyName("fecha_fin")]
        public DateTime Fecha_Fin { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public EncuestaType()
        {
            Nombre = string.Empty;
            Habilitar_NoAceptar = false;
            Estado = Estados.ACTIVO;
            Fecha_Inicio = DateTime.Now;
            Fecha_Fin = DateTime.Now;
        }
    }
}
