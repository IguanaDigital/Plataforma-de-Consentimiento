﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class HaciendaType
    {
        [JsonPropertyName("id"), MaxLength(12)]
        public string Id { get; set; }

        [JsonPropertyName("nombre"), MaxLength(20)]
        public string Nombre { get; set; }

        [JsonPropertyName("aban8")]
        public float? Aban8 { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public HaciendaType()
        {
            Id = string.Empty;
            Nombre = string.Empty;
            Aban8 = 0;
            Estado = Estados.ACTIVO;
        }
    }
}
