﻿using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class LoguearUsuarioType
    {
        [JsonPropertyName("usuario")]
        public string Usuario { get; set; }

        [JsonPropertyName("clave")]
        public string Clave { get; set; }

        [JsonPropertyName("identificador")]
        public string Identificador { get; set; }

        public LoguearUsuarioType()
        {
            Usuario = string.Empty;
            Clave = string.Empty;
            Identificador = string.Empty;
        }
    }
}
