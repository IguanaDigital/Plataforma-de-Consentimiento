﻿using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class MenuItemType
    {
        [JsonPropertyName("path")]
        public string Path { get; set; }

        [JsonPropertyName("title")]
        public string Title { get; set; }

        [JsonPropertyName("icon")]
        public string Icon { get; set; }

        [JsonPropertyName("class")]
        public string @Class { get; set; }

        [JsonPropertyName("label")]
        public string Label { get; set; }

        [JsonPropertyName("labelClass")]
        public string LabelClass { get; set; }

        [JsonPropertyName("extralink")]
        public bool Extralink { get; set; }

        [JsonPropertyName("submenu")]
        public List<MenuItemType> Submenu { get; set; }
    }
}
