﻿using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class MenuType
    {
        [JsonPropertyName("codigo")]
        public string Codigo { get; set; }

        [JsonPropertyName("url")]
        public string URL { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; }

        [JsonPropertyName("icono")]
        public string? Icono { get; set; }

        [JsonPropertyName("submenu")]
        public List<MenuType> Submenu { get; set; }

        public MenuType()
        {
            Nombre = string.Empty;
            Codigo = string.Empty;
            URL = string.Empty;
            Icono = null;
            Codigo = string.Empty;
            URL = string.Empty;
            Submenu = new List<MenuType>();
        }
    }
}
