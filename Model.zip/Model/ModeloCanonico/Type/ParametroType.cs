﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class ParametroType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("codigo"), MaxLength(15)]
        public string Codigo { get; set; }

        [JsonPropertyName("valor"), MaxLength(500)]
        public string Valor { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public ParametroType()
        {
            Codigo = string.Empty;
            Valor = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
