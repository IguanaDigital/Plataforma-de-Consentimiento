﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class PermisoDispositivoType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("id_hacienda"), MaxLength(12)]
        public string Id_Hacienda { get; set; }

        [JsonPropertyName("id_dispositivo")]
        public int Id_Dispositivo { get; set; }

        [JsonPropertyName("id_encuesta")]
        public int Id_Encuesta { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }


        public PermisoDispositivoType()
        {
            Id_Hacienda = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
