﻿using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class PermisoMenuControlesType
    {
        [JsonPropertyName("codigo_control")]
        public string Codigo { get; set; }

        [JsonPropertyName("habilitar")]
        public bool Habilitar { get; set; }

        [JsonPropertyName("modificar")]
        public bool Modificar { get; set; }

        [JsonPropertyName("visualizar")]
        public bool Visualizar { get; set; }

        public PermisoMenuControlesType()
        {
            Codigo = string.Empty;
            Habilitar = false;
            Modificar = false;
            Visualizar = false;
        }
    }
}
