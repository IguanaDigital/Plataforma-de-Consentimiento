﻿using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class PermisoMenuType
    {
        [JsonPropertyName("codigo")]
        public string Codigo { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; }

        [JsonPropertyName("visualizar")]
        public bool Visualizar { get; set; }

        [JsonPropertyName("nuevo")]
        public bool Nuevo { get; set; }

        [JsonPropertyName("modificar")]
        public bool Modificar { get; set; }

        [JsonPropertyName("eliminar")]
        public bool Eliminar { get; set; }

        [JsonPropertyName("exportar")]
        public bool Exportar { get; set; }

        [JsonPropertyName("procesar")]
        public bool Procesar { get; set; }

        [JsonPropertyName("consulta")]
        public bool Consulta { get; set; }

        [JsonPropertyName("controles")]
        public List<PermisoMenuControlesType> Controles { get; set; }
        public PermisoMenuType()
        {
            Nombre = string.Empty;
            Codigo = string.Empty;
            Visualizar = false;
            Nuevo = false;
            Modificar = false;
            Eliminar = false;
            Exportar = false;
            Procesar = false;
            Consulta = false;
            Controles = null;
        }
    }
}
