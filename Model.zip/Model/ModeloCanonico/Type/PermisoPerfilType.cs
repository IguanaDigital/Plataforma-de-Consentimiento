﻿using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class PermisoPerfilType
    {

        [JsonPropertyName("codigo")]
        public string Codigo { get; set; }

        [JsonPropertyName("programas")]
        public List<PermisoMenuType> Programas { get; set; }

        public PermisoPerfilType()
        {
            Programas = null;
        }
    }
}
