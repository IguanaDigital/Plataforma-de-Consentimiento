﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class PersonaEmpresaType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("cedula"), MaxLength(100)]
        public string Cedula { get; set; }

        [JsonPropertyName("id_empresa_jde")]
        public decimal Id_Empresa_Jde { get; set; }

        [JsonPropertyName("origen"), MaxLength(50)]
        public string Origen { get; set; }

        [JsonPropertyName("tipo_origen"), MaxLength(50)]
        public string Tipo_Origen { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }
        public PersonaEmpresaType()
        {
            Cedula = string.Empty;
            Origen = string.Empty;
            Tipo_Origen = string.Empty;
            Id_Empresa_Jde = 0;
            Estado = Estados.ACTIVO;
        }
    }
}



