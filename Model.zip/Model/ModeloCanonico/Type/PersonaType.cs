﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class PersonaType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("cedula"), MaxLength(100)]
        public string Cedula { get; set; }

        [JsonPropertyName("nombre"), MaxLength(500)]
        public string? Nombre { get; set; }

        [JsonPropertyName("subledger"), MaxLength(30)]
        public string? Subledger { get; set; }

        [JsonPropertyName("correo"), MaxLength(50)]
        public string? Correo { get; set; }

        [JsonPropertyName("telefono"), MaxLength(30)]
        public string? Telefono { get; set; }

        public PersonaType()
        {
            Cedula = string.Empty;
            Nombre = string.Empty;
            Subledger = string.Empty;
            Correo = string.Empty;
            Telefono = string.Empty;
        }
    }
}
