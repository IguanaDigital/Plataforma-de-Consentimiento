﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class PlantillaType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("titulo"), MaxLength(50)]
        public string Titulo { get; set; }

        [JsonPropertyName("contenido")]
        public string Contenido { get; set; }

        [JsonPropertyName("contenido_video")]
        public string Contenido_Video { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public PlantillaType()
        {
            Titulo = string.Empty;
            Contenido = string.Empty;
            Contenido_Video = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
