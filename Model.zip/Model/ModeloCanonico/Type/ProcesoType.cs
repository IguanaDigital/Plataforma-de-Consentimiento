﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class ProcesoType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("codigo"), MaxLength(5)]
        public string Codigo { get; set; }

        [JsonPropertyName("proceso"), MaxLength(200)]
        public string Proceso { get; set; }

        [JsonPropertyName("frecuencia")]
        public Frecuencias Frecuencia { get; set; }

        [JsonPropertyName("hora"), MaxLength(200)]
        public string Hora { get; set; }

        [JsonPropertyName("diasemana"), MaxLength(50)]
        public string DiaSemana { get; set; }

        [JsonPropertyName("diasmes")]
        public int DiaMes { get; set; }

        [JsonPropertyName("aplica_feriado")]
        public bool AplicaFeriado { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }


        public ProcesoType()
        {
            Codigo = string.Empty;
            Proceso = string.Empty;
            Hora = string.Empty;
            Frecuencia = Frecuencias.Diaria;
            DiaSemana = string.Empty;
            AplicaFeriado = false;
            Estado = Estados.ACTIVO;
        }
    }
}
