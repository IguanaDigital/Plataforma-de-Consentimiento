﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class RegistroConsentimientoHaciendaType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("id_persona")]
        public int Id_Persona { get; set; }

        [JsonPropertyName("id_encuesta")]
        public int Id_Encuesta { get; set; }

        [JsonPropertyName("id_hacienda")]
        public string Id_Haciendad { get; set; }

        [JsonPropertyName("fecha")]
        public DateTime Fecha { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }


        public RegistroConsentimientoHaciendaType()
        {
            
            Fecha = DateTime.Today;
            Estado = Estados.ACTIVO;
        }
    }
}
