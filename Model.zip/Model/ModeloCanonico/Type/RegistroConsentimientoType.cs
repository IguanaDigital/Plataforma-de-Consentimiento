﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class RegistroConsentimientoType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("id_persona")]
        public int Id_Persona { get; set; }

        [JsonPropertyName("id_encuesta")]
        public int Id_Encuesta { get; set; }

        [JsonPropertyName("aceptado")]
        public bool Aceptado { get; set; }

        [JsonPropertyName("latitud")]
        public float Latitud { get; set; }

        [JsonPropertyName("longitud")]
        public float Longitud { get; set; }

        [JsonPropertyName("fecha")]
        public DateTime Fecha { get; set; }

        [JsonPropertyName("hora"), MaxLength(5)]
        public string Hora { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }


        public RegistroConsentimientoType()
        {
            Aceptado = false;
            Latitud = 0;
            Longitud = 0;
            Fecha = DateTime.Today;
            Hora = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
