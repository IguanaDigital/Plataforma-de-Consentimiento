﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class ServicioType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("id_proceso")]
        public int Id_Proceso { get; set; }

        [JsonPropertyName("descripcion"), MaxLength(200)]
        public string Descripcion { get; set; }

        [JsonPropertyName("url"), MaxLength(200)]
        public string Url { get; set; }

        [JsonPropertyName("tipo_peticion"), MaxLength(20)]
        public string TipoPeticion { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public ServicioType()
        {
            Id_Proceso = 0;
            Descripcion = string.Empty;
            Url = string.Empty;
            TipoPeticion = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
