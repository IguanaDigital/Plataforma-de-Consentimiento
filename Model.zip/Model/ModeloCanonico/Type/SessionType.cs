﻿using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class SessionType
    {
        [JsonPropertyName("token")]
        public string Token { get; set; }

        [JsonPropertyName("key")]
        public string Key { get; set; }

        [JsonPropertyName("expires")]
        public int Expires { get; set; }

        [JsonPropertyName("permisos")]
        public List<PermisoDispositivoType> Permisos { get; set; }


        public SessionType()
        {
            Token = string.Empty;
            Key = string.Empty;
            Expires = 0;
            Permisos = new List<PermisoDispositivoType>();
        }

    }
}
