﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class TipoCampaniaType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("nombre"), MaxLength(50)]
        public string Nombre { get; set; }

        [JsonPropertyName("codigo"), MaxLength(5)]
        public string Codigo { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public TipoCampaniaType()
        {
            Nombre = string.Empty;
            Codigo = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
