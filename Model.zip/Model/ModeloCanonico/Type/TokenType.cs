﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class TokenType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("token")]
        public string Token { get; set; }

        [JsonPropertyName("vigencia")]
        public DateTime Vigencia { get; set; }

        [JsonPropertyName("canal")]
        public int Canal { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public TokenType()
        {
            Id = 0;
            Token = string.Empty;
            Vigencia = DateTime.Now;
            Canal = 0;
            Estado = Estados.ACTIVO;
        }
    }
}
