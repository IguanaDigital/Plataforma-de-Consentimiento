﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.ModeloCanonico.Type
{
    public class ZonaType
    {
        [JsonPropertyName("id"), MaxLength(3)]
        public string Id { get; set; }

        [JsonPropertyName("nombre"), MaxLength(30)]
        public string? Nombre { get; set; }

        [JsonPropertyName("ubicacion"), MaxLength(50)]
        public string? Ubicacion { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        public ZonaType()
        {
            Id = string.Empty;
            Nombre = string.Empty;
            Ubicacion = string.Empty;
            Estado = Estados.ACTIVO;
        }
    }
}
