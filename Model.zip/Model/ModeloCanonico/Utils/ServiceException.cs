﻿namespace ReyBanPac.ModeloCanonico.Utils
{
    public class ServiceException : Exception
    {
        public int Codigo { get; set; }

        public ServiceException(string mensaje)
            : base(mensaje)
        {
        }

        public ServiceException(string mensaje, Exception excepcionInterna)
            : base(mensaje, excepcionInterna)
        {
        }
    }
}
