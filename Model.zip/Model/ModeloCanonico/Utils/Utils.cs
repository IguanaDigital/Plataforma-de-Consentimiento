﻿using System.Text;

namespace ReyBanPac.ModeloCanonico.Utils
{
    public static class Utils
    {
        public static string Base64Decode(string base64EncodedData)
        {
            byte[] bytes = Convert.FromBase64String(base64EncodedData);
            return Encoding.UTF8.GetString(bytes);
        }

        public static string Base64Encode(string dataToEncode)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(dataToEncode);
            return Convert.ToBase64String(bytes);
        }

        public static HttpClientHandler OffSSLClient()
        {
            return new HttpClientHandler()
            {
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
            };
        }
    }
}
