﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Security
{
    public class Crypto
    {
        public string CipherText { set; get; }
        public string IV { set; get; }
    }
}
