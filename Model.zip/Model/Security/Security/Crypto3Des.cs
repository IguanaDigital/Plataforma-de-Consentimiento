﻿using System.Security.Cryptography;
using System.Text;

namespace Security
{
    public static class Crypto3Des
    {
        /// <summary>
        /// Método encripta una cadena de string
        /// </summary>
        /// <param name="texto">Texto a encriptar</param>
        /// <param name="clave">Clave de 24 bytes (192 bits)</param>
        /// <returns>string encriptado</returns>
        public static string Cifrar(string texto, string clave)
        {
            using (TripleDES tdesAlg = TripleDES.Create())
            {
                tdesAlg.Key = Encoding.UTF8.GetBytes(clave);
                tdesAlg.GenerateIV(); // Generar un IV aleatorio para cada operación de cifrado

                ICryptoTransform encryptor = tdesAlg.CreateEncryptor();

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(texto);
                        }
                    }

                    // Combina el IV aleatorio con los datos cifrados en una cadena
                    byte[] ivBytes = tdesAlg.IV;
                    byte[] ciphertextBytes = msEncrypt.ToArray();
                    byte[] combinedBytes = new byte[ivBytes.Length + ciphertextBytes.Length];
                    Buffer.BlockCopy(ivBytes, 0, combinedBytes, 0, ivBytes.Length);
                    Buffer.BlockCopy(ciphertextBytes, 0, combinedBytes, ivBytes.Length, ciphertextBytes.Length);

                    return Convert.ToBase64String(combinedBytes);
                }
            }
        }
        /// <summary>
        /// Método desencripta una cadena de string previamenete encriptada
        /// </summary>
        /// <param name="textoCifrado">Texto encriptado a desencriptar</param>
        /// <param name="clave">Clave de 24 bytes (192 bits) utilizada cuando se encripto el texto</param>
        /// <returns>string desencriptado</returns>
        public static string Descifrar(string textoCifrado, string clave)
        {
            using (TripleDES tdesAlg = TripleDES.Create())
            {
                tdesAlg.Key = Encoding.UTF8.GetBytes(clave);

                // Extraer el IV de los datos cifrados
                byte[] combinedBytes = Convert.FromBase64String(textoCifrado);
                byte[] ivBytes = new byte[8]; // El IV de 3DES es de 8 bytes
                byte[] ciphertextBytes = new byte[combinedBytes.Length - ivBytes.Length];
                Buffer.BlockCopy(combinedBytes, 0, ivBytes, 0, ivBytes.Length);
                Buffer.BlockCopy(combinedBytes, ivBytes.Length, ciphertextBytes, 0, ciphertextBytes.Length);

                tdesAlg.IV = ivBytes;

                ICryptoTransform decryptor = tdesAlg.CreateDecryptor();

                using (MemoryStream msDecrypt = new MemoryStream(ciphertextBytes))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            return srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
        }
    }
}