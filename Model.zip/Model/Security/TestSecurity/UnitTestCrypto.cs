using Security;
namespace TestSecurity
{
    public class Tests
    {
      
        [Test]
        public void TestCifrarYDescifrarAes()
        {
            // Arrange: Configurar el escenario de prueba
            string textoOriginal = "Hola, mundo";
            string clave = "12345678901234567890123456789012"; // Clave de 32 bytes (256 bits)
            Console.WriteLine(clave);
            // Act: Ejecutar la acci�n que deseas probar
            string textoCifrado = CryptoAes.Cifrar(textoOriginal, clave);
            string textoDescifrado = CryptoAes.Descifrar(textoCifrado, clave);

            // Assert: Verificar los resultados esperados
            Assert.That(textoDescifrado, Is.EqualTo(textoOriginal));
        }

        [Test]
        public void TestCifrarYDescifrarTripeDes()
        {
            // Arrange: Configurar el escenario de prueba
            string textoOriginal = "Hola, mundo";
            string clave = "123456789012345678901234"; // Clave de 24 bytes (192 bits)
            Console.WriteLine(clave);
            // Act: Ejecutar la acci�n que deseas probar
            string textoCifrado = Crypto3Des.Cifrar(textoOriginal, clave);
            string textoDescifrado = Crypto3Des.Descifrar(textoCifrado, clave);

            // Assert: Verificar los resultados esperados
            Assert.That(textoDescifrado, Is.EqualTo(textoOriginal));
        }
    }
}