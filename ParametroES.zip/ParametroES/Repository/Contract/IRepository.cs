﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ParametroES.Repository.Contract
{
    public interface IRepository
    {
        public Task<ParametroModel> Guardar(ParametroModel EntityModel);

        public Task<ParametroModel> Actualizar(ParametroModel EntityModel);

        public Task<int> Eliminar(int Id);

        public Task<List<ParametroModel>> Consultar();

        public Task<ParametroModel> ConsultarPorId(int Id);

        public Task<ParametroModel> ConsultarPorCodigo(string Codigo);

        public Task<bool> ValidarExistencia(int Id);
    }
}
