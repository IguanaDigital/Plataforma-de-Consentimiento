﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ParametroES.Constans;
using ReyBanPac.ParametroES.Repository.Contract;
using ReyBanPac.ParametroES.Repository.Context;
using ReyBanPac.ModeloCanonico.Model;

using ReyBanPac.ModeloCanonico.Constans;

namespace ReyBanPac.ParametroES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            _logger = logger;
        }

        public async Task<ParametroModel> Guardar(ParametroModel EntityModel)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");
            try
            {
                EntityModel.Fecha_Creacion = DateTime.Now;
                var Item = db.Models.Add(EntityModel);
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<ParametroModel> Actualizar(ParametroModel EntityModel)
        {
            try
            {
                EntityModel.Fecha_Actualizacion = DateTime.Now;
                var Item = db.Models.Add(EntityModel);
                db.Entry(EntityModel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                var Reg = await db.Models.FindAsync(Id) ?? new ParametroModel();
                Reg.Estado = Estados.ELIMINADO;
                Reg.Fecha_Actualizacion = DateTime.Now;
                return await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<List<ParametroModel>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.Where(x => x.Estado != Estados.ELIMINADO).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<ParametroModel> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.FindAsync(Id) ?? new ParametroModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<ParametroModel> ConsultarPorCodigo(string Codigo)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.FirstOrDefaultAsync(x=> x.Codigo == Codigo) ?? new ParametroModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<bool> ValidarExistencia(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.AnyAsync(item => item.Id == Id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

    }
}
