﻿using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ParametroES.Service.Contract
{
    public interface IService
    {
        public Task<ParametroType> Guardar(ParametroType EntityType);

        public Task<ParametroType> Actualizar(ParametroType EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<ParametroType>> Consultar();

        public Task<ParametroType> ConsultarPorId(int Id);

        public Task<ParametroType> ConsultarPorCodigo(string Codigo);

    }
}
