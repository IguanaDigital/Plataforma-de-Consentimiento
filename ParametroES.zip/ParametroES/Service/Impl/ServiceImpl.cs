﻿using ReyBanPac.ParametroES.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ParametroES.Repository.Contract;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ParametroES.Service.Contract;
using ReyBanPac.ParametroES.Utils;

using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.ParametroES.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository Repository;

        public ServiceImpl(IRepository repositorio, ILogger<ServiceImpl> logger)
        {
            Repository = repositorio;
            _logger = logger;
        }

        public async Task<ParametroType> Guardar(ParametroType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                ParametroModel EntityModel = Converts.ConvertirTypeAModel(EntityType);
                EntityModel = await Repository.Guardar(EntityModel);
                return Converts.ConvertirModelAType(EntityModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }
        }

        public async Task<ParametroType> Actualizar(ParametroType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                bool Existe = await Repository.ValidarExistencia(EntityType.Id);
                if (Existe)
                {
                    ParametroModel EntityModel = Converts.ConvertirTypeAModel(EntityType);
                    EntityModel = await Repository.Actualizar(EntityModel);
                    return Converts.ConvertirModelAType(EntityModel);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }



        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                bool Existe = await Repository.ValidarExistencia(Id);
                if (Existe)
                {
                    return await Repository.Eliminar(Id);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }



        }

        public async Task<List<ParametroType>> Consultar()
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                List<ParametroModel> ListadoModel = await Repository.Consultar();
                List<ParametroType> ListadoType = Converts.ConvertirListModelToListType(ListadoModel);
                return ListadoType;
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }


        }

        public async Task<ParametroType> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                ParametroModel EntityModel = await Repository.ConsultarPorId(Id);

                return Converts.ConvertirModelAType(EntityModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }

        }

        public async Task<ParametroType> ConsultarPorCodigo(string Codigo)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                ParametroModel EntityModel = await Repository.ConsultarPorCodigo(Codigo);

                return Converts.ConvertirModelAType(EntityModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }

        }

    }
}
