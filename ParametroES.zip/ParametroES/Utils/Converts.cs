﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ParametroES.Utils
{
    public static class Converts
    {
        public static ParametroType ConvertirModelAType(ParametroModel Model)
        {
            ParametroType EntityType = new ParametroType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Codigo = Model.Codigo;
                EntityType.Valor = Model.Valor;
                EntityType.Estado = Model.Estado;
            }

            return EntityType;
        }

        public static ParametroModel ConvertirTypeAModel(ParametroType EntityType)
        {
            ParametroModel Model = new ParametroModel();
            if (EntityType != null)
            {
                Model.Id = EntityType.Id;
                Model.Codigo = EntityType.Codigo;
                Model.Valor = EntityType.Valor;
                Model.Estado = EntityType.Estado;
            }

            return Model;
        }

        public static List<ParametroType> ConvertirListModelToListType(List<ParametroModel> ListadoModel)
        {
            List<ParametroType> ListadoType = new List<ParametroType>();
            if (ListadoModel != null)
            {
                foreach (ParametroModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
