﻿namespace ReyBanPac.PermisoMenuMS.Constans
{
    public class UrlService
    {
        public string CONSULTAR_PERMISO_MENU { get; set; } = string.Empty;
        public string CONSULTAR_PERMISO { get; set; } = string.Empty;

    }
}
