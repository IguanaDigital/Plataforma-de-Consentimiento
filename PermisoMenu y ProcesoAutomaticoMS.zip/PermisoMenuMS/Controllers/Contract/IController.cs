﻿
using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.PermisoMenuMS.Controllers.Dto;

namespace ReyBanPac.PermisoMenuMS.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<Object>> ConsultarMenu([FromQuery] string Usuario);

        public Task<ActionResult<Object>> ConsultarMenuLogin([FromQuery] string Usuario);

        public Task<ActionResult<Object>> ConsultarPermisoMenu([FromQuery]string Usuario, [FromQuery] string Url);

    }
}
