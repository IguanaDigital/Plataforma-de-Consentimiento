﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;
using System.Diagnostics;
using System.Text.Json.Serialization;

namespace ReyBanPac.PermisoMenuMS.Controllers.Dto
{
    public class SessionWebType
    {
        [JsonPropertyName("menu")]
        public List<MenuItemType>? Menu { get; set; }

        [JsonPropertyName("permiso")]
        public List<PermisoMenuType>? Permiso { get; set; }

        public SessionWebType()
        {
            Menu = new List<MenuItemType>();
            Permiso = new List<PermisoMenuType>();
        }
    }
}
