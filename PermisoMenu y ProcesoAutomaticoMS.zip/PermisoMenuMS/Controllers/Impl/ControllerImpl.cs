﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.PermisoMenuMS.Constans;
using ReyBanPac.PermisoMenuMS.Controllers.Contract;
using ReyBanPac.PermisoMenuMS.Controllers.Dto;
using ReyBanPac.PermisoMenuMS.Service.Contract;
using System.Reflection;

namespace ReyBanPac.PermisoMenuMS.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;

        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger)
        {
            Svc = Servicio;
            _logger = logger;
        }

        [HttpPost("consulta")]
        [ProducesResponseType(typeof(MenuItemType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarMenu([FromQuery] string Usuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                List<MenuItemType> EntityType;
                EntityType = await Svc.ConsultarMenu(Usuario);
                return Ok(EntityType);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpPost("login")]
        [ProducesResponseType(typeof(MenuItemType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarMenuLogin([FromQuery] string Usuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                SessionWebType EntityType;
                EntityType = await Svc.ConsultarMenuLogin(Usuario);
                return Ok(EntityType);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpPost("permiso")]
        [ProducesResponseType(typeof(PermisoMenuType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarPermisoMenu([FromQuery] string Usuario, [FromQuery]  string Url)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                PermisoMenuType EntityType;
                EntityType = await Svc.ConsultarPermisoMenu(Usuario, Url);
                return Ok(EntityType);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

    }
}
