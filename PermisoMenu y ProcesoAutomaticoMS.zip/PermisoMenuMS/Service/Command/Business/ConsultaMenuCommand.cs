﻿using Microsoft.Identity.Client;
using ReyBanPac.PermisoMenuMS.Constans;
using ReyBanPac.PermisoMenuMS.Utils;
using System.Reflection;
using System.Text.Json;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.PermisoMenuMS.Service.Command.Business
{
    public class ConsultaMenuCommand
    {
        private readonly ILogger<ConsultaMenuCommand> _logger;
        public ConsultaMenuCommand(ILogger<ConsultaMenuCommand> logger)
        {
            _logger = logger;
        }


        public async Task<string> ExecuteAsync()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");

            // Ruta al archivo JSON
            string rutaArchivo = "Menu.json";
            try
            {

                // Lee el contenido del archivo JSON
                return await File.ReadAllTextAsync(rutaArchivo);
            }
            catch (FileNotFoundException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} El archivo JSON no se encontró.");
                throw new ServiceException("El archivo JSON no se encontró.") ;
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error al leer el archivo JSON.");
                throw new ServiceException("Error al leer el archivo JSON.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
