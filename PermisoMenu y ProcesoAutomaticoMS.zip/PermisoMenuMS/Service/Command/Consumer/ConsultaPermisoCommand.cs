﻿using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.PermisoMenuMS.Constans;
using ReyBanPac.PermisoMenuMS.Utils;
using System.Reflection;
using System.Text.Json;

namespace ReyBanPac.PermisoMenuMS.Service.Command
{
    public class ConsultaPermisoCommand
    {
        private readonly ILogger<ConsultaPermisoCommand> _logger;
        private readonly Provider Provider;
        public ConsultaPermisoCommand(Provider _provider, ILogger<ConsultaPermisoCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string Usuario)
        {
            //_logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");

            //// Ruta al archivo JSON
            //string rutaArchivo = "Permiso.json";
            //try
            //{

            //    // Lee el contenido del archivo JSON
            //    return await File.ReadAllTextAsync(rutaArchivo);
            //}
            //catch (FileNotFoundException ex)
            //{
            //    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} El archivo JSON no se encontró.");
            //    throw new ServiceException("El archivo JSON no se encontró.");
            //}
            //catch (JsonException ex)
            //{
            //    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error al leer el archivo JSON.");
            //    throw new ServiceException("Error al leer el archivo JSON.");
            //}
            //catch (Exception ex)
            //{
            //    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
            //    throw;
            //}
            //finally
            //{
            //    _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            //}

            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {

                using (var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient()))
                {
                    client.Timeout = TimeSpan.FromMinutes(5);
                    var Url = string.Concat(Provider.HostApi, Provider.Api.CONSULTAR_PERMISO_MENU.Replace("{Usuario}", Usuario));

                    var Response = await client.GetAsync(Url);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible para consultar token");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
