﻿using ReyBanPac.PermisoMenuMS.Constans;
using ReyBanPac.PermisoMenuMS.Utils;
using System.Reflection;
using System.Reflection.Metadata;
using System.Text;
using System.Text.Json;
using System.Web;

namespace ReyBanPac.PermisoMenuMS.Service.Command
{
    public class ConsultaPermisoMenuCommand
    {
        private readonly ILogger<ConsultaPermisoMenuCommand> _logger;
        private readonly Provider Provider;
        public ConsultaPermisoMenuCommand(Provider _provider, ILogger<ConsultaPermisoMenuCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string Usuario, string Path)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {

                using (var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient()))
                {
                    var Content = new StringContent("{}", Encoding.UTF8, "application/json");
                    var Url = string.Concat(Provider.HostApi, Provider.Api.CONSULTAR_PERMISO, $"?Usuario={Usuario}&Path={Path}");
                    var Response = await client.PostAsync(Url, Content);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible para consultar token");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
