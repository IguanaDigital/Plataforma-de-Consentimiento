﻿
using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.PermisoMenuMS.Controllers.Dto;

namespace ReyBanPac.PermisoMenuMS.Service.Contract
{
    public interface IService
    {
        public Task<List<MenuItemType>> ConsultarMenu(string Usuario);

        public  Task<SessionWebType> ConsultarMenuLogin(string Usuario);

        public Task<PermisoMenuType> ConsultarPermisoMenu(string Usuario, string Url);


    }
}
