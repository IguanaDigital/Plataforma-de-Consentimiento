﻿using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.PermisoMenuMS.Constans;
using ReyBanPac.PermisoMenuMS.Controllers.Dto;
using ReyBanPac.PermisoMenuMS.Service.Command;
using ReyBanPac.PermisoMenuMS.Service.Command.Business;
using ReyBanPac.PermisoMenuMS.Service.Contract;
using System.Reflection;
using System.Text.Json;

namespace ReyBanPac.PermisoMenuMS.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly ConsultaMenuCommand _consultaMenuCommand;
        private readonly ConsultaPermisoCommand _consultaPermisoCommand;
        private readonly ConsultaPermisoMenuCommand _consultaPermisoMenuCommand;
        public ServiceImpl(ILogger<ServiceImpl> logger, ConsultaMenuCommand consultaMenuCommand, ConsultaPermisoCommand consultaPermisoCommand, ConsultaPermisoMenuCommand consultaPermisoMenuCommand)
        {
            _logger = logger;
            _consultaMenuCommand = consultaMenuCommand;
            _consultaPermisoCommand = consultaPermisoCommand;
            _consultaPermisoMenuCommand = consultaPermisoMenuCommand;
        }

        public async Task<List<MenuItemType>> ConsultarMenu(string Usuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                #region Consumir servicio Menu
                List<MenuType> Menus = null;
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");
                try
                {
                    //Consumir servicio para obtener la informacion
                    var JsonMenu = await _consultaMenuCommand.ExecuteAsync();

                    //Mapping 
                    Menus = JsonSerializer.Deserialize<List<MenuType>>(JsonMenu);

                    //Valida
                    if (Menus == null || (Menus != null && Menus.Count == 0))
                    {
                        throw new ServiceException("No hay menus en el archivo de json") { Codigo = StatusCodes.Status400BadRequest };
                    }
                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                    throw;
                }
                finally
                {
                    _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
                }
                #endregion

                #region Consumir Permiso
                List<PermisoMenuType> Permisos = null;
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");
                try
                {
                    //Consumir servicio para obtener la informacion
                    var JsonPermiso = await _consultaPermisoCommand.ExecuteAsync(Usuario);

                    //Mapping 
                    Permisos = JsonSerializer.Deserialize<List<PermisoMenuType>>(JsonPermiso);

                    //Valida
                    if (Permisos == null || (Permisos != null && Permisos.Count == 0))
                    {
                        throw new ServiceException("No existen permsios para el usuario actual") { Codigo = StatusCodes.Status400BadRequest };
                    }

                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                }
                finally
                {
                    _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
                }
                #endregion


                #region Unificar Menu y Permisos
                List<MenuItemType> ListPermisosMenu = new();

                //Nivel 1
                foreach (var xNivel1 in Menus)
                {
                    var Permiso = Permisos.FirstOrDefault(x => x.Codigo == xNivel1.Codigo);

                    if (Permiso != null &&  !string.IsNullOrEmpty(Permiso.Codigo) && Permiso.Visualizar)
                    {
                        MenuItemType PNivel1 = new MenuItemType();

                        PNivel1.Path = xNivel1.URL;
                        PNivel1.Title = xNivel1.Nombre;
                        PNivel1.Icon = xNivel1.Icono;
                        PNivel1.Class = "";
                        PNivel1.Label = "";
                        PNivel1.LabelClass = "";
                        PNivel1.Extralink = false;
                        PNivel1.Submenu = new();

                        //Nivel 2

                        foreach (var xNivel2 in xNivel1.Submenu)
                        {
                            var Permiso2 = Permisos.FirstOrDefault(x => x.Codigo == xNivel2.Codigo);

                            if (Permiso2 != null && !string.IsNullOrEmpty(Permiso2.Codigo) && Permiso2.Visualizar)
                            {
                                PNivel1.Class = "has-arrow";
                                PNivel1.LabelClass = "side-badge badge badge-pill text-white bg-amarillo";

                                MenuItemType PNivel2 = new MenuItemType();

                                PNivel2.Path = xNivel2.URL;
                                PNivel2.Title = xNivel2.Nombre;
                                PNivel2.Icon = "";
                                PNivel2.Class = "";
                                PNivel2.Label = "";
                                PNivel2.LabelClass = "";
                                PNivel2.Extralink = false;
                                PNivel2.Submenu = new();

                                //Nivel 3

                                foreach (var xNivel3 in xNivel2.Submenu)
                                {
                                    var Permiso3 = Permisos.FirstOrDefault(x => x.Codigo == xNivel3.Codigo);

                                    if (Permiso3 != null && !string.IsNullOrEmpty(Permiso3.Codigo) && Permiso3.Visualizar)
                                    {
                                        PNivel2.Class = "has-arrow";
                                        PNivel2.LabelClass = "side-badge badge badge-pill text-white bg-amarillo";

                                        MenuItemType PNivel3 = new MenuItemType();

                                        PNivel3.Path = xNivel3.URL;
                                        PNivel3.Title = xNivel3.Nombre;
                                        PNivel3.Icon = "";
                                        PNivel3.Class = "";
                                        PNivel3.Label = "";
                                        PNivel3.LabelClass = "";
                                        PNivel3.Extralink = false;
                                        PNivel3.Submenu = new();

                                        PNivel2.Submenu.Add(PNivel3);
                                    }
                                }

                                PNivel1.Submenu.Add(PNivel2);
                            }
                        }

                        ListPermisosMenu.Add(PNivel1);
                    }
                }

                #endregion


                return ListPermisosMenu;
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }


        public async Task<SessionWebType> ConsultarMenuLogin(string Usuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                #region Consumir servicio Menu
                List<MenuType> Menus = null;
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");
                try
                {
                    //Consumir servicio para obtener la informacion
                    var JsonMenu = await _consultaMenuCommand.ExecuteAsync();

                    //Mapping 
                    Menus = JsonSerializer.Deserialize<List<MenuType>>(JsonMenu);

                    //Valida
                    if (Menus == null || (Menus != null && Menus.Count == 0))
                    {
                        throw new ServiceException("No hay menus en el archivo de json") { Codigo = StatusCodes.Status400BadRequest };
                    }
                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                    throw;
                }
                finally
                {
                    _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
                }
                #endregion

                #region Consumir Permiso
                List<PermisoMenuType> Permisos = null;
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");
                try
                {
                    //Consumir servicio para obtener la informacion
                    var JsonPermiso = await _consultaPermisoCommand.ExecuteAsync(Usuario);

                    //Mapping 
                    Permisos = JsonSerializer.Deserialize<List<PermisoMenuType>>(JsonPermiso);

                    //Valida
                    if (Permisos == null || (Permisos != null && Permisos.Count == 0))
                    {
                        throw new ServiceException("No existen permsios para el usuario actual") { Codigo = StatusCodes.Status400BadRequest };
                    }

                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                }
                finally
                {
                    _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
                }
                #endregion


                #region Unificar Menu y Permisos
                List<MenuItemType> ListPermisosMenu = new();

                //Nivel 1
                foreach (var xNivel1 in Menus)
                {
                    var Permiso = Permisos.FirstOrDefault(x => x.Codigo == xNivel1.Codigo);

                    if (Permiso != null && !string.IsNullOrEmpty(Permiso.Codigo) && Permiso.Visualizar)
                    {
                        MenuItemType PNivel1 = new MenuItemType();

                        PNivel1.Path = xNivel1.URL;
                        PNivel1.Title = xNivel1.Nombre;
                        PNivel1.Icon = xNivel1.Icono;
                        PNivel1.Class = "";
                        PNivel1.Label = "";
                        PNivel1.LabelClass = "";
                        PNivel1.Extralink = false;
                        PNivel1.Submenu = new();

                        //Nivel 2

                        foreach (var xNivel2 in xNivel1.Submenu)
                        {
                            var Permiso2 = Permisos.FirstOrDefault(x => x.Codigo == xNivel2.Codigo);

                            if (Permiso2 != null && !string.IsNullOrEmpty(Permiso2.Codigo) && Permiso2.Visualizar)
                            {
                                PNivel1.Class = "has-arrow";
                                PNivel1.LabelClass = "side-badge badge badge-pill text-white bg-amarillo";

                                MenuItemType PNivel2 = new MenuItemType();

                                PNivel2.Path = xNivel2.URL;
                                PNivel2.Title = xNivel2.Nombre;
                                PNivel2.Icon = "";
                                PNivel2.Class = "";
                                PNivel2.Label = "";
                                PNivel2.LabelClass = "";
                                PNivel2.Extralink = false;
                                PNivel2.Submenu = new();

                                //Nivel 3

                                foreach (var xNivel3 in xNivel2.Submenu)
                                {
                                    var Permiso3 = Permisos.FirstOrDefault(x => x.Codigo == xNivel3.Codigo);

                                    if (Permiso3 != null && !string.IsNullOrEmpty(Permiso3.Codigo) && Permiso3.Visualizar)
                                    {
                                        PNivel2.Class = "has-arrow";
                                        PNivel2.LabelClass = "side-badge badge badge-pill text-white bg-amarillo";

                                        MenuItemType PNivel3 = new MenuItemType();

                                        PNivel3.Path = xNivel3.URL;
                                        PNivel3.Title = xNivel3.Nombre;
                                        PNivel3.Icon = "";
                                        PNivel3.Class = "";
                                        PNivel3.Label = "";
                                        PNivel3.LabelClass = "";
                                        PNivel3.Extralink = false;
                                        PNivel3.Submenu = new();

                                        PNivel2.Submenu.Add(PNivel3);
                                    }
                                }

                                PNivel1.Submenu.Add(PNivel2);
                            }
                        }

                        ListPermisosMenu.Add(PNivel1);
                    }
                }

                #endregion


                SessionWebType PemisosType = new SessionWebType();
                PemisosType.Menu = ListPermisosMenu;
                PemisosType.Permiso = Permisos;
                return PemisosType;
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }

        public async Task<PermisoMenuType> ConsultarPermisoMenu(string Usuario, string Url)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                #region Consumir servicio Menu
                //List<MenuType> Menus = null;
                //_logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");
                //try
                //{
                //    //Consumir servicio para obtener la informacion
                //    var JsonMenu = await _consultaMenuCommand.ExecuteAsync();

                //    //Mapping 
                //    Menus = JsonSerializer.Deserialize<List<MenuType>>(JsonMenu);

                //    //Valida
                //    if (Menus == null || (Menus != null && Menus.Count == 0))
                //    {
                //        throw new ServiceException("00044") { Codigo = StatusCodes.Status400BadRequest };
                //    }
                //}
                //catch (ServiceException ex)
                //{
                //    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                //    throw;
                //}
                //finally
                //{
                //    _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
                //}
                #endregion

                #region Consumir Permiso
                PermisoMenuType Permiso = null;
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");
                try
                {
                    //Consumir servicio para obtener la informacion
                    var JsonPermiso = await _consultaPermisoMenuCommand.ExecuteAsync(Usuario,Url);

                    //Mapping 
                    Permiso = JsonSerializer.Deserialize<PermisoMenuType>(JsonPermiso);

                    //Valida
                    if (Permiso == null )
                    {
                        throw new ServiceException("No se encontro el permiso") { Codigo = StatusCodes.Status400BadRequest };
                    }

                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                }
                finally
                {
                    _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
                }
                #endregion


                //#region Unificar Menu y Permisos
                //List<PermisoMenuType> ListPermisosMenu = new();

                //foreach (var Menu in Menus)
                //{


                //    PermisoMenuType PermisoMenu = new();
                //    PermisoMenu.Codigo = Permiso.Codigo;
                //    PermisoMenu.Nombre = Menu.Nombre;
                //    PermisoMenu.Visualizar = Permiso.Visualizar;
                //    PermisoMenu.Nuevo = Permiso.Nuevo;
                //    PermisoMenu.Modificar = Permiso.Modificar;
                //    PermisoMenu.Eliminar = Permiso.Eliminar;
                //    PermisoMenu.Exportar = Permiso.Exportar;
                //    PermisoMenu.Consulta = Permiso.Consulta;
                //    PermisoMenu.Procesar = Permiso.Procesar;
                //    ListPermisosMenu.Add(PermisoMenu);
                //}


                //#endregion

                return Permiso;
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }

    }
}
