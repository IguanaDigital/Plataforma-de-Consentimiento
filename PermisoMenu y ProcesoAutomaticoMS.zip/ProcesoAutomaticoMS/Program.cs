using Microsoft.OpenApi.Models;
using reybanpac.procesoautomaticoms.constans;
using reybanpac.procesoautomaticoms.controllers.contract;
using reybanpac.procesoautomaticoms.controllers.impl;
using reybanpac.procesoautomaticoms.service.command.business;
using reybanpac.procesoautomaticoms.service.command.consumer;
using reybanpac.procesoautomaticoms.service.contract;
using reybanpac.procesoautomaticoms.service.impl;
using reybanpac.procesoautomaticoms.utils;

var builder = WebApplication.CreateBuilder(args);

#region Cors

// Configurar la politica CORS con la configuracion cargada
builder.Services.AddCors(options =>
{
    options.AddPolicy("NUXT", builder =>
    {
        builder.AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader();
    });
});
#endregion
/*
#region Autenticacion

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = api.Ambiente.Issuer,

            ValidateAudience = true,
            ValidAudience = api.Ambiente.Audience,

            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(api.Ambiente.Secret)),

            //ValidateLifetime = true,
            //ClockSkew = TimeSpan.Zero
        };
    });
#endregion
*/

#region Logger File

var DirLogs = builder.Configuration.GetSection("Parametros:DirLogs").Value;
builder.Logging.AddFile($"{DirLogs}Logs_{General.Nombre_Servicio}{General.Tipo_Servicio}-{{Date}}.txt");

#endregion
builder.Services.AddScoped<IController, ControllerImpl>();
builder.Services.AddScoped<IService, ServiceImpl>();

// INYECTAMOS LOS COMANDOS DESDE EL SINGLETON PARA TENER SOLO UNA INSTANCIA
builder.Services.AddTransient<ConsultaProcesoCommand>();
builder.Services.AddTransient<EjecutaProcesoCommand>();
builder.Services.AddTransient<ConsultaServicioCommand>();
builder.Services.AddHostedService<ProcesoAutomaticoCommand>();
builder.Services.AddSingleton<Provider>();


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = General.Nombre_Servicio + "-" + General.Tipo_Servicio, Version = "v1" });

});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsProduction())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", General.Nombre_Servicio + "-" + General.Tipo_Servicio + " v1");
    });
}

app.UseCors("NUXT");

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
