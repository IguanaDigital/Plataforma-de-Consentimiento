﻿namespace reybanpac.procesoautomaticoms.constans
{
    public static class Constants
    {
        public const string FormatoFecha = "MM/dd/yyyy";
    }
}
