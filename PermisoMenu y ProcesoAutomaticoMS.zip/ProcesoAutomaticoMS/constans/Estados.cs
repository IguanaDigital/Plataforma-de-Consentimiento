﻿namespace reybanpac.procesoautomaticoms.constans
{

    public enum Frecuencias1
    {
        Diaria = 1,
        Semanal = 2,
        Mensual = 3
    }
}
