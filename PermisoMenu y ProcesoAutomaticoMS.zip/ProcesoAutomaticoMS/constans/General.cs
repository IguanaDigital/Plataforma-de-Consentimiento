﻿namespace reybanpac.procesoautomaticoms.constans
{
    public static class General
    {
        public const string Nombre_Servicio = "procesoautomatico";   //Ejemplo: ambiente, conexion, etc.                     -- Debe ser minuscula
        public const string Tipo_Servicio = "ms";           //Ejemplo: es, ms, us, ts                               -- Debe ser minuscula
    }
}
