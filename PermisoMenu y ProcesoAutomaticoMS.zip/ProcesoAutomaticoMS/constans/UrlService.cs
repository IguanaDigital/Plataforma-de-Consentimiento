﻿namespace reybanpac.procesoautomaticoms.constans
{
    public class UrlService
    {
        public string CONSULTAR_PROCESO_POR_ESTADO { get; set; }
        public string EJECUTA_PROCESO { get; set; }
        public string CONSULTAR_SERVICIO_POR_ESTADO { get; set; }

    }
}
