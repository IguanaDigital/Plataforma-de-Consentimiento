﻿using Microsoft.AspNetCore.Mvc;

namespace reybanpac.procesoautomaticoms.controllers.contract
{
    public interface IController
    {

        public Task<ActionResult> ProcesarProcesoAutomatico();


    }
}
