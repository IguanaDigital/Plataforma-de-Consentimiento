﻿using Microsoft.AspNetCore.Mvc;
using reybanpac.procesoautomaticoms.constans;
using reybanpac.procesoautomaticoms.controllers.contract;
using reybanpac.procesoautomaticoms.service.contract;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Utils;

using System.Reflection;

namespace reybanpac.procesoautomaticoms.controllers.impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;
        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger)
        {
            Svc = Servicio;
            _logger = logger;
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult> ProcesarProcesoAutomatico()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                await Svc.ProcesarProcesoAutomatico();
                return Ok("El proceso se ejecuto correctamente");
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }
    }
}
