﻿using FluentScheduler;
using reybanpac.procesoautomaticoms.constans;
using reybanpac.procesoautomaticoms.utils;
using System.Reflection;
using System.Text;

namespace reybanpac.procesoautomaticoms.service.command.business
{
   
        public class ProcesoAutomaticoCommand : IHostedService
        {
            private readonly ILogger<ProcesoAutomaticoCommand> _logger;
            private readonly Provider Provider;

            public ProcesoAutomaticoCommand(Provider _provider, ILogger<ProcesoAutomaticoCommand> logger)
            {
                _logger = logger;
                Provider = _provider;
            }

            public Task StartAsync(CancellationToken cancellationToken)
            {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Scheduler");

                //FluentScheduler
                var registry = new Registry();
                //For example let's run our method every 1 hour or 10 seconds
                registry.Schedule(async () => await SomeBackgroundTask()).ToRunNow().AndEvery(1).Minutes();

                //FluentScheduler
                JobManager.Initialize(registry);

                return Task.CompletedTask;
            }

            public Task StopAsync(CancellationToken cancellationToken)
            {
                //Needed to remove all jobs from our Job manager when our Web API is shutting down  
                JobManager.RemoveAllJobs();

            _logger.LogInformation($"{General.Nombre_Servicio}  Fin Scheduler");

                return Task.CompletedTask;
            }

            private async Task SomeBackgroundTask()
            {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Command");

                try
                {
                    #region Generar Token Temporal

                    //var claims = new[]
                    //{
                    //    new Claim(ClaimTypes.Name, "Adquirencia")
                    //};

                    //var tokenHandler = new JwtSecurityTokenHandler();
                    //var key = Encoding.ASCII.GetBytes(_api.Ambiente.Secret);
                    //var tokenDescriptor = new SecurityTokenDescriptor
                    //{
                    //    Subject = new ClaimsIdentity(claims),
                    //    Expires = DateTime.UtcNow.AddDays(1),
                    //    Issuer = _api.Ambiente.Issuer,
                    //    Audience = _api.Ambiente.Audience,
                    //    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                    //};

                    //var token = tokenHandler.CreateToken(tokenDescriptor);
                    //var TokenTemporal = tokenHandler.WriteToken(token);

                    #endregion


                    using var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient());
    #if DEBUG
                    var Url = "https://localhost:7228/api/ms/procesoautomatico";
    #else
                    var Url = string.Concat(Provider.HostApi, Provider.Api.EJECUTA_PROCESO);
    #endif
                    //if (!string.IsNullOrEmpty(TokenTemporal))
                    //    client.DefaultRequestHeaders.Add("Authorization", $"Bearer {TokenTemporal}");

                    

                    //client.DefaultRequestHeaders.Add("Sesion", JsonSerializer.Serialize(header));


                    var content = new StringContent("{}", Encoding.UTF8, "application/json");

                    await client.PostAsync(Url, content);
                }
                catch (TaskCanceledException)
                {
                _logger.LogInformation($"{General.Nombre_Servicio}  Finaliza la espera de la petición, Espera la finalización del proceso");
                }
                catch (HttpRequestException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  Error al consumir el api  {Provider.HostApi}{Provider.Api.EJECUTA_PROCESO}");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  Error interno del servidor ");
                }
                finally
                {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Command");
                }

            }
        }
    
}
