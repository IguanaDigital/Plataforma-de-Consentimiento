﻿using reybanpac.procesoautomaticoms.constans;
using reybanpac.procesoautomaticoms.utils;
using System.Reflection;

namespace reybanpac.procesoautomaticoms.service.command.consumer
{
    public class ConsultaProcesoCommand
    {
        private readonly ILogger<ConsultaProcesoCommand> _logger;

        private readonly Provider Provider;
        public ConsultaProcesoCommand(Provider _provider, ILogger<ConsultaProcesoCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Command");

            try
            {
                using var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient());
                var Url = string.Concat(Provider.HostApi, Provider.Api.CONSULTAR_PROCESO_POR_ESTADO, "A");

                var response = await client.GetAsync(Url);

                response.EnsureSuccessStatusCode();

                return await response.Content.ReadAsStringAsync();

            }

            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio} Proceso no disponible para consultar por estado A");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Command");
            }
        }
    }
}
