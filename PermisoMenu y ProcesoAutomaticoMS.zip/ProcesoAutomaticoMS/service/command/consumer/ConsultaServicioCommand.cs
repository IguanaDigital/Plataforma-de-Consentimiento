﻿using reybanpac.procesoautomaticoms.constans;
using reybanpac.procesoautomaticoms.utils;
using System.Reflection;

namespace reybanpac.procesoautomaticoms.service.command.consumer
{
    public class ConsultaServicioCommand
    {
        private readonly ILogger<ConsultaProcesoCommand> _logger;
        private readonly Provider Provider;
        public ConsultaServicioCommand(Provider _provider, ILogger<ConsultaProcesoCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(int idProceso)
        {
            _logger.LogInformation($"{General.Nombre_Servicio} Inicio Command");
            try
            {
                using var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient());
                var Url = string.Concat(Provider.HostApi, Provider.Api.CONSULTAR_SERVICIO_POR_ESTADO, idProceso);
                var response = await client.GetAsync(Url);

                response.EnsureSuccessStatusCode();

                return await response.Content.ReadAsStringAsync();

            }

            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio} Servicio for proceso {idProceso} no disponible");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio} ");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio} Fin Command");
            }
        }
    }
}
