﻿using reybanpac.procesoautomaticoms.constans;
using ReyBanPac.ModeloCanonico.Type;
using System.Reflection;
using System.Text;

namespace reybanpac.procesoautomaticoms.service.command.consumer
{
    public class EjecutaProcesoCommand
    {
        private readonly ILogger<EjecutaProcesoCommand> _logger;
        public EjecutaProcesoCommand(ILogger<EjecutaProcesoCommand> logger)
        {
            _logger = logger;

        }

        public async Task ExecuteAsync(ServicioType Service)
        {
            _logger.LogInformation($"{General.Nombre_Servicio} Inicio Command");
            try
            {
                using var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient());
                /*client.Timeout = TimeSpan.FromMinutes(5);//Se espera maximo 5 minutos para que termine de ejecutar el proceso si pasa de 5 minutos entonces solo ya no se realiza el seguimiento de la respuesta
                UtilService.AddHeaderClient(client, _headerData, Canales.Servicio);*/

                switch (Service.TipoPeticion)
                {
                    case "POST":
                        var Content = new StringContent("{}", Encoding.UTF8, "application/json");
                        await client.PostAsync(Service.Url, Content);
                        break;

                    case "GET":
                        await client.GetAsync(Service.Url);
                        break;
                }


            }
            catch (TaskCanceledException)
            {
                _logger.LogInformation($"{General.Nombre_Servicio} Finaliza la espera de la petición, Espera la finalización del proceso");
            }

            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio} Fin Command");
            }
        }
    }
}
