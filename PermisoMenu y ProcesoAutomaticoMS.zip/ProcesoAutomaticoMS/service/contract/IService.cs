﻿namespace reybanpac.procesoautomaticoms.service.contract
{
    public interface IService
    {
        public Task ProcesarProcesoAutomatico();
    }
}
