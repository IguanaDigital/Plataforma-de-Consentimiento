﻿using Newtonsoft.Json;
using reybanpac.procesoautomaticoms.constans;
using reybanpac.procesoautomaticoms.service.command.consumer;
using reybanpac.procesoautomaticoms.service.contract;
using reybanpac.procesoautomaticoms.utils;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;


namespace reybanpac.procesoautomaticoms.service.impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly ConsultaProcesoCommand _consultaProcesoCommand;
        private readonly ConsultaServicioCommand _consultaServicioCommand;
        private readonly EjecutaProcesoCommand _ejecutaProcesoCommand;
        public ServiceImpl(
                            ILogger<ServiceImpl> logger,
                            ConsultaProcesoCommand consultaProcesoCommand, EjecutaProcesoCommand ejecutaProcesoCommand,
                            ConsultaServicioCommand consultaServicioCommand)
        {

            _logger = logger;
            _consultaProcesoCommand = consultaProcesoCommand;
            _consultaServicioCommand = consultaServicioCommand;
            _ejecutaProcesoCommand = ejecutaProcesoCommand;
        }


        public async Task ProcesarProcesoAutomatico()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {

                #region Consumir servicio Proceso
                string JsonProceso = String.Empty;
                var FullName = "ProcesarProcesoAutomatico";
                List<ProcesoType> Procesos = null;
                try
                {
                    //Consumir servicio para obtener la informacion
                    JsonProceso = await _consultaProcesoCommand.ExecuteAsync();

                    //Mapping
                    //List<ProcesoType> procesosDto = null;
                    Procesos = JsonConvert.DeserializeObject<List<ProcesoType>>(JsonProceso);
                    //Mapear Dto to Type
                    //Procesos = Converts.ConvertirListTypeToListModel(procesosDto);

                    //Valida Estado
                    if (Procesos.Count == 0)
                    {
                        _logger.LogInformation($"{General.Nombre_Servicio} {FullName} No existe procesos para ejecutar");
                    }

                    //Activo
                    Procesos = Procesos.Where(x => x.Estado == "A").ToList();

                }
                catch (ServiceException ex)//Error personalizado
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                    throw;
                }
                #endregion





                #region Analizar Proceso a ejecutar
                foreach (var ProcesoType in Procesos)
                {
                    DateTime fechaActual = DateTime.Now;

                    //Enum.TryParse<Frecuencias>(ProcesoType.Frecuencia, out Frecuencias FrecuenciaEnum);

                    switch (ProcesoType.Frecuencia)
                    {
                        case (Frecuencias.Diaria):


                            if (Util.ValidarDiaSemana(ProcesoType.DiaSemana, fechaActual) && Util.ValidarHora(ProcesoType.Hora, fechaActual))
                            {


                                await Peticion(FullName, ProcesoType);
                            }

                            break;
                        case (Frecuencias.Mensual):


                            if (Util.ValidarDiaMes(ProcesoType.DiaMes, fechaActual) && Util.ValidarHora(ProcesoType.Hora, fechaActual))
                            {
                                //Validar Feriado


                                await Peticion(FullName, ProcesoType);
                            }

                            break;
                        case (Frecuencias.Semanal):



                            if (Util.ValidarDiaSemana(ProcesoType.DiaSemana, fechaActual) && Util.ValidarHora(ProcesoType.Hora, fechaActual))
                            {


                                await Peticion(FullName, ProcesoType);
                            }

                            break;
                    }

                }
                #endregion
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }

        }

        private async Task Peticion(string FullName, ProcesoType ProcesoType)
        {
            try
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Proceso");
                var JsonServicio = await _consultaServicioCommand.ExecuteAsync(ProcesoType.Id);
                var Servicio = JsonConvert.DeserializeObject<List<ServicioType>>(JsonServicio);

                //Valida Estado
                if (Servicio.Count == 0)
                {
                    _logger.LogInformation($"{General.Nombre_Servicio}  No existe servicios para el proceso a ejecutar ");

                }

                //Activo
                Servicio = Servicio.Where(x => x.Estado == "A").ToList();

                foreach (var ServicioType in Servicio)
                {
                    try
                    {
                        _logger.LogInformation($"{General.Nombre_Servicio}  Peticion -> {ServicioType.Url}");


                        await _ejecutaProcesoCommand.ExecuteAsync(ServicioType);
                        _logger.LogInformation($"{General.Nombre_Servicio}  Proceso [{ProcesoType.Proceso}] fue ejecutado correctamente");
                    }
                    catch (TaskCanceledException)
                    {
                        _logger.LogInformation($"{General.Nombre_Servicio}  Proceso [{ProcesoType.Proceso}] Esperar a que finalice el proceso de transferencia");

                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }
        }
    }
}
