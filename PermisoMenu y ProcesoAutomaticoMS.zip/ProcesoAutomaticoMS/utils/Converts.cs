﻿using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;

namespace reybanpac.procesoautomaticoms.utils
{
    public static class Converts
    {
        //public static ProcesoDto ConvertirModelAType(ProcesoType Model)
        //{
        //    ProcesoDto EntityDto = new ProcesoDto();
        //    if (Model != null)
        //    {
        //        EntityDto.Id = Model.Id;
        //        EntityDto.Codigo = Model.Codigo;
        //        EntityDto.Proceso = Model.Proceso;
        //        EntityDto.Frecuencia = Model.Frecuencia.ToString();
        //        EntityDto.Hora = Model.Hora;
        //        EntityDto.DiaSemana = Model.DiaSemana;
        //        EntityDto.DiaMes = Model.DiaMes;
        //        EntityDto.AplicaFeriado = Model.AplicaFeriado;
        //        EntityDto.Estado = Model.Estado;
        //    }

        //    return EntityDto;
        //}

        //public static ProcesoType ConvertirTypeAModel(ProcesoDto EntityType)
        //{
        //    ProcesoType Model = new ProcesoType();
        //    if (EntityType != null)
        //    {
        //        Model.Id = EntityType.Id;
        //        Model.Codigo = EntityType.Codigo;
        //        Model.Proceso = EntityType.Proceso;
        //        Model.Frecuencia = (Frecuencias)Enum.Parse(typeof(Frecuencias), EntityType.Frecuencia);
        //        Model.Hora = EntityType.Hora;
        //        Model.DiaSemana = EntityType.DiaSemana;
        //        Model.DiaMes = EntityType.DiaMes;
        //        Model.AplicaFeriado = EntityType.AplicaFeriado;
        //        Model.Estado = EntityType.Estado;
        //    }
        //    return Model;
        //}

        //public static List<ProcesoType> ConvertirListTypeToListModel(List<ProcesoDto> ListadoDto)
        //{
        //    List<ProcesoType> ListadoModel = new List<ProcesoType>();
        //    if (ListadoDto != null)
        //    {
        //        foreach (ProcesoDto Item in ListadoDto)
        //        {
        //            ListadoModel.Add(ConvertirTypeAModel(Item));
        //        }
        //    }
        //    return ListadoModel;
        //}

    }
}
