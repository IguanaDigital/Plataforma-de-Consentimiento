﻿using reybanpac.procesoautomaticoms.constans;
using System.Globalization;

namespace reybanpac.procesoautomaticoms.utils
{
    public static class Util
    {
        public static Boolean ValidarDiaSemana(string diaSemana, DateTime fechaActual)
        {
            string[] dias = diaSemana.Split(',');
            List<DayOfWeek> diasSemana = new List<DayOfWeek>();
            foreach (string dia in dias)
            {
                switch (dia.Trim())
                {
                    case "L":
                        diasSemana.Add(DayOfWeek.Monday);
                        break;
                    case "Ma":
                        diasSemana.Add(DayOfWeek.Tuesday);
                        break;
                    case "Mi":
                        diasSemana.Add(DayOfWeek.Wednesday);
                        break;
                    case "J":
                        diasSemana.Add(DayOfWeek.Thursday);
                        break;
                    case "V":
                        diasSemana.Add(DayOfWeek.Friday);
                        break;
                    case "S":
                        diasSemana.Add(DayOfWeek.Saturday);
                        break;
                    case "D":
                        diasSemana.Add(DayOfWeek.Sunday);
                        break;
                    default:
                        throw new InvalidOperationException("dia no valido");
                }


            }
            if (diasSemana.Contains(fechaActual.DayOfWeek))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static Boolean ValidarDiaMes(int diaMes, DateTime fechaActual)
        {
            if (diaMes == (fechaActual.Day))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public static Boolean ValidarHora(string Hora, DateTime fechaActual)
        {
            string[] horaSplit = Hora.Split(',');
            Boolean horas = false;
            foreach (var hora in horaSplit)
            {
                try
                {
                    if (!string.IsNullOrEmpty(hora.Trim()))
                    {
                        DateTime horaDateTime = DateTime.ParseExact(hora.Trim(), "HH:mm", CultureInfo.InvariantCulture);
                        Console.WriteLine(horaDateTime.ToString("hh:mm tt"));
                        DateTime ahoraSolo = new DateTime(fechaActual.Year, fechaActual.Month, fechaActual.Day, fechaActual.Hour, fechaActual.Minute, 0);

                        if (horaDateTime == ahoraSolo)
                        {
                            horas = true;
                            break;
                        }
                    }
                }
                catch (Exception)
                {
                    continue;
                }
            }
            return horas;

        }

        //public static Boolean ValidarDiaFeriado(List<DiasFeriadoType> diasFeriados, DateTime fechaActual)
        //{

        //    foreach (var dia in diasFeriados)
        //    {
        //        if (dia.FechaFeriado.ToString(Constants.FormatoFecha).Equals(fechaActual.ToString(Constants.FormatoFecha)))
        //        {
        //            return true;
        //        }

        //    }

        //    return false;


        //}
    }
}
