﻿namespace ReyBanPac.PersonaES.Constans
{
    public class UrlService
    {
        public string CONSULTAR_KEY { get; set; } = string.Empty;


    }
}
