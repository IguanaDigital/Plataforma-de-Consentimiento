﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.PersonaES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(int Id);

        public Task<ActionResult<Object>> ConsultarPorHaciendaId(string Id_Hacienda);

        public Task<ActionResult<Object>> ConsultarPorHaciendaYEncuestaId(string Id_Hacienda, int Id_Encuesta);

        public Task<ActionResult<Object>> ConsultarDashboard(string Id_Hacienda, int Id_Encuesta);

    }
}
