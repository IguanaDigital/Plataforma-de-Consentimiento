﻿using Microsoft.AspNetCore.Mvc;

using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.PersonaES.Constans;
using ReyBanPac.PersonaES.Controllers.Contract;
using ReyBanPac.PersonaES.Service.Contract;
using ReyBanPac.PersonaES.Utils;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace ReyBanPac.PersonaES.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
    //[Authorize]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;

        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger)
        {
            Svc = Servicio;
            _logger = logger;
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<PersonaType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<PersonaType> Listado = await Svc.Consultar();
                return Ok(DataValidator.ValidarResultadoConsulta(Listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("{Id}")]
        [ProducesResponseType(typeof(PersonaType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                PersonaType EntityType = await Svc.ConsultarPorId(Id);
                return Ok(DataValidator.ValidarResultadoConsulta(EntityType));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("hacienda/{Id_Hacienda}")]
        [ProducesResponseType(typeof(List<EmpleadoHaciendaType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ConsultarPorHaciendaId(string Id_Hacienda)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<EmpleadoHaciendaType> Listado = await Svc.ConsultarPorHaciendaId(Id_Hacienda);
                return Ok(DataValidator.ValidarResultadoConsulta(Listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }


        [HttpGet("encuesta/{Id_Hacienda}/{Id_Encuesta}")]
        [ProducesResponseType(typeof(List<EmpleadoEncuestaType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ConsultarPorHaciendaYEncuestaId(string Id_Hacienda, int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<EmpleadoEncuestaType> Listado = await Svc.ConsultarPorHaciendaYEncuestaId(Id_Hacienda, Id_Encuesta);
                return Ok(DataValidator.ValidarResultadoConsulta(Listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }


        [HttpGet("dashboard/{Id_Hacienda}/{Id_Encuesta}")]
        [ProducesResponseType(typeof(List<EmpleadoDashboardType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ConsultarDashboard(string Id_Hacienda, int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<EmpleadoDashboardType> Listado = await Svc.ConsultarDashboard(Id_Hacienda, Id_Encuesta);
                return Ok(DataValidator.ValidarResultadoConsulta(Listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

    }
}
