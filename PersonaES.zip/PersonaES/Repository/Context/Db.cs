﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.PersonaES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<PersonaModel> Models => Set<PersonaModel>();
        public DbSet<EmpleadoHaciendaModel> EmpleadoHaciendaModel => Set<EmpleadoHaciendaModel>();
        public DbSet<PersonaEmpresaModel> PersonaEmpresaModel => Set<PersonaEmpresaModel>();
        public DbSet<RegistroConsentimientoModel> RegistroConsentimientoModel => Set<RegistroConsentimientoModel>();
        public DbSet<PermisoDispositivoModel> PermisoDispositivoModel => Set<PermisoDispositivoModel>();
    }
}
