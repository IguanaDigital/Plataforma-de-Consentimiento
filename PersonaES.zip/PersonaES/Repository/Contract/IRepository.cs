﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.PersonaES.Repository.Contract
{
    public interface IRepository
    {
        public Task<List<PersonaModel>> Consultar();

        public Task<PersonaModel> ConsultarPorId(int Id);

        public Task<List<EmpleadoHaciendaType>> ConsultarPorHaciendaId(string Id_Hacienda);

        public Task<List<EmpleadoEncuestaType>> ConsultarPorHaciendaYEncuestaId(string Id_Hacienda, int Id_Encuesta);

        public Task<List<EmpleadoDashboardType>> ConsultarDashboard(string Id_Hacienda, int Id_Encuesta);

    }
}
