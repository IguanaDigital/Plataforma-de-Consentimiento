﻿using Microsoft.EntityFrameworkCore;

using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.PersonaES.Constans;
using ReyBanPac.PersonaES.Repository.Contract;
using ReyBanPac.PersonaES.Repository.Context;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.PersonaES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            _logger = logger;
        }

        public async Task<List<PersonaModel>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<PersonaModel> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.FindAsync(Id) ?? new PersonaModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<List<EmpleadoHaciendaType>> ConsultarPorHaciendaId(string Id_Hacienda)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await (from th in db.EmpleadoHaciendaModel
                              join p in db.Models on th.Id equals p.Id
                              where p.Estado == Estados.ACTIVO && 
                                    th.Estado == Estados.ACTIVO
                              select new EmpleadoHaciendaType
                              {
                                  Id = p.Id,
                                  Cedula = p.Cedula,
                                  Nombre = p.Nombre,
                                  Id_Hacienda = th.Id_Hacienda,
                                  Id_Zona = th.Id_Zona,
                                  Id_Empresa = th.Id_Empresa,
                                  Estado = th.Estado
                              }
                              ).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<List<EmpleadoEncuestaType>> ConsultarPorHaciendaYEncuestaId(string Id_Hacienda, int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {

                return await (from th in db.EmpleadoHaciendaModel
                              join p in db.Models on th.Id equals p.Id
                              join rc in db.RegistroConsentimientoModel.Where(c => c.Id_Encuesta == Id_Encuesta) on p.Id equals rc.Id_Persona into rcl
                              from rclj in rcl.DefaultIfEmpty()
                              where th.Id_Hacienda == Id_Hacienda &&
                                    p.Estado == Estados.ACTIVO &&
                                    th.Estado == Estados.ACTIVO
                              select new EmpleadoEncuestaType
                              {
                                  Id = p.Id,
                                  Cedula = p.Cedula,
                                  Nombre = p.Nombre,
                                  Id_Hacienda = th.Id_Hacienda,
                                  Id_Zona = th.Id_Zona,
                                  Id_Empresa = th.Id_Empresa,
                                  Estado = rclj.Estado ?? Estados.INACTIVO
                              }

                    ).ToListAsync();


            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<List<EmpleadoDashboardType>> ConsultarDashboard(string Id_Hacienda, int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {

                return await (from th in db.EmpleadoHaciendaModel
                        join p in db.Models on th.Id equals p.Id
                        join rc in db.RegistroConsentimientoModel.Where(c => c.Id_Encuesta == Id_Encuesta) on p.Id equals rc.Id_Persona into rcl
                        from rclj in rcl.DefaultIfEmpty()
                        where th.Id_Hacienda == Id_Hacienda &&
                              p.Estado == Estados.ACTIVO &&
                              th.Estado == Estados.ACTIVO
                        select new EmpleadoDashboardType
                        {
                            Id = p.Id,
                            Cedula = p.Cedula,
                            Nombre = p.Nombre,
                            Id_Hacienda = th.Id_Hacienda,
                            Id_Zona = th.Id_Zona,
                            Id_Empresa = th.Id_Empresa,
                            Estado_Aceptacion = rclj.Aceptado?"S":"N",
                            Estado_Proceso = ((rclj.Estado??Estados.INACTIVO) == Estados.ACTIVO || (rclj.Estado??Estados.INACTIVO) == "S")?"S":"N"
                        }

                    ).ToListAsync();


            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

    }
}
