﻿using ReyBanPac.PersonaES.Constans;
using ReyBanPac.PersonaES.Utils;

using ReyBanPac.ModeloCanonico.Utils;

namespace integracionlegadous.service.command
{
    public class ConsultarKeyCommand
    {
        private readonly ILogger<ConsultarKeyCommand> _logger;
        private readonly Provider Provider;
        public ConsultarKeyCommand(Provider _provider, ILogger<ConsultarKeyCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Command");
            try
            {
                
                using (var client = new HttpClient(Utils.OffSSLClient()))
                {
                    var Url = string.Concat(Provider.HostApi, Provider.Api.CONSULTAR_KEY);

                    var Response = await client.GetAsync(Url);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Servicio no disponible para consultar token");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Command");
            }
        }
    }
}
