﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.PersonaES.Service.Contract
{
    public interface IService
    {
        public Task<List<PersonaType>> Consultar();

        public Task<PersonaType> ConsultarPorId(int Id);

        public Task<List<EmpleadoHaciendaType>> ConsultarPorHaciendaId(string Id_Hacienda);

        public Task<List<EmpleadoEncuestaType>> ConsultarPorHaciendaYEncuestaId(string Id_Hacienda, int Id_Encuesta);

        public Task<List<EmpleadoDashboardType>> ConsultarDashboard(string Id_Hacienda, int Id_Encuesta);

    }
}
