﻿
using System.Text.Json;
using integracionlegadous.service.command;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.PersonaES.Constans;
using ReyBanPac.PersonaES.Repository.Contract;
using ReyBanPac.PersonaES.Service.Contract;
using ReyBanPac.PersonaES.Utils;

namespace ReyBanPac.PersonaES.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository Repository;
        private readonly ConsultarKeyCommand _consultarKeyCommand;

        public ServiceImpl(IRepository repositorio, ILogger<ServiceImpl> logger, ConsultarKeyCommand consultarKeyCommand)
        {
            Repository = repositorio;
            _logger = logger;
            _consultarKeyCommand = consultarKeyCommand;
        }

        public async Task<List<PersonaType>> Consultar()
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                List<PersonaModel> ListadoModel = await Repository.Consultar();

                return Converts.ConvertirListModelToListType(ListadoModel,await ConsultarKey());
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }


        }

        public async Task<PersonaType> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                PersonaModel EntityModel = await Repository.ConsultarPorId(Id);

                return Converts.ConvertirModelAType(EntityModel, await ConsultarKey());
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }

        }

        public async Task<List<EmpleadoHaciendaType>> ConsultarPorHaciendaId(string Id_Hacienda)
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                List<EmpleadoHaciendaType> EntityType = await Repository.ConsultarPorHaciendaId(Id_Hacienda);


                return Converts.ConvertirListModelToListType(EntityType, await ConsultarKey());
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }


        }

        public async Task<List<EmpleadoEncuestaType>> ConsultarPorHaciendaYEncuestaId(string Id_Hacienda, int Id_Encuesta)
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {

                List<EmpleadoEncuestaType> EntityType = await Repository.ConsultarPorHaciendaYEncuestaId(Id_Hacienda, Id_Encuesta);


                return Converts.ConvertirListModelToListType(EntityType, await ConsultarKey());
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }


        }

        public async Task<List<EmpleadoDashboardType>> ConsultarDashboard(string Id_Hacienda, int Id_Encuesta)
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {

                List<EmpleadoDashboardType> EntityType = await Repository.ConsultarDashboard(Id_Hacienda, Id_Encuesta);


                return Converts.ConvertirListModelToListType(EntityType, await ConsultarKey());
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }


        }

        private async Task<string> ConsultarKey()
        {
            //Declara Variables
            CredencialType CredencialType = new CredencialType();

            try
            {

                //Consumir servicio para obtener el key
                string JsonKey = await _consultarKeyCommand.ExecuteAsync();

                //Mapping 
                CredencialType = JsonSerializer.Deserialize<CredencialType>(JsonKey);

                //Valida
                if (CredencialType == null || string.IsNullOrEmpty(CredencialType.Pass))
                {
                    throw new ServiceException("No hay Key") { Codigo = StatusCodes.Status400BadRequest };
                }

                return ModeloCanonico.Utils.Utils.Base64Decode(CredencialType.Pass);

            }
            catch (ServiceException ex) //Error personalizado
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }

        }

    }
}
