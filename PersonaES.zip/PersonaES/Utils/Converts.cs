﻿
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.PersonaES.Utils
{
    public static class Converts
    {
        public static PersonaType ConvertirModelAType(PersonaModel Model, string Key)
        {
            return new PersonaType
            {
                Id = Model.Id,
                Cedula = ReyBanPac.ModeloCanonico.Utils.Utils.Base64Encode(Security.CryptoAes.Descifrar(Model.Cedula, Key)),
                Nombre = ReyBanPac.ModeloCanonico.Utils.Utils.Base64Encode(Security.CryptoAes.Descifrar(Model.Nombre, Key)),
                Subledger = Model.Subledger,
                Correo = Model.Correo,
                Telefono = Model.Telefono
            };
        }
        
        public static List<PersonaType> ConvertirListModelToListType(List<PersonaModel> ListadoModel,string Key)
        {
            return ListadoModel.ConvertAll(listadoModel => ConvertirModelAType(listadoModel,Key));
        }

        public static EmpleadoHaciendaType ConvertirModelAType(EmpleadoHaciendaType Type, string Key)
        {
            return new EmpleadoHaciendaType
            {
                Id = Type.Id,
                Cedula = ReyBanPac.ModeloCanonico.Utils.Utils.Base64Encode(Security.CryptoAes.Descifrar(Type.Cedula, Key)),
                Nombre = ReyBanPac.ModeloCanonico.Utils.Utils.Base64Encode(Security.CryptoAes.Descifrar(Type.Nombre, Key)),
                Id_Hacienda = Type.Id_Hacienda,
                Id_Zona = Type.Id_Zona,
                Id_Empresa = Type.Id_Empresa,
                Estado = Type.Estado
            };
        }

        public static List<EmpleadoHaciendaType> ConvertirListModelToListType(List<EmpleadoHaciendaType> ListadoModel, string Key)
        {
            return ListadoModel.ConvertAll(listadoModel => ConvertirModelAType(listadoModel,Key));
        }
        
        public static EmpleadoEncuestaType ConvertirModelAType(EmpleadoEncuestaType Type, string Key)
        {
            return new EmpleadoEncuestaType
            {
                Id = Type.Id,
                Cedula = ReyBanPac.ModeloCanonico.Utils.Utils.Base64Encode(Security.CryptoAes.Descifrar(Type.Cedula, Key)),
                Nombre = ReyBanPac.ModeloCanonico.Utils.Utils.Base64Encode(Security.CryptoAes.Descifrar(Type.Nombre, Key)),
                Id_Hacienda = Type.Id_Hacienda,
                Id_Zona = Type.Id_Zona,
                Id_Empresa = Type.Id_Empresa,
                Estado = Type.Estado
            };
        }

        public static List<EmpleadoEncuestaType> ConvertirListModelToListType(List<EmpleadoEncuestaType> ListadoModel, string Key)
        {
            return ListadoModel.ConvertAll(listadoModel => ConvertirModelAType(listadoModel,Key));
        }


        public static EmpleadoDashboardType ConvertirModelAType(EmpleadoDashboardType Type, string Key)
        {
            return new EmpleadoDashboardType
            {
                Id = Type.Id,
                Cedula = ReyBanPac.ModeloCanonico.Utils.Utils.Base64Encode(Security.CryptoAes.Descifrar(Type.Cedula, Key)),
                Nombre = ReyBanPac.ModeloCanonico.Utils.Utils.Base64Encode(Security.CryptoAes.Descifrar(Type.Nombre, Key)),
                Id_Hacienda = Type.Id_Hacienda,
                Id_Zona = Type.Id_Zona,
                Id_Empresa = Type.Id_Empresa,
                Estado_Aceptacion = Type.Estado_Aceptacion,
                Estado_Proceso = Type.Estado_Proceso
            };
        }

        public static List<EmpleadoDashboardType> ConvertirListModelToListType(List<EmpleadoDashboardType> ListadoModel, string Key)
        {
            return ListadoModel.ConvertAll(listadoModel => ConvertirModelAType(listadoModel, Key));
        }
    }
}
