﻿namespace ReyBanPac.PlantillaES.Constans
{
    public static class General
    {
        public const string Nombre_Servicio = "plantilla";   //Ejemplo: ambiente, conexion, etc.                     -- Debe ser minuscula
        public const string Tipo_Servicio = "es";       //Ejemplo: es, ms, us, ts                               -- Debe ser minuscula
    }
}