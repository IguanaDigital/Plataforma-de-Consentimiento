﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.PlantillaES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<object>> Guardar(PlantillaType PlantillaType);

        public Task<ActionResult<object>> Actualizar(PlantillaType PlantillaType);

        public Task<ActionResult<object>> Eliminar(int Id);

        public Task<ActionResult<object>> Consultar();

        public Task<ActionResult<object>> ConsultarPorId(int Id);



    }
}
