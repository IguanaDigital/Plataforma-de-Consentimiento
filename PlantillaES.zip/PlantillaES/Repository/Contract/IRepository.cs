﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.PlantillaES.Repository.Contract
{
    public interface IRepository
    {
        public Task<PlantillaModel> Guardar(PlantillaModel PlantillaModel);

        public Task<PlantillaModel> Actualizar(PlantillaModel PlantillaModel);

        public Task<int> Eliminar(int Id);

        public Task<List<PlantillaModel>> Consultar();

        public Task<PlantillaModel> ConsultarPorId(int Id);

        public Task<bool> ValidarExistencia(int Id);
    }
}
