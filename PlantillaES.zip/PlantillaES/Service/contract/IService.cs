﻿using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.PlantillaES.Service.Contract
{
    public interface IService
    {
        public Task<PlantillaType> Guardar(PlantillaType PlantillaType);

        public Task<PlantillaType> Actualizar(PlantillaType PlantillaType);

        public Task<int> Eliminar(int Id);

        public Task<List<PlantillaType>> Consultar();

        public Task<PlantillaType> ConsultarPorId(int Id);

    }
}
