﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.PlantillaES.Constans;
using ReyBanPac.PlantillaES.Repository.Contract;
using ReyBanPac.PlantillaES.Service.Contract;
using ReyBanPac.PlantillaES.Utils;


namespace ReyBanPac.PlantillaES.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository Repository;

        public ServiceImpl(IRepository repositorio, ILogger<ServiceImpl> logger)
        {
            Repository = repositorio;
            _logger = logger;
        }

        public async Task<PlantillaType> Guardar(PlantillaType PlantillaType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                PlantillaModel PlantillaModel = Converts.ConvertirTypeAModel(PlantillaType);
                PlantillaModel = await Repository.Guardar(PlantillaModel);
                return Converts.ConvertirModelAType(PlantillaModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }
        }

        public async Task<PlantillaType> Actualizar(PlantillaType PlantillaType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                bool Existe = await Repository.ValidarExistencia(PlantillaType.Id);
                if (Existe)
                {
                    PlantillaModel PlantillaModel = Converts.ConvertirTypeAModel(PlantillaType);
                    PlantillaModel = await Repository.Actualizar(PlantillaModel);
                    return Converts.ConvertirModelAType(PlantillaModel);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }



        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                bool Existe = await Repository.ValidarExistencia(Id);
                if (Existe)
                {
                    return await Repository.Eliminar(Id);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }



        }

        public async Task<List<PlantillaType>> Consultar()
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                List<PlantillaModel> ListadoModel = await Repository.Consultar();
                List<PlantillaType> ListadoType = Converts.ConvertirListModelToListType(ListadoModel);
                return ListadoType;
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }


        }

        public async Task<PlantillaType> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Service");

            try
            {
                PlantillaModel PlantillaModel = await Repository.ConsultarPorId(Id);

                return Converts.ConvertirModelAType(PlantillaModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Service");
            }

        }


    }
}
