﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.PlantillaES.Utils
{
    public static class Converts
    {
        public static PlantillaType ConvertirModelAType(PlantillaModel Model)
        {
            PlantillaType PlantillaType = new PlantillaType();

            if (Model != null)
            {
                PlantillaType.Id = Model.Id;
                PlantillaType.Titulo = Model.Titulo;
                PlantillaType.Contenido = Model.Contenido;
                PlantillaType.Contenido_Video = Model.Contenido_Video;
                PlantillaType.Estado = Model.Estado;
            }

            return PlantillaType;
        }

        public static PlantillaModel ConvertirTypeAModel(PlantillaType PlantillaType)
        {
            PlantillaModel Model = new PlantillaModel();
            if (PlantillaType != null)
            {
                Model.Id = PlantillaType.Id;
                Model.Titulo = PlantillaType.Titulo;
                Model.Contenido = PlantillaType.Contenido;
                Model.Contenido_Video = PlantillaType.Contenido_Video;
                Model.Estado = PlantillaType.Estado;
            }

            return Model;
        }

        public static List<PlantillaType> ConvertirListModelToListType(List<PlantillaModel> ListadoModel)
        {
            List<PlantillaType> ListadoType = new List<PlantillaType>();
            if (ListadoModel != null)
            {
                foreach (PlantillaModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
