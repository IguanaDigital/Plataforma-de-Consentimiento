﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ProcesoES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<object>> Guardar(ProcesoType EntityType);

        public Task<ActionResult<object>> Actualizar(ProcesoType EntityType);

        public Task<ActionResult<object>> Eliminar(int Id);

        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(int Id);

        public Task<ActionResult<Object>> ConsultarPorEstado(String Estado);



    }
}
