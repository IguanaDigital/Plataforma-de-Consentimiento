﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ProcesoES.Repository.Contract
{
    public interface IRepository
    {
        public Task<ProcesoModel> Guardar(ProcesoModel EntityModel);

        public Task<ProcesoModel> Actualizar(ProcesoModel EntityModel);

        public Task<int> Eliminar(int Id);

        public Task<List<ProcesoModel>> Consultar();

        public Task<ProcesoModel> ConsultarPorId(int Id);

        public Task<List<ProcesoModel>> ConsultarPorEstado(string Estado);

        public Task<bool> ValidarExistencia(int Id);

        public Task<bool> ValidarExistencia(string Codigo);
    }
}
