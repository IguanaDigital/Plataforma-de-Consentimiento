﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ProcesoES.Service.Contract
{
    public interface IService
    {
        public Task<ProcesoType> Guardar(ProcesoType EntityType);

        public Task<ProcesoType> Actualizar(ProcesoType EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<ProcesoType>> Consultar();

        public Task<ProcesoType> ConsultarPorId(int Id);

        public Task<List<ProcesoType>> ConsultarPorEstado(string Estado);

    }
}
