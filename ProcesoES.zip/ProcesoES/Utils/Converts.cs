﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ProcesoES.Utils
{
    public static class Converts
    {
        public static ProcesoType ConvertirModelAType(ProcesoModel Model)
        {
            ProcesoType EntityType = new ProcesoType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Codigo = Model.Codigo;
                EntityType.Proceso = Model.Proceso;
                EntityType.Frecuencia = Model.Frecuencia;
                EntityType.Hora = Model.Hora;
                EntityType.DiaSemana = Model.DiaSemana;
                EntityType.DiaMes = Model.DiaMes;
                EntityType.AplicaFeriado = Model.AplicaFeriado;
                EntityType.Estado = Model.Estado;

            }

            return EntityType;
        }

        public static ProcesoModel ConvertirTypeAModel(ProcesoType EntityType)
        {
            ProcesoModel Model = new ProcesoModel();
            if (EntityType != null)
            {
                Model.Id = EntityType.Id;
                Model.Codigo = EntityType.Codigo;
                Model.Proceso = EntityType.Proceso;
                Model.Frecuencia = EntityType.Frecuencia;
                Model.Hora = EntityType.Hora;
                Model.DiaSemana = EntityType.DiaSemana;
                Model.DiaMes = EntityType.DiaMes;
                Model.AplicaFeriado = EntityType.AplicaFeriado;
                Model.Estado = EntityType.Estado;
            }

            return Model;
        }

        public static List<ProcesoType> ConvertirListModelToListType(List<ProcesoModel> ListadoModel)
        {
            List<ProcesoType> ListadoType = new List<ProcesoType>();
            if (ListadoModel != null)
            {
                foreach (ProcesoModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
