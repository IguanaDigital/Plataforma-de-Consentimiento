﻿namespace ReyBanPac.RegistroConsentimientoES.Constans
{
    public class Semilla
    {
        public string KEY { get; set; } = string.Empty;
    }
}
