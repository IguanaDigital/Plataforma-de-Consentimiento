﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.RegistroConsentimientoES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<Object>> Guardar(RegistroConsentimientoType EntityType);

        public Task<ActionResult<Object>> Actualizar(RegistroConsentimientoType EntityType);

        public Task<ActionResult<Object>> Eliminar(int Id);

        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(int Id);


        public Task<ActionResult<Object>> ConsultarRegistroConsentimientoConHaciendaPorId(int Id);


    }
}
