﻿using ReyBanPac.ModeloCanonico.Constans;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ReyBanPac.RegistroConsentimientoES.Controllers.Model
{
    public class ReporteRegistroConsentimientoType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("id_empresa")]
        public string Id_Empresa { get; set; }

        [JsonPropertyName("empresa")]
        public string Empresa { get; set; }

        [JsonPropertyName("id_persona")]
        public int Id_Persona { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; }

        [JsonPropertyName("cedula")]
        public string Cedula { get; set; }

        [JsonPropertyName("id_encuesta")]
        public int Id_Encuesta { get; set; }

        [JsonPropertyName("id_hacienda")]
        public string Id_Hacienda { get; set; }

        [JsonPropertyName("hacienda")]
        public string Hacienda { get; set; }

        [JsonPropertyName("acepto")]
        public bool Acepto { get; set; }

        [JsonPropertyName("fecha")]
        public DateTime? Fecha { get; set; }

        [JsonPropertyName("hora")]
        public string Hora { get; set; }

        [JsonPropertyName("usuario")]
        public string Usuario { get; set; }

        [JsonPropertyName("ip")]
        public string Ip { get; set; }

        [JsonPropertyName("realizado")]
        public bool Realizado { get; set; }

        [JsonPropertyName("estado"), MaxLength(1)]
        public string Estado { get; set; }

        [JsonPropertyName("dispositivo")]
        public string Dispositivo { get; set; }

        [JsonPropertyName("ubicacion")]
        public string Ubicacion { get; set; }

        public ReporteRegistroConsentimientoType()
        {

            Fecha = null;
            Hora = string.Empty;
            Usuario = string.Empty;
            Ip = string.Empty;
            Realizado = false;
            Dispositivo = string.Empty;
            Ubicacion = string.Empty;
            Estado = Estados.INACTIVO;
            Acepto = false;
            Id_Empresa = string.Empty;
            Id_Encuesta = 0;
            Empresa = string.Empty;
            Nombre = string.Empty;
            Cedula = string.Empty;
            Id_Hacienda = string.Empty;
            Hacienda = string.Empty;

        }
    }
}
