﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.RegistroConsentimientoES.Controllers.Model;

namespace ReyBanPac.RegistroConsentimientoES.Repository.Contract
{
    public interface IRepository
    {
        public Task<RegistroConsentimientoModel> Guardar(RegistroConsentimientoModel EntityModel);

        public Task<RegistroConsentimientoModel> Actualizar(RegistroConsentimientoModel EntityModel);

        public Task<int> Eliminar(int Id);

        public Task<List<RegistroConsentimientoModel>> Consultar();

        public Task<RegistroConsentimientoModel> ConsultarPorId(int Id);

        public Task<bool> ValidarExistencia(int Id);
        public Task<bool> ValidarDuplicidad(int IdEmpleado, int IdPermiso);
        public Task<RegistroConsentimientoHaciendaType> consultarRegistroConHacienda(int id);

        public Task<List<ReporteRegistroConsentimientoType>> ReporteRegistroConHacienda(int Id_Encuesta, string Id_Hacienda);

    }

    
}
