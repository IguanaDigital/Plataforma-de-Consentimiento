﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.RegistroConsentimientoES.Constans;
using ReyBanPac.RegistroConsentimientoES.Controllers.Model;
using ReyBanPac.RegistroConsentimientoES.Repository.Context;
using ReyBanPac.RegistroConsentimientoES.Repository.Contract;
using ReyBanPac.RegistroConsentimientoES.Utils;
using System.Reflection;

namespace ReyBanPac.RegistroConsentimientoES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        private readonly CredencialType _credencialTypeKey;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger,CredencialType credencialType)
        {
            this.db = dbContex;
            _logger = logger;
            _credencialTypeKey = credencialType;
        }

        public async Task<RegistroConsentimientoModel> Guardar(RegistroConsentimientoModel EntityModel)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                EntityModel.Fecha_Creacion = DateTime.Now;
                var Item = db.Models.Add(EntityModel);
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<RegistroConsentimientoModel> Actualizar(RegistroConsentimientoModel EntityModel)
        {
            try
            {
                EntityModel.Fecha_Actualizacion = DateTime.Now;
                var Item = db.Models.Add(EntityModel);
                db.Entry(EntityModel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                var Reg = await db.Models.FindAsync(Id) ?? new RegistroConsentimientoModel();
                Reg.Estado = Estados.ELIMINADO;
                Reg.Fecha_Actualizacion = DateTime.Now;
                return await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<RegistroConsentimientoModel>> Consultar()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                return await db.Models.Where(x => x.Estado != Estados.ELIMINADO).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<RegistroConsentimientoModel> ConsultarPorId(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                return await db.Models.FindAsync(Id) ?? new RegistroConsentimientoModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<bool> ValidarExistencia(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                return await db.Models.AnyAsync(item => item.Id == Id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<bool> ValidarDuplicidad(int Id_Persona, int Id_Encuesta)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                return await db.Models.AnyAsync(item => item.Id_Persona == Id_Persona && item.Id_Encuesta == Id_Encuesta);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<RegistroConsentimientoHaciendaType> consultarRegistroConHacienda(int id_Persona)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                //return await db.ModelsEmpleadoHacienda.Where(item => item.Id == id_Persona && item.Estado == Estados.ACTIVO).FirstOrDefaultAsync();
                var res =await (from r in db.Models
                           join p in db.ModelsPersona on r.Id_Persona equals p.Id
                           join h in db.ModelsEmpleadoHacienda on p.Id equals h.Id
                           where r.Id == id_Persona
                           select new RegistroConsentimientoHaciendaType
                           {
                               Id = r.Id,
                               Estado = r.Estado,
                               Fecha = r.Fecha,
                               Id_Encuesta = r.Id_Encuesta,
                               Id_Persona = r.Id_Persona,
                               Id_Haciendad = h.Id_Hacienda
                           }).FirstOrDefaultAsync();
                return res;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Repository", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<List<ReporteRegistroConsentimientoType>> ReporteRegistroConHacienda(int Id_Encuesta, string Id_Hacienda)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Repository", General.Nombre_Servicio);

            try
            {
                var Datos = await (from e in db.ModelsEmpleadoHacienda
                                   join p in db.ModelsPersona on e.Id equals p.Id
                                   join h in db.ModelsHacienda on e.Id_Hacienda equals h.Id
                                   join c in db.ModelsCompania on e.Id_Empresa equals c.Id

                                   where e.Id_Hacienda == Id_Hacienda
                                   select new
                                   {
                                       Hacienda = h.Nombre,
                                       Id_Hacienda = h.Id,
                                       p.Nombre,
                                       p.Cedula,
                                       Empresa = c.Nombre,
                                       Id_Persona = p.Id,
                                       Id_Empresa = c.Id
                                   }).ToListAsync();


                return (from d in Datos
                        join r in db.Models.Where(y => y.Id_Encuesta == Id_Encuesta) on d.Id_Persona equals r.Id_Persona into rc
                        from rcl in rc.DefaultIfEmpty()

                        select new ReporteRegistroConsentimientoType
                        {
                            Hacienda = d.Hacienda,
                            Id_Hacienda = d.Id_Hacienda,
                            Nombre = d.Nombre,
                            Cedula =d.Cedula,
                            Empresa = d.Empresa,
                            Id_Persona = d.Id_Persona,
                            Acepto = rcl == null ? false : rcl.Aceptado,
                            Fecha = rcl == null ? null : rcl.Fecha,
                            Hora = rcl == null ? string.Empty : rcl.Hora,
                            Usuario = "",
                            Ip = "",
                            Realizado = rcl == null ? false : true,
                            Estado = rcl == null ? "I" : rcl.Estado,
                            Id = rcl == null ? 0 : rcl.Id,
                            Id_Encuesta = rcl == null ? 0 : rcl.Id_Encuesta,
                            Id_Empresa = d.Id_Empresa,
                            Dispositivo = "",
                            Ubicacion = ""
                        }).ToList();



            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Repository", General.Nombre_Servicio);
            }
        }
    }
}
