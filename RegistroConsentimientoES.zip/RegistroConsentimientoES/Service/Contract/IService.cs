﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.RegistroConsentimientoES.Controllers.Model;

namespace ReyBanPac.RegistroConsentimientoES.Service.Contract
{
    public interface IService
    {
        public Task<RegistroConsentimientoType> Guardar(RegistroConsentimientoType EntityType);

        public Task<RegistroConsentimientoType> Actualizar(RegistroConsentimientoType EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<RegistroConsentimientoType>> Consultar();

        public Task<RegistroConsentimientoType> ConsultarPorId(int Id);

        public Task<RegistroConsentimientoHaciendaType> ConsultarRegistroConsentimientoConHaciendaPorId(int Id);

        public Task<List<ReporteRegistroConsentimientoType>> ReporteRegistroConHacienda(int Id_Encuesta, string Id_Hacienda);

    }
}
