﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.RegistroConsentimientoES.Controllers.Model;

namespace ReyBanPac.RegistroConsentimientoES.Utils
{
    public static class Converts
    {
        public static RegistroConsentimientoType ConvertirModelAType(RegistroConsentimientoModel Model)
        {
            RegistroConsentimientoType EntityType = new RegistroConsentimientoType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Id_Persona = Model.Id_Persona;
                EntityType.Id_Encuesta = Model.Id_Encuesta;
                EntityType.Aceptado = Model.Aceptado;
                EntityType.Latitud = Model.Latitud;
                EntityType.Longitud = Model.Longitud;
                EntityType.Fecha = Model.Fecha;
                EntityType.Hora = Model.Hora;
                EntityType.Estado = Model.Estado;
            }

            return EntityType;
        }

        public static RegistroConsentimientoModel ConvertirTypeAModel(RegistroConsentimientoType EntityType)
        {
            RegistroConsentimientoModel Model = new RegistroConsentimientoModel();
            if (EntityType != null)
            {
                Model.Id = EntityType.Id;
                Model.Id_Persona = EntityType.Id_Persona;
                Model.Id_Encuesta = EntityType.Id_Encuesta;
                Model.Aceptado = EntityType.Aceptado;
                Model.Latitud = EntityType.Latitud;
                Model.Longitud = EntityType.Longitud;
                Model.Fecha = EntityType.Fecha;
                Model.Hora = EntityType.Hora;
                Model.Estado = EntityType.Estado;
            }

            return Model;
        }

        public static List<RegistroConsentimientoType> ConvertirListModelToListType(List<RegistroConsentimientoModel> ListadoModel)
        {
            List<RegistroConsentimientoType> ListadoType = new List<RegistroConsentimientoType>();
            if (ListadoModel != null)
            {
                foreach (RegistroConsentimientoModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }

        public static ReporteRegistroConsentimientoType ConvertirTypeAType(ReporteRegistroConsentimientoType Model)
        {
            ReporteRegistroConsentimientoType EntityType = new ReporteRegistroConsentimientoType();

            if (Model != null)
            {
                EntityType.Acepto = Model.Acepto;
                EntityType.Cedula = Model.Cedula;
                EntityType.Dispositivo = Model.Dispositivo;
                EntityType.Empresa = Model.Empresa;
                EntityType.Estado = Model.Estado;
                EntityType.Fecha = Model.Fecha;
                EntityType.Hacienda = Model.Hacienda;
                EntityType.Hora = Model.Hora;
                EntityType.Id = Model.Id;
                EntityType.Id_Empresa = Model.Id_Empresa;
                EntityType.Id_Encuesta = Model.Id_Encuesta;
                EntityType.Id_Hacienda = Model.Id_Hacienda;
                EntityType.Id_Persona = Model.Id_Persona;
                EntityType.Ip = Model.Ip;
                EntityType.Nombre = Model.Nombre;
                EntityType.Realizado = Model.Realizado;
                EntityType.Ubicacion = Model.Ubicacion;
                EntityType.Usuario = Model.Usuario;

            }

            return EntityType;
        }

        public static List<ReporteRegistroConsentimientoType> ConvertirListTypelToListType(List<ReporteRegistroConsentimientoType> ListadoModel)
        {
            List<ReporteRegistroConsentimientoType> ListadoType = new List<ReporteRegistroConsentimientoType>();
            if (ListadoModel != null)
            {
                foreach (ReporteRegistroConsentimientoType Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirTypeAType(Item));
                }
            }
            return ListadoType;
        }


        public static string EnmascararDatos(string input)
        {
            if (input == null)
            {
                return null;
            }

            int longitud = input.Length;

            if (longitud <= 3)
            {
                return input; // Si la cadena es corta, no se enmascara
            }

            string primerosTresCaracteres = input.Substring(0, 3);
            string caracteresEnmascarados = new string('*', longitud - 6); // Enmascarar caracteres intermedios
            string ultimosTresCaracteres = input.Substring(longitud - 3);

            return primerosTresCaracteres + caracteresEnmascarados + ultimosTresCaracteres;
        }
    }
}
