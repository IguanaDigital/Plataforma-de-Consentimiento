﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.RegistroConsentimientoES.Constans;
using ReyBanPac.RegistroConsentimientoES.Controllers.Contract;
using ReyBanPac.RegistroConsentimientoES.Controllers.Model;
using ReyBanPac.RegistroConsentimientoES.Service.Contract;
using ReyBanPac.RegistroConsentimientoES.Utils;
using System.Reflection;

namespace ReyBanPac.RegistroConsentimientoES.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
    //[Authorize]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;

        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger)
        {
            Svc = Servicio;
            _logger = logger;
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> Guardar(RegistroConsentimientoType EntityType)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                RegistroConsentimientoType Resultado;
                Resultado = await Svc.Guardar(EntityType);
                return StatusCode(StatusCodes.Status201Created, DataValidator.ValidarResultadoByCreate(Resultado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        [HttpPut]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> Actualizar(RegistroConsentimientoType EntityType)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                RegistroConsentimientoType Resultado;
                Resultado = await Svc.Actualizar(EntityType);
                return Ok(DataValidator.ValidarResultadoByUpdate(Resultado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        [HttpDelete("{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> Eliminar(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                int ConfirmarEliminacion = 0;
                ConfirmarEliminacion = await Svc.Eliminar(Id);
                return Ok(DataValidator.ValidarResultadoByDelete(ConfirmarEliminacion));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<RegistroConsentimientoType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Consultar()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                List<RegistroConsentimientoType> Listado;
                Listado = await Svc.Consultar();
                return Ok(DataValidator.ValidarResultadoConsulta(Listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        [HttpGet("{Id}")]
        [ProducesResponseType(typeof(RegistroConsentimientoType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarPorId(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {
                RegistroConsentimientoType EntityType;
                EntityType = await Svc.ConsultarPorId(Id);
                return Ok(DataValidator.ValidarResultadoConsulta(EntityType));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }


        [HttpGet("hacienda/{Id}")]
        [ProducesResponseType(typeof(RegistroConsentimientoHaciendaType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarRegistroConsentimientoConHaciendaPorId(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            try
            {


                RegistroConsentimientoHaciendaType EntityType;
                EntityType = await Svc.ConsultarRegistroConsentimientoConHaciendaPorId(Id);
                return Ok(DataValidator.ValidarResultadoConsulta(EntityType));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Controller", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        [HttpGet("reporte/{Id_Encuesta}/{Id_Hacienda}")]
        [ProducesResponseType(typeof(List<ReporteRegistroConsentimientoType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ReporteRegistroConHacienda(int Id_Encuesta, string Id_Hacienda)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Controller", General.Nombre_Servicio);
            try
            {
                List<ReporteRegistroConsentimientoType> Listado;
                Listado = await Svc.ReporteRegistroConHacienda(Id_Encuesta, Id_Hacienda);
                return Ok(DataValidator.ValidarResultadoConsulta(Listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje: {Message}", General.Nombre_Servicio, ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Controller", General.Nombre_Servicio);
            }
        }


    }
}
