﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.RegistroConsentimientoES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<RegistroConsentimientoModel> Models => Set<RegistroConsentimientoModel>();
        public DbSet<EmpleadoHaciendaModel> ModelsEmpleadoHacienda => Set<EmpleadoHaciendaModel>();
        public DbSet<PersonaModel> ModelsPersona => Set<PersonaModel>();
        public DbSet<HaciendaModel> ModelsHacienda => Set<HaciendaModel>();
        public DbSet<CompaniaModel> ModelsCompania => Set<CompaniaModel>();

    }
}
