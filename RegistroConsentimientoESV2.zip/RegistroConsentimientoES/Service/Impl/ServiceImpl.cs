﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.RegistroConsentimientoES.Constans;
using ReyBanPac.RegistroConsentimientoES.Controllers.Model;
using ReyBanPac.RegistroConsentimientoES.Repository.Contract;
using ReyBanPac.RegistroConsentimientoES.Service.Contract;
using ReyBanPac.RegistroConsentimientoES.Utils;
using System.Reflection;

namespace ReyBanPac.RegistroConsentimientoES.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository Repository;

        public ServiceImpl(IRepository repositorio, ILogger<ServiceImpl> logger)
        {
            Repository = repositorio;
            _logger = logger;
        }

        public async Task<RegistroConsentimientoType> Guardar(RegistroConsentimientoType EntityType)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                RegistroConsentimientoModel Existe = await Repository.ValidarDuplicidad(EntityType.Id_Persona, EntityType.Id_Encuesta);
                if (Existe.Id == 0)
                {
                    RegistroConsentimientoModel EntityModel = Converts.ConvertirTypeAModel(EntityType);
                    EntityModel = await Repository.Guardar(EntityModel);
                    return Converts.ConvertirModelAType(EntityModel);
                }
                else
                {

                    _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: El registro {id} ya existe, se retorna datos en vez de insertarlo", General.Nombre_Servicio, Existe.Id);
                    return Converts.ConvertirModelAType(Existe);
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }
        }

        public async Task<RegistroConsentimientoType> Actualizar(RegistroConsentimientoType EntityType)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                bool Existe = await Repository.ValidarExistencia(EntityType.Id);
                if (Existe)
                {
                    RegistroConsentimientoModel EntityModel = Converts.ConvertirTypeAModel(EntityType);
                    EntityModel = await Repository.Actualizar(EntityModel);
                    return Converts.ConvertirModelAType(EntityModel);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }



        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                bool Existe = await Repository.ValidarExistencia(Id);
                if (Existe)
                {
                    return await Repository.Eliminar(Id);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }



        }

        public async Task<List<RegistroConsentimientoType>> Consultar()
        {

            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                List<RegistroConsentimientoModel> ListadoModel = await Repository.Consultar();
                List<RegistroConsentimientoType> ListadoType = Converts.ConvertirListModelToListType(ListadoModel);
                return ListadoType;
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }


        }

        public async Task<RegistroConsentimientoType> ConsultarPorId(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                RegistroConsentimientoModel EntityModel = await Repository.ConsultarPorId(Id);

                return Converts.ConvertirModelAType(EntityModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }

        }


        public async Task<RegistroConsentimientoHaciendaType> ConsultarRegistroConsentimientoConHaciendaPorId(int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Inicio Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");

            try
            {
                return await Repository.consultarRegistroConHacienda(Id);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: {Message}", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "", ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Metodo: {CurrentMethod} Mensaje: Fin Service", General.Nombre_Servicio, MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? "");
            }

        }

        public async Task<List<ReporteRegistroConsentimientoType>> ReporteRegistroConHacienda(int Id_Encuesta, string Id_Hacienda)
        {

            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Service", General.Nombre_Servicio);

            try
            {
                List<ReporteRegistroConsentimientoType> Resultado = await Repository.ReporteRegistroConHacienda(Id_Encuesta, Id_Hacienda);

                return Converts.ConvertirTypeAType(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje: {Message}", General.Nombre_Servicio, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Service", General.Nombre_Servicio);
            }


        }


    }
}
