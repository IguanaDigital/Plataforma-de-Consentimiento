﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ServicioES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<object>> Guardar(ServicioType EntityType);

        public Task<ActionResult<object>> Actualizar(ServicioType EntityType);

        public Task<ActionResult<object>> Eliminar(int Id);

        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(int Id);

        public Task<ActionResult<Object>> ConsultarPorIdProceso(int Id);

        public Task<ActionResult<Object>> ConsultarPorEstado(string Estado);

    }
}
