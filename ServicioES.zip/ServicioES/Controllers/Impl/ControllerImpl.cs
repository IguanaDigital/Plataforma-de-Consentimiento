﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Logging;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.ServicioES.Constans;
using ReyBanPac.ServicioES.Controllers.Contract;
using ReyBanPac.ServicioES.Service.Contract;
using ReyBanPac.ServicioES.Utils;
using System.Reflection;

namespace ReyBanPac.ServicioES.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
    ////[Authorize]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;

        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger)
        {
            Svc = Servicio;
            _logger = logger;
        }

        [HttpPost]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Guardar(ServicioType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                ServicioType Resultado;
                Resultado = await Svc.Guardar(EntityType);
                return Ok(DataValidator.ValidarResultadoByCreate(Resultado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpPut]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Actualizar(ServicioType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                ServicioType Resultado;
                Resultado = await Svc.Actualizar(EntityType);
                return Ok(DataValidator.ValidarResultadoByUpdate(Resultado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpDelete("{Id}")]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                int ConfirmarEliminacion = 0;
                ConfirmarEliminacion = await Svc.Eliminar(Id);
                return Ok(DataValidator.ValidarResultadoByDelete(ConfirmarEliminacion));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<ServicioType>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                List<ServicioType> Listado;
                Listado = await Svc.Consultar();
                return Ok(DataValidator.ValidarResultadoConsulta(Listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpGet("{Id}")]
        [ProducesResponseType(typeof(ServicioType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                ServicioType EntityType;
                EntityType = await Svc.ConsultarPorId(Id);
                return Ok(DataValidator.ValidarResultadoConsulta(EntityType));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpGet("proceso/{Id}")]
        [ProducesResponseType(typeof(List<ServicioType>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarPorIdProceso(int Id)
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                List<ServicioType> listado;
                listado = await Svc.ConsultarPorIdProceso(Id);
                return Ok(DataValidator.ValidarResultadoConsulta(listado));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpGet("estado/{Estado}")]
        [ProducesResponseType(typeof(List<ServicioType>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]

        public async Task<ActionResult<Object>> ConsultarPorEstado(String Estado)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                List<ServicioType> listado;
                listado = await Svc.ConsultarPorEstado(Estado);
                return Ok(DataValidator.ValidarResultadoConsulta(listado));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

    }
}
