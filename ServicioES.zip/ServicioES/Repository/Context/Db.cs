﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ServicioES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<ServicioModel> Models => Set<ServicioModel>();
    }
}
