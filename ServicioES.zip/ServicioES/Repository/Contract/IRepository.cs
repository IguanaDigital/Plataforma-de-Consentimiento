﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ServicioES.Repository.Contract
{
    public interface IRepository
    {
        public Task<ServicioModel> Guardar(ServicioModel EntityModel);

        public Task<ServicioModel> Actualizar(ServicioModel EntityModel);

        public Task<int> Eliminar(int Id);

        public Task<List<ServicioModel>> Consultar();

        public Task<ServicioModel> ConsultarPorId(int Id);

        public Task<List<ServicioModel>> ConsultarPorIdProceso(int Id);

        public Task<List<ServicioModel>> ConsultarPorEstado(string Estado);

        public Task<bool> ValidarExistencia(int Id);
    }
}
