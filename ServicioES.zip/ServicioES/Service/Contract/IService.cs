﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ServicioES.Service.Contract
{
    public interface IService
    {
        public Task<ServicioType> Guardar(ServicioType EntityType);

        public Task<ServicioType> Actualizar(ServicioType EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<ServicioType>> Consultar();

        public Task<ServicioType> ConsultarPorId(int Id);

        public Task<List<ServicioType>> ConsultarPorIdProceso(int Id);

        public Task<List<ServicioType>> ConsultarPorEstado(string Estado);

    }
}
