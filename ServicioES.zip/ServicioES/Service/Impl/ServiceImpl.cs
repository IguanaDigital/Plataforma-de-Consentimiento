﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.ServicioES.Constans;
using ReyBanPac.ServicioES.Repository.Contract;
using ReyBanPac.ServicioES.Service.Contract;
using ReyBanPac.ServicioES.Utils;
using System.Reflection;

namespace ReyBanPac.ServicioES.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository Repository;

        public ServiceImpl(IRepository repositorio, ILogger<ServiceImpl> logger)
        {
            Repository = repositorio;
            _logger = logger;
        }

        public async Task<ServicioType> Guardar(ServicioType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                ServicioModel EntityModel = Converts.ConvertirTypeAModel(EntityType);
                EntityModel = await Repository.Guardar(EntityModel);
                return Converts.ConvertirModelAType(EntityModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }

        public async Task<ServicioType> Actualizar(ServicioType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                bool Existe = await Repository.ValidarExistencia(EntityType.Id);
                if (Existe)
                {
                    ServicioModel EntityModel = Converts.ConvertirTypeAModel(EntityType);
                    EntityModel = await Repository.Actualizar(EntityModel);
                    return Converts.ConvertirModelAType(EntityModel);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }



        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                bool Existe = await Repository.ValidarExistencia(Id);
                if (Existe)
                {
                    return await Repository.Eliminar(Id);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }



        }

        public async Task<List<ServicioType>> Consultar()
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                List<ServicioModel> ListadoModel = await Repository.Consultar();
                List<ServicioType> ListadoType = Converts.ConvertirListModelToListType(ListadoModel);
                return ListadoType;
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }


        }

        public async Task<ServicioType> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                ServicioModel EntityModel = await Repository.ConsultarPorId(Id);

                return Converts.ConvertirModelAType(EntityModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }

        }

        public async Task<List<ServicioType>> ConsultarPorIdProceso(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                List<ServicioModel> ServicioDTO = await Repository.ConsultarPorIdProceso(Id);

                return Converts.ConvertirListModelToListType(ServicioDTO);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }

        }

        public async Task<List<ServicioType>> ConsultarPorEstado(string Estado)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                List<ServicioModel> Listado = await Repository.ConsultarPorEstado(Estado);

                return Converts.ConvertirListModelToListType(Listado);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }


        }
    }
}
