﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ServicioES.Utils
{
    public static class Converts
    {
        public static ServicioType ConvertirModelAType(ServicioModel Model)
        {
            ServicioType EntityType = new ServicioType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Url = Model.Url;
                EntityType.Id_Proceso = Model.Id_Proceso;
                EntityType.Descripcion = Model.Descripcion;
                EntityType.Estado = Model.Estado;
                EntityType.TipoPeticion = Model.TipoPeticion;

            }

            return EntityType;
        }

        public static ServicioModel ConvertirTypeAModel(ServicioType EntityType)
        {
            ServicioModel Model = new ServicioModel();
            if (EntityType != null)
            {
                Model.Id = EntityType.Id;
                Model.Url = EntityType.Url;
                Model.Id_Proceso = EntityType.Id_Proceso;
                Model.Descripcion = EntityType.Descripcion;
                Model.Estado = EntityType.Estado;
                Model.TipoPeticion = EntityType.TipoPeticion;
            }

            return Model;
        }

        public static List<ServicioType> ConvertirListModelToListType(List<ServicioModel> ListadoModel)
        {
            List<ServicioType> ListadoType = new List<ServicioType>();
            if (ListadoModel != null)
            {
                foreach (ServicioModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
