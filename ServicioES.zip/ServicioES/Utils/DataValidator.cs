﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.ServicioES.Utils
{
    public static class DataValidator
    {

        public static RespuestaType ValidarResultadoByCreate(ServicioType EntityType)
        {
            if (EntityType == null)
            {
                return new RespuestaType { Codigo = 500, Descripcion = "Error Interno en el Servidor" };
            }
            return new RespuestaType { Codigo = 201, Descripcion = "Registro creado con id: " + EntityType.Id };
        }

        public static RespuestaType ValidarResultadoByUpdate(ServicioType EntityType)
        {
            if (EntityType == null)
            {
                return new RespuestaType { Codigo = 404, Descripcion = "El registro no fue encontrado" };
            }
            return new RespuestaType { Codigo = 200, Descripcion = "El registro con id: " + EntityType.Id + " fue actualizado de forma exitosa" };
        }

        public static RespuestaType ValidarResultadoByDelete(int Confirmacion)
        {
            if (Confirmacion == 0)
            {
                return new RespuestaType { Codigo = 404, Descripcion = "El registro no fue encontrado" };
            }
            else
            {
                return new RespuestaType { Codigo = 200, Descripcion = "Registro eliminado de forma exitosa" };
            }

        }
        public static Object ValidarResultadoConsulta(List<ServicioType> Configuracion)
        {
            if (Configuracion != null)
            {
                return Configuracion;
            }
            else
            {
                return new RespuestaType { Codigo = 204, Descripcion = "No hay Contenido" };
            }
        }

        public static Object ValidarResultadoConsulta(ServicioType EntityType)
        {
            if (EntityType != null && EntityType.Id != 0)
            {
                return EntityType;
            }
            else
            {
                return new RespuestaType { Codigo = 404, Descripcion = "El registro no existe" };
            }
        }
    }
}
