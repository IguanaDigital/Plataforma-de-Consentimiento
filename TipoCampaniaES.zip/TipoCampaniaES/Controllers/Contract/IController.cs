﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.TipoCampaniaES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<object>> Guardar(TipoCampaniaType EntityType);

        public Task<ActionResult<object>> Actualizar(TipoCampaniaType EntityType);

        public Task<ActionResult<object>> Eliminar(int Id);

        public Task<ActionResult<object>> Consultar();

        public Task<ActionResult<object>> ConsultarPorId(int Id);



    }
}
