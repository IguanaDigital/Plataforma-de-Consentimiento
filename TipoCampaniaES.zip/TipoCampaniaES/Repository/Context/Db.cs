﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.TipoCampaniaES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<TipoCampaniaModel> Models => Set<TipoCampaniaModel>();
    }
}
