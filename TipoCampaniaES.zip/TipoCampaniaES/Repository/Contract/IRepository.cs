﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.TipoCampaniaES.Repository.Contract
{
    public interface IRepository
    {
        public Task<TipoCampaniaModel> Guardar(TipoCampaniaModel EntityType);

        public Task<TipoCampaniaModel> Actualizar(TipoCampaniaModel EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<TipoCampaniaModel>> Consultar();

        public Task<TipoCampaniaModel> ConsultarPorId(int Id);

        public Task<bool> ValidarExistencia(int Id);
    }
}
