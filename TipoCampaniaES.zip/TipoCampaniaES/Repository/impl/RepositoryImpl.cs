﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.TipoCampaniaES.Constans;
using ReyBanPac.TipoCampaniaES.Repository.Context;
using ReyBanPac.TipoCampaniaES.Repository.Contract;
using System.Reflection;

namespace ReyBanPac.TipoCampaniaES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            _logger = logger;
        }

        public async Task<TipoCampaniaModel> Guardar(TipoCampaniaModel EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");
            try
            {
                EntityType.Fecha_Creacion = DateTime.Now;

                var Item = db.Models.Add(EntityType);
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<TipoCampaniaModel> Actualizar(TipoCampaniaModel EntityType)
        {
            try
            {
                EntityType.Fecha_Actualizacion = DateTime.Now;
                var Item = db.Models.Add(EntityType);
                db.Entry(EntityType).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {

                var Reg = await db.Models.FindAsync(Id) ?? new TipoCampaniaModel();
                Reg.Fecha_Actualizacion = DateTime.Now;
                Reg.Estado = Estados.ELIMINADO;
                return await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<List<TipoCampaniaModel>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await db.Models.Where(x => x.Estado != Estados.ELIMINADO).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<TipoCampaniaModel> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await db.Models.FindAsync(Id) ?? new TipoCampaniaModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<bool> ValidarExistencia(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await db.Models.AnyAsync(item => item.Id == Id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

    }
}
