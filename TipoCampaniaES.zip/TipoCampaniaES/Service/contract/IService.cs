﻿using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.TipoCampaniaES.Service.Contract
{
    public interface IService
    {
        public Task<TipoCampaniaType> Guardar(TipoCampaniaType EntityType);

        public Task<TipoCampaniaType> Actualizar(TipoCampaniaType EntityType);

        public Task<int> Eliminar(int Id);

        public Task<List<TipoCampaniaType>> Consultar();

        public Task<TipoCampaniaType> ConsultarPorId(int Id);

    }
}
