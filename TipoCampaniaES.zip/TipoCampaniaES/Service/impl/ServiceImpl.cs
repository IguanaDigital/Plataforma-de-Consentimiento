﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.TipoCampaniaES.Constans;
using ReyBanPac.TipoCampaniaES.Repository.Contract;
using ReyBanPac.TipoCampaniaES.Service.Contract;
using ReyBanPac.TipoCampaniaES.Utils;
using System.Reflection;

namespace ReyBanPac.TipoCampaniaES.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly IRepository Repository;

        public ServiceImpl(IRepository repositorio, ILogger<ServiceImpl> logger)
        {
            Repository = repositorio;
            _logger = logger;
        }

        public async Task<TipoCampaniaType> Guardar(TipoCampaniaType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                TipoCampaniaModel TipoCampaniaModel = Converts.ConvertirTypeAModel(EntityType);
                TipoCampaniaModel = await Repository.Guardar(TipoCampaniaModel);
                return Converts.ConvertirModelAType(TipoCampaniaModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }

        public async Task<TipoCampaniaType> Actualizar(TipoCampaniaType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                bool Existe = await Repository.ValidarExistencia(EntityType.Id);
                if (Existe)
                {
                    TipoCampaniaModel TipoCampaniaModel = Converts.ConvertirTypeAModel(EntityType);
                    TipoCampaniaModel = await Repository.Actualizar(TipoCampaniaModel);
                    return Converts.ConvertirModelAType(TipoCampaniaModel);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }



        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                bool Existe = await Repository.ValidarExistencia(Id);
                if (Existe)
                {
                    return await Repository.Eliminar(Id);
                }
                else
                {
                    throw new ServiceException("El registro no fue encontrado") { Codigo = StatusCodes.Status404NotFound };
                }
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }



        }

        public async Task<List<TipoCampaniaType>> Consultar()
        {

            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                List<TipoCampaniaModel> ListadoModel = await Repository.Consultar();
                List<TipoCampaniaType> ListadoType = Converts.ConvertirListModelToListType(ListadoModel);
                return ListadoType;
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }


        }

        public async Task<TipoCampaniaType> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                TipoCampaniaModel TipoCampaniaModel = await Repository.ConsultarPorId(Id);

                return Converts.ConvertirModelAType(TipoCampaniaModel);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }

        }


    }
}
