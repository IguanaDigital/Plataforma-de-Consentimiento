﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.TipoCampaniaES.Utils
{
    public static class Converts
    {
        public static TipoCampaniaType ConvertirModelAType(TipoCampaniaModel Model)
        {
            TipoCampaniaType TipoCampaniaType = new TipoCampaniaType();

            if (Model != null)
            {
                TipoCampaniaType.Id = Model.Id;
                TipoCampaniaType.Nombre = Model.Nombre;
                TipoCampaniaType.Codigo = Model.Codigo;
                TipoCampaniaType.Estado = Model.Estado;
            }

            return TipoCampaniaType;
        }

        public static TipoCampaniaModel ConvertirTypeAModel(TipoCampaniaType TipoCampaniaType)
        {
            TipoCampaniaModel Model = new TipoCampaniaModel();
            if (TipoCampaniaType != null)
            {
                Model.Id = TipoCampaniaType.Id;
                Model.Nombre = TipoCampaniaType.Nombre;
                Model.Codigo = TipoCampaniaType.Codigo;
                Model.Estado = TipoCampaniaType.Estado;
            }

            return Model;
        }

        public static List<TipoCampaniaType> ConvertirListModelToListType(List<TipoCampaniaModel> ListadoModel)
        {
            List<TipoCampaniaType> ListadoType = new List<TipoCampaniaType>();
            if (ListadoModel != null)
            {
                foreach (TipoCampaniaModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
