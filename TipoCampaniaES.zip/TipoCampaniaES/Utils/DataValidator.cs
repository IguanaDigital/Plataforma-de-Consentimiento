﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.TipoCampaniaES.Utils
{
    public static class DataValidator
    {
        public static string ValidarResultadoByCreate(TipoCampaniaType TipoCampaniaType)
        {
            if (TipoCampaniaType == null)
            {
                throw new ServiceException("Error al crear el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "Registro creado con id: " + TipoCampaniaType.Id;
        }

        public static string ValidarResultadoByUpdate(TipoCampaniaType TipoCampaniaType)
        {
            if (TipoCampaniaType == null)
            {
                throw new ServiceException("Error al actualizar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "El registro con id: " + TipoCampaniaType.Id + " fue actualizado de forma exitosa";
        }

        public static string ValidarResultadoByDelete(int Confirmacion)
        {
            if (Confirmacion == 0)
            {
                throw new ServiceException("Error al eliminar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            else
            {
                return "Registro eliminado de forma exitosa";
            }

        }
        public static Object ValidarResultadoConsulta(List<TipoCampaniaType> Configuracion)
        {
            if (Configuracion != null)
            {
                return Configuracion;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }

        public static Object ValidarResultadoConsulta(TipoCampaniaType TipoCampaniaType)
        {
            if (TipoCampaniaType != null && TipoCampaniaType.Id != 0)
            {
                return TipoCampaniaType;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }
    }
}
