﻿namespace ReyBanPac.IntegracionLegadoUS.Constans
{
    public class Constan
    {
        public string COD_APP { get; set; } = string.Empty;
        public string COD_REC_DB { get; set; } = string.Empty;
        public string COD_REC_LEG { get; set; } = string.Empty;
        public string COD_REC_KEY { get; set; } = string.Empty;
        public string COD_REC_AU { get; set; } = string.Empty;

        public string ENVIRONMENT { get; set; } = string.Empty;

        public string URL_GSA_GPS { get; set; } = string.Empty;
        public string URL_SOFFID { get; set; } = string.Empty;
        public string PUERTO_URL_SOFFID { get; set; } = string.Empty;
        public string URL_GSA_WS { get; set; } = string.Empty;
        
    }
}
