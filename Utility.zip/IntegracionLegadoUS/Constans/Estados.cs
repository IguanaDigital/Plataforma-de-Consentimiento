﻿namespace ReyBanPac.IntegracionLegadoUS.Constans
{
    public static class Estados
    {
        public const string ACTIVO = "A";
        public const string INACTIVO = "I";
    }

}
