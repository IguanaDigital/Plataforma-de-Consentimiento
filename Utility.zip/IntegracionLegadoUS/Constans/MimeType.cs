﻿namespace ReyBanPac.IntegracionLegadoUS.Constans
{
    public static class MimeType
    {
        public const String JSON = "application/json";
        public const String XML = "text/xml";
    }
}
