﻿namespace ReyBanPac.IntegracionLegadoUS.Constans
{
    public class UrlService
    {
        //Securidad Legado
        public string GENERAR_TOKEN { get; set; } = string.Empty;
        public string GENERAR_VAULT { get; set; } = string.Empty;

        //Servicio Local

        public string GUARDAR_TOKEN { get; set; } = string.Empty;
        public string CONSULTAR_TOKEN { get; set; } = string.Empty;

    }
}
