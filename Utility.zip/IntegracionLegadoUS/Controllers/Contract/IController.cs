﻿using ReyBanPac.IntegracionLegadoUS.Controllers.Dto;
using Microsoft.AspNetCore.Mvc;
using GSAInterfaceWS;
using System.Reflection.Metadata;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.IntegracionLegadoUS.Controllers.Contract
{
    public interface IController
    {
        

        public Task<ActionResult<object>> ConsultaKey();
        public Task<ActionResult<object>> Consulta();

        public Task<ActionResult<object>> PermisoMenu(string Usuario);
        public Task<ActionResult<object>> PermisoMenu([FromQuery] string Usuario, [FromQuery] string Path);

        public Task<ActionResult<object>> PermisoMenuControles(string Usuario, string? CodPerfil);
    }
}
