﻿namespace ReyBanPac.IntegracionLegadoUS.Controllers.Dto
{
    public class Data
    {
        public string password { get; set; }

        public string system { get; set; }

        public string account { get; set; }

        public string status { get; set; }

        public string cause { get; set; }



    }
}
