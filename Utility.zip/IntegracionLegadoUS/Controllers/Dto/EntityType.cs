﻿using System.Text.Json.Serialization;

namespace ReyBanPac.IntegracionLegadoUS.Controllers.Dto
{
    public class EntityType
    {
        [JsonPropertyName("Id")]
        public int Id { get; set; }

        [JsonPropertyName("LFDESZON")]
        public string LFDESZON { get; set; }

        [JsonPropertyName("LFPROZON")]
        public string LFPROZON { get; set; }

        public EntityType()
        {
            LFDESZON = string.Empty;
            LFPROZON = string.Empty;
        }
    }
}
