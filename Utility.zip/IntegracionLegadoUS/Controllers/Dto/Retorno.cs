﻿namespace ReyBanPac.IntegracionLegadoUS.Controllers.Dto
{
    public class Retorno
    {
        public string password { get; set; }

        public List<Data> data { get; set; }

        public string cause { get; set; }

        public string status { get; set; }


        public Retorno()
        {
            password = string.Empty;
            cause = string.Empty;
            status = string.Empty;
        }
    }
}
