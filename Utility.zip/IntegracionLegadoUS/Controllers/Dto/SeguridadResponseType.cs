﻿namespace ReyBanPac.IntegracionLegadoUS.Controllers.Dto
{
    public class SeguridadResponseType
    {

        public string tokenuser { set; get; } = string.Empty;
        public string tokenpass { set; get; } = string.Empty;
        public string aud_user { set; get; } = string.Empty;
        public string aud_pass { set; get; } = string.Empty;
        public string folder { set; get; } = string.Empty;
        public string secretkeypass { set; get; } = string.Empty;
    }
}
