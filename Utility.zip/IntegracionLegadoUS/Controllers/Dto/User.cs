﻿namespace ReyBanPac.IntegracionLegadoUS.Controllers.Dto
{
    public class User
    {
        public string access_token { get; set; }

        public string refresh_token { get; set; }

        public string id_token { get; set; }

        public string token_type { get; set; }

        public int expires_in { get; set; }

        public User()
        {
            access_token = string.Empty;
            refresh_token = string.Empty;
            id_token = string.Empty;
            token_type = string.Empty;
        }
    }




}
