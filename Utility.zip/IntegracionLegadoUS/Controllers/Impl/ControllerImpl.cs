﻿using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Controllers.Contract;
using ReyBanPac.IntegracionLegadoUS.Controllers.Dto;
using ReyBanPac.IntegracionLegadoUS.Service.Contract;
using ReyBanPac.IntegracionLegadoUS.Utils;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;
using GSAInterfaceWS;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.IntegracionLegadoUS.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
    public class ControllerImpl : ControllerBase, IController
    {

        private readonly Provider _provider;
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;

        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger, Provider provider)
        {
            Svc = Servicio;
            _logger = logger;
            _provider = provider;
        }

        [HttpGet("key")]
        [ProducesResponseType(typeof(CredencialType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ConsultaKey()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                CredencialType Resultado;
                Resultado = await Svc.Consulta(_provider.Const.COD_APP, _provider.Const.COD_REC_KEY);
                return Ok(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpGet]
        [ProducesResponseType(typeof(CredencialType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Consulta()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                CredencialType Resultado;
                Resultado = await Svc.Consulta(_provider.Const.COD_APP, _provider.Const.COD_REC_DB);
                return Ok(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpGet("{COD_APP}/{COD_REC}")]
        [ProducesResponseType(typeof(CredencialType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> Consulta(string COD_APP, string COD_REC)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                CredencialType Resultado;
                Resultado = await Svc.Consulta(COD_APP, COD_REC);
                return Ok(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpGet("db")]
        [ProducesResponseType(typeof(CredencialType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ConsultaDb()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                CredencialType Resultado;
                Resultado = await Svc.Consulta(_provider.Const.COD_APP, _provider.Const.COD_REC_LEG);
                return Ok(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpGet("permisomenu/{Usuario}")]
        [ProducesResponseType(typeof(List<PermisoMenuType>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> PermisoMenu(string Usuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                //Por si el usuario llega como correo
                Usuario = Usuario.Split('@')[0];

                //Limitarlo a 10 caracteres
                //if (Usuario.Length > 10)
                //    Usuario = Usuario.Substring(0, 10);

                List<PermisoMenuType> Resultado = await Svc.PermisoMenu(Usuario);
                return Ok(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

        [HttpPost("permisomenu")]
        [ProducesResponseType(typeof(PermisoMenuType), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> PermisoMenu([FromQuery] string Usuario, [FromQuery] string Path)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                //Por si el usuario llega como correo
                Usuario = Usuario.Split('@')[0];

                //Limitarlo a 10 caracteres
                //if (Usuario.Length > 10)
                //    Usuario = Usuario.Substring(0, 10);

                PermisoMenuType Resultado = await Svc.PermisoMenu(Usuario, Path);
                return Ok(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }


        [HttpPost]
        [ProducesResponseType(typeof(List<PermisoPerfilType>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(RespuestaType), StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> PermisoMenuControles([FromQuery] string Usuario, [FromQuery] string? CodPerfil)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Controller");
            try
            {
                //Por si el usuario llega como correo
                Usuario = Usuario.Split('@')[0];

                //Limitarlo a 10 caracteres
                //if (Usuario.Length > 10)
                //    Usuario = Usuario.Substring(0, 10);

                List<PermisoPerfilType> Resultado = await Svc.PermisoMenuControles(Usuario, CodPerfil);
                return Ok(Resultado);
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Controller");
            }
        }

    }
}
