using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Controllers.Contract;
using ReyBanPac.IntegracionLegadoUS.Controllers.Impl;
using ReyBanPac.IntegracionLegadoUS.Service.Command;
using ReyBanPac.IntegracionLegadoUS.Service.Command.Business;
using ReyBanPac.IntegracionLegadoUS.Service.Contract;
using ReyBanPac.IntegracionLegadoUS.Service.Impl;
using ReyBanPac.IntegracionLegadoUS.Utils;
using Microsoft.OpenApi.Models;
using Microsoft.Extensions.Logging;

var builder = WebApplication.CreateBuilder(args);

#region Logger File

var DirLogs = builder.Configuration.GetSection("Parametros:DirLogs").Value;
builder.Logging.AddFile($"{DirLogs}Logs_{General.Nombre_Servicio}{General.Tipo_Servicio}-{{Date}}.txt");

#endregion

// Add services to the container.
builder.Services.AddScoped<IController, ControllerImpl>();
builder.Services.AddScoped<IService, ServiceImpl>();
builder.Services.AddSingleton<Provider>();
//Segudidad
builder.Services.AddTransient<ConsultaPrmSeguridadCommand>();
builder.Services.AddTransient<GenerarTokenCommand>();
builder.Services.AddTransient<GenerarVaultCommand>();
builder.Services.AddTransient<ValidarVariablesCommand>();

//Gsa
builder.Services.AddTransient<ConsultaGSAPerfilDetControlesCommand>();
builder.Services.AddTransient<ConsultaGSAPerfilProgramasCommand>();
builder.Services.AddTransient<ConsultaGSAPerfilUsuarioCommand>();
builder.Services.AddTransient<ConsultaGSAUsuarioPerfilCommand>();

//Local
builder.Services.AddTransient<ConsultarTokenCommand>();
builder.Services.AddTransient<GuardarTokenCommand>();
builder.Services.AddTransient<ValidarTokenCommand>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = General.Nombre_Servicio + "-" + General.Tipo_Servicio, Version = "v1" });

});

var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("v1/swagger.json", General.Nombre_Servicio + "-" + General.Tipo_Servicio + " v1");
    });
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
