﻿using GSAInterfaceWS;
using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Controllers.Dto;
using ReyBanPac.IntegracionLegadoUS.Utils;
using ReyBanPac.ModeloCanonico.Type;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Xml;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command.Business
{


    public class ValidarTokenCommand
    {
        private readonly ILogger<ValidarTokenCommand> _logger;
        private readonly ConsultarTokenCommand _consultarTokenCommand;
        private readonly GuardarTokenCommand _guardarTokenCommand;
        private readonly ConsultaPrmSeguridadCommand _consultaPrmSeguridadCommand;
        private readonly GenerarTokenCommand _generarTokenCommand;
        public ValidarTokenCommand(ILogger<ValidarTokenCommand> logger,
            ConsultarTokenCommand consultarTokenCommand,
            ConsultaPrmSeguridadCommand consultaPrmSeguridadCommand,
            GenerarTokenCommand generarTokenCommand,
            GuardarTokenCommand guardarTokenCommand)
        {
            _logger = logger;
            _consultarTokenCommand = consultarTokenCommand;
            _consultaPrmSeguridadCommand = consultaPrmSeguridadCommand;
            _generarTokenCommand = generarTokenCommand;
            _guardarTokenCommand = guardarTokenCommand;
        }

        public async Task<(string, SeguridadResponseType)> ExecuteAsync(string COD_APP, string COD_REC)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {
                #region Consumir PRM Seguridad Legado

                SeguridadResponseType Seguridad = new SeguridadResponseType();

                try
                {

                    var _requestQueryResult = await _consultaPrmSeguridadCommand.ExecuteAsync(COD_APP, COD_REC);

                    XmlDocument xmlDocument = new XmlDocument();
                    xmlDocument.LoadXml(_requestQueryResult.Result);
                    XmlNodeList xmlNodeList = xmlDocument.DocumentElement!.SelectNodes("*[local-name()='data']");
                    foreach (XmlNode item in xmlNodeList)
                    {
                        XmlNodeList xmlNodeList2 = item.SelectNodes("*[local-name()='gps_sdt_get_parametrosItem']");
                        foreach (XmlNode item2 in xmlNodeList2)
                        {
                            string Codigo = item2.SelectSingleNode("*[local-name()='codigo']")!.InnerText;
                            string Valor = item2.SelectSingleNode("*[local-name()='valor']")!.InnerText;


                            switch (Codigo.Trim())
                            {
                                case "SEGPAR001":
                                    Seguridad.aud_user = Valor;
                                    break;
                                case "SEGPAR002":
                                    Seguridad.aud_pass = Converts.Base64Decode(Valor);
                                    break;
                                case "SEGPAR003":
                                    Seguridad.tokenuser = Valor;
                                    break;
                                case "SEGPAR004":
                                    Seguridad.tokenpass = Converts.Base64Decode(Valor);
                                    break;
                                case "SEGPAR005":
                                    Seguridad.folder = Valor;
                                    break;
                                case "SEGPAR006":
                                    break;
                                case "SEGPAR007":
                                    Seguridad.secretkeypass = Valor;
                                    break;
                            }

                        }
                    }

                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                    throw;
                }


                #endregion


                #region Consultar Token Existente

                try
                {
                    string respuesta = await _consultarTokenCommand.ExecuteAsync();

                    TokenType Token = JsonSerializer.Deserialize<TokenType>(respuesta) ?? new TokenType();

                    if (string.IsNullOrEmpty(Token.Token))
                        throw new ServiceException("Servicio no retorno datos de Token") { Codigo = StatusCodes.Status400BadRequest };

                    return (Token.Token, Seguridad);
                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio} No hay token vigentes");

                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio} {ex.Message}");

                }
                #endregion

                #region Generar Token
                User user = new User();
                try
                {
                    _logger.LogInformation($"{General.Nombre_Servicio}  Se procede a generar token");

                   
                    #region Consumir Generar Token Legado


                    try
                    {

                        string content = await _generarTokenCommand.ExecuteAsync(Seguridad.tokenuser, Seguridad.tokenpass, "password", Seguridad.aud_user, Seguridad.aud_pass);
                        user = JsonSerializer.Deserialize<User>(content) ?? new User();

                    }
                    catch (Exception)
                    {
                        throw new ServiceException("Error al consumir soffid");
                    }
                    #endregion

                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio} {ex.Message}");
                }
                #endregion

                #region Registrar Token Local
                try
                {

                    TokenType tokenType = new TokenType();
                    tokenType.Token = user.id_token;
                    tokenType.Canal = 1;
                    tokenType.Vigencia = DateTime.Now.AddSeconds(user.expires_in - 3);
                    tokenType.Estado = Estados.ACTIVO;

                    await _guardarTokenCommand.ExecuteAsync(JsonSerializer.Serialize(tokenType));

                    return (tokenType.Token, Seguridad);
                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, $"{General.Nombre_Servicio} Error al guardar el token");
                    return (user.id_token, Seguridad);
                }
                #endregion


            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error al consumir servicios para generar token");
                throw new ServiceException("Error al consumir servicios para generar token") { Codigo = StatusCodes.Status400BadRequest };
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }


    }
}
