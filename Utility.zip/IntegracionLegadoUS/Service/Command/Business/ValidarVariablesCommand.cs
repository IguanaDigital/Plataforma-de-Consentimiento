﻿using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Utils;
using System.Reflection;
using System.Text;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command.Business
{


    public class ValidarVariablesCommand
    {
        private readonly ILogger<ValidarVariablesCommand> _logger;
        private readonly Provider Provider;
        public ValidarVariablesCommand(Provider _provider, ILogger<ValidarVariablesCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public void Execute(string codApp, string codRec, string urlWSGsa, string urlWSSoffid)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {

                bool flag = false;

                flag = codApp.Equals("") || codRec.Equals("") || urlWSGsa.Equals("") || urlWSSoffid.Equals("");
                flag = ((!flag) ? true : false);

               if(!flag)
                    throw new ServiceException("Las variables codApp, codRec, urlWSGsa y urlWSSoffid son obligatorias");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Las variables codApp, codRec, urlWSGsa y urlWSSoffid son obligatorias");
                throw new ServiceException("Las variables codApp, codRec, urlWSGsa y urlWSSoffid son obligatorias");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
