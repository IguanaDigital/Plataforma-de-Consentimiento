﻿
using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Utils;
using SeguridadService;
using System.Net.Security;
using System.Net;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.Text;
using GSAInterfaceWS;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command
{
    public class ConsultaGSAPerfilUsuarioCommand
    {
        private readonly ILogger<ConsultaGSAPerfilUsuarioCommand> _logger;
        private readonly Provider Provider;
        public ConsultaGSAPerfilUsuarioCommand(Provider _provider, ILogger<ConsultaGSAPerfilUsuarioCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<PerfilUsuarioBean[]> ExecuteAsync(GetPerfilUsuario RequestPerfilUsuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {
                using (var connect = new GSAInterfaceWSImplClient())
                {
                    connect.ClientCredentials.ServiceCertificate.SslCertificateAuthentication = new System.ServiceModel.Security.X509ServiceCertificateAuthentication()
                    {
                        CertificateValidationMode = System.ServiceModel.Security.X509CertificateValidationMode.None,
                        RevocationMode = X509RevocationMode.NoCheck
                    };

                    connect.Endpoint.Address = new EndpointAddress(Provider.Const.URL_GSA_WS); 
                    connect.Endpoint.Binding = new BasicHttpsBinding();

                    return await connect.getPerfilUsuarioAsync(RequestPerfilUsuario);
                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error en Servicio Web ");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
