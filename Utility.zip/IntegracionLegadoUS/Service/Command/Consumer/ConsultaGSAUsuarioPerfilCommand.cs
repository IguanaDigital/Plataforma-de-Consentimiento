﻿using GSAInterfaceWS;
using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Utils;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.Text;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command
{
    public class ConsultaGSAUsuarioPerfilCommand
    {
        private readonly ILogger<ConsultaGSAUsuarioPerfilCommand> _logger;
        private readonly Provider Provider;
        public ConsultaGSAUsuarioPerfilCommand(Provider _provider, ILogger<ConsultaGSAUsuarioPerfilCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<GetUsuarioPerfilBean[]> ExecuteAsync(GetUsuarioPerfil RequestUsuarioPerfil)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {
                using (var connect = new GSAInterfaceWSImplClient())
                {
                    connect.ClientCredentials.ServiceCertificate.SslCertificateAuthentication = new System.ServiceModel.Security.X509ServiceCertificateAuthentication()
                    {
                        CertificateValidationMode = System.ServiceModel.Security.X509CertificateValidationMode.None,
                        RevocationMode = X509RevocationMode.NoCheck
                    };

                    connect.Endpoint.Address = new EndpointAddress(Provider.Const.URL_GSA_WS);
                    connect.Endpoint.Binding = new BasicHttpsBinding();

                    return await connect.getUsuarioPerfilAsync(RequestUsuarioPerfil);
                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error en Servicio Web ");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
