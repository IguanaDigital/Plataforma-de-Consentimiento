﻿
using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Utils;
using SeguridadService;
using System.Net.Security;
using System.Net;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.Text;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command
{
    public class ConsultaPrmSeguridadCommand
    {
        private readonly ILogger<ConsultaPrmSeguridadCommand> _logger;
        private readonly Provider Provider;
        public ConsultaPrmSeguridadCommand(Provider _provider, ILogger<ConsultaPrmSeguridadCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<CONSULTA_PRM_SEGURIDADResponse> ExecuteAsync(string COD_APP, string COD_REC)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {
                using (var connect = new gpsys_wsSoapPortClient())
                {
                    connect.ClientCredentials.ServiceCertificate.SslCertificateAuthentication = new System.ServiceModel.Security.X509ServiceCertificateAuthentication()
                    {
                        CertificateValidationMode = System.ServiceModel.Security.X509CertificateValidationMode.None,
                        RevocationMode = X509RevocationMode.NoCheck
                    };

                    connect.Endpoint.Address = new EndpointAddress(Provider.Const.URL_GSA_GPS); 
                    connect.Endpoint.Binding = new BasicHttpsBinding();

                    return await connect.CONSULTA_PRM_SEGURIDADAsync(COD_APP, COD_REC);
                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error en Servicio Web ");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
