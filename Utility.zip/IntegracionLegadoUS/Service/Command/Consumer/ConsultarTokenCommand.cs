﻿using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Utils;
using System;
using System.Net;
using System.Reflection;
using System.Text;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command
{
    public class ConsultarTokenCommand
    {
        private readonly ILogger<ConsultarTokenCommand> _logger;
        private readonly Provider Provider;
        public ConsultarTokenCommand(Provider _provider, ILogger<ConsultarTokenCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {
                //Creo un HttpClientHandler personalizado
                HttpClientHandler handler = new HttpClientHandler();
                
                //Deshabilitar la validacion del certificado (No recomendato para produccion)
                handler.ServerCertificateCustomValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;

                using (var client = new HttpClient(handler))
                {

                    //Generar la Url del servicio a consumir
                    var Url = $"{Provider.HostApi}{Provider.Api.CONSULTAR_TOKEN}";

                    _logger.LogInformation($"Url del token a consumir: URL: {Url}");
                    client.Timeout = TimeSpan.FromSeconds(5);
                    var Response = await client.GetAsync(Url);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
               

                if (ex.StatusCode == HttpStatusCode.NotFound)
                {
                    _logger.LogInformation($"Mensaje de error: HttpRequestException: {ex.Message} InnerException: {ex.InnerException}");
                    _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no retorno token");

                    throw new ServiceException("Servicio no retorno datos de Token") { Codigo = StatusCodes.Status400BadRequest };
                }

                _logger.LogInformation($"Mensaje de error: HttpRequestException: {ex.Message} InnerException: {ex.InnerException}");
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible para generar token");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Mensaje de error: Exception: {ex.Message} InnerException: {ex.InnerException}");
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
