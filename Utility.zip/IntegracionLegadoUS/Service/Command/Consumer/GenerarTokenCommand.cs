﻿using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Utils;
using System;
using System.Net;
using System.Reflection;
using System.Text;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command
{
    public class GenerarTokenCommand
    {
        private readonly ILogger<GenerarTokenCommand> _logger;
        private readonly Provider Provider;
        public GenerarTokenCommand(Provider _provider, ILogger<GenerarTokenCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string tokenuser, string tokenpass, string grant_type, string userName, string password)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {
                //Creo un HttpClientHandler personalizado
                HttpClientHandler handler = new HttpClientHandler();
                //handler.Credentials = new NetworkCredential(userName, password);
                _logger.LogInformation($"Claves de Autenticacion: Username: {userName} Pass:{password}");
                //Configuro las credenciales de la autenticacion Basic
                handler.Credentials = new NetworkCredential(userName, password);

                //Deshabilitar la validacion del certificado (No recomendato para produccion)
                handler.ServerCertificateCustomValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;

                using (var client = new HttpClient(handler))
                {
                    //Generar el contenido del body en json
                    var Content = new StringContent("{}", Encoding.UTF8, MimeType.JSON);

                    //Generar la Url del servicio a consumir
                    var Url =$"{Provider.Const.URL_SOFFID}{Provider.Api.GENERAR_TOKEN}?username={tokenuser}&password={tokenpass}&grant_type={grant_type}";
                    
                    _logger.LogInformation($"Url del token a consumir: URL: {Url}");
                    
                    var Response = await client.PostAsync(Url, Content);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogInformation($"Mensaje de error: HttpRequestException: {ex.Message} InnerException: {ex.InnerException}");
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible para generar token");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Mensaje de error: Exception: {ex.Message} InnerException: {ex.InnerException}");
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
