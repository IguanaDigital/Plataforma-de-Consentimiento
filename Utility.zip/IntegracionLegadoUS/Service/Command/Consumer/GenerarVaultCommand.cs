﻿using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Utils;
using System.Net;
using System.Reflection;
using System.Text;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command
{
    public class GenerarVaultCommand
    {
        private readonly ILogger<GenerarVaultCommand> _logger;
        private readonly Provider Provider;
        public GenerarVaultCommand(Provider _provider, ILogger<GenerarVaultCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string JsonRequest)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {
                //Creo un HttpClientHandler personalizado
                HttpClientHandler handler = new HttpClientHandler();

                //Configuro las credenciales de la autenticacion Basic
                //handler.Credentials = new NetworkCredential(userName, password);

                //Deshabilitar la validacion del certificado (No recomendato para produccion)
                handler.ServerCertificateCustomValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;

                using (var client = new HttpClient(handler))
                {
                    //Generar el contenido del body en json
                    var Content = new StringContent(JsonRequest, Encoding.UTF8, MimeType.JSON);

                    //Generar la Url del servicio a consumir
                    var Url = string.Concat(Provider.Const.URL_SOFFID,":", Provider.Const.PUERTO_URL_SOFFID, Provider.Api.GENERAR_VAULT);

                    //Crear el encabezado de la autenticacion Basic
                    //string credentials = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes($"{username}:{password}"));
                   //client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", credentials);


                    var Response = await client.PostAsync(Url, Content);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible para generar token");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
