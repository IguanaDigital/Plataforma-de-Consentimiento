﻿using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Utils;
using System;
using System.Net;
using System.Reflection;
using System.Text;

namespace ReyBanPac.IntegracionLegadoUS.Service.Command
{
    public class GuardarTokenCommand
    {
        private readonly ILogger<GuardarTokenCommand> _logger;
        private readonly Provider Provider;
        public GuardarTokenCommand(Provider _provider, ILogger<GuardarTokenCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string JsonBody)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Command");
            try
            {
                //Creo un HttpClientHandler personalizado
                HttpClientHandler handler = new HttpClientHandler();


                //Deshabilitar la validacion del certificado (No recomendato para produccion)
                handler.ServerCertificateCustomValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;

                using (var client = new HttpClient(handler))
                {
                    //Generar el contenido del body en json
                    var Content = new StringContent(JsonBody, Encoding.UTF8, MimeType.JSON);

                    //Generar la Url del servicio a consumir
                    var Url = $"{Provider.HostApi}{Provider.Api.GUARDAR_TOKEN}";

                    _logger.LogInformation($"Url del token a consumir: URL: {Url}");
                    client.Timeout = TimeSpan.FromSeconds(5);
#if DEBUG
                    Url = "https://localhost:7233/api/es/token/";
#endif
                    var Response = await client.PostAsync(Url, Content);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogInformation($"Mensaje de error: HttpRequestException: {ex.Message} InnerException: {ex.InnerException}");
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Servicio no disponible para guardar token");
                throw new ServiceException("Error al guardar el token") { Codigo = StatusCodes.Status400BadRequest };
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Mensaje de error: Exception: {ex.Message} InnerException: {ex.InnerException}");
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Command");
            }
        }
    }
}
