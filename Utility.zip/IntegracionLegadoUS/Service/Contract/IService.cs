﻿using GSAInterfaceWS;
using ReyBanPac.IntegracionLegadoUS.Controllers.Dto;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.IntegracionLegadoUS.Service.Contract
{
    public interface IService
    {
        public Task<CredencialType> Consulta(string COD_APP, string COD_REC);

        public Task<List<PermisoMenuType>> PermisoMenu(string Usuario);

        public Task<PermisoMenuType> PermisoMenu(string Usuario, string Path);
        public  Task<List<PermisoPerfilType>> PermisoMenuControles(string Usuario, string CodPerfil);
    }
}
