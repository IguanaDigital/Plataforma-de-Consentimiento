﻿using ReyBanPac.IntegracionLegadoUS.Constans;
using ReyBanPac.IntegracionLegadoUS.Controllers.Dto;
using ReyBanPac.IntegracionLegadoUS.Service.Contract;
using ReyBanPac.IntegracionLegadoUS.Utils;
using System.Reflection;
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Xml;
using ReyBanPac.IntegracionLegadoUS.Service.Command;
using ReyBanPac.IntegracionLegadoUS.Service.Command.Business;
using System.Text.Json.Nodes;
using System.Text.Json;
using System.Threading.Tasks;
using GSAInterfaceWS;
using ReyBanPac.ModeloCanonico.Type;
using System.Collections.Immutable;
using System.Collections.Generic;

namespace ReyBanPac.IntegracionLegadoUS.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;

        private readonly Provider _provider;
        private readonly ConsultaPrmSeguridadCommand _consultaPrmSeguridadCommand;
        private readonly GenerarTokenCommand _generarTokenCommand;
        private readonly GenerarVaultCommand _generarVaultCommand;
        private readonly ValidarVariablesCommand _validarVariablesCommand;
        private readonly ConsultaGSAPerfilUsuarioCommand _consultaGSAPerfilUsuarioCommand;
        private readonly ConsultaGSAUsuarioPerfilCommand _consultaGSAUsuarioPerfilCommand;
        private readonly ConsultaGSAPerfilProgramasCommand _consultaGSAPerfilProgramasCommand;
        private readonly ConsultaGSAPerfilDetControlesCommand _consultaGSAPerfilDetControlesCommand;
        private readonly ValidarTokenCommand _validarTokenCommand;


        public ServiceImpl(ILogger<ServiceImpl> logger,
                            Provider provider,
                            ConsultaPrmSeguridadCommand consultaPrmSeguridadCommand,
                            GenerarTokenCommand generarTokenCommand,
                            GenerarVaultCommand generarVaultCommand,
                            ValidarVariablesCommand validarVariablesCommand,
                            ConsultaGSAPerfilUsuarioCommand consultaGSAPerfilUsuarioCommand,
                            ConsultaGSAUsuarioPerfilCommand consultaGSAUsuarioPerfilCommand,
                            ConsultaGSAPerfilProgramasCommand consultaGSAPerfilProgramasCommand,
                            ConsultaGSAPerfilDetControlesCommand consultaGSAPerfilDetControlesCommand,
                            ValidarTokenCommand validarTokenCommand)
        {
            _logger = logger;
            _provider = provider;
            _consultaPrmSeguridadCommand = consultaPrmSeguridadCommand;
            _generarTokenCommand = generarTokenCommand;
            _generarVaultCommand = generarVaultCommand;
            _validarVariablesCommand = validarVariablesCommand;
            _consultaGSAPerfilUsuarioCommand = consultaGSAPerfilUsuarioCommand;
            _consultaGSAUsuarioPerfilCommand = consultaGSAUsuarioPerfilCommand;
            _consultaGSAPerfilProgramasCommand = consultaGSAPerfilProgramasCommand;
            _consultaGSAPerfilDetControlesCommand = consultaGSAPerfilDetControlesCommand;
            _validarTokenCommand = validarTokenCommand;
        }


        public async Task<CredencialType> Consulta(string COD_APP, string COD_REC)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");


            try
            {

                //var Seguridad = await Consultar_Prm_Seguridad(COD_APP, COD_REC);

                 (string id_token, SeguridadResponseType Seguridad) = await _validarTokenCommand.ExecuteAsync(COD_APP, COD_REC);

                //User user = await GetToken(Seguridad.tokenuser, Seguridad.tokenpass, Seguridad.aud_user, Seguridad.aud_pass);

                Retorno retorno = await GetVault(Seguridad.secretkeypass, /*user.*/id_token, Seguridad.folder);


                if (retorno.status.Equals("success"))
                {
                    if (retorno.data[0].status.Equals("deny"))
                    {
                        throw new ServiceException("No fue posible obtener la clave, deny: " + retorno.data[0].cause) { Codigo = StatusCodes.Status400BadRequest };
                    }

                    return new CredencialType()
                    {
                        User = retorno.data[0].account,
                        Pass = retorno.data[0].password
                    };
                }
                else
                {
                    throw new ServiceException("No fue posible obtener la clave, no success: RECS") { Codigo = StatusCodes.Status400BadRequest };
                }

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }

        public async Task<List<PermisoMenuType>> PermisoMenu(string Usuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                (string id_token, SeguridadResponseType Seguridad) = await _validarTokenCommand.ExecuteAsync(_provider.Const.COD_APP, _provider.Const.COD_REC_AU);

                //var Seguridad = await Consultar_Prm_Seguridad(_provider.Const.COD_APP, _provider.Const.COD_REC_AU);

                //User user = await GetToken(Seguridad.tokenuser, Seguridad.tokenpass, Seguridad.aud_user, Seguridad.aud_pass);


                #region Perfil Usuario
                GetPerfilUsuario RequestPU = new GetPerfilUsuario();
                RequestPU.environment = _provider.Const.ENVIRONMENT;
                RequestPU.scg_usu_codigo = Usuario;
                RequestPU.scg_app_codigo = _provider.Const.COD_APP;
                RequestPU.token = /*user.*/id_token;

                PerfilUsuarioBean[] PerfilUsuario = await _consultaGSAPerfilUsuarioCommand.ExecuteAsync(RequestPU);

                PerfilUsuarioBean Perfil = PerfilUsuario.FirstOrDefault();

                if (Perfil == null)
                    throw new ServiceException("Servicio no retorno datos de perfil usuario") { Codigo = StatusCodes.Status400BadRequest };


                #region Perfil Programas
                GetPerfilProgramas RequestP = new GetPerfilProgramas();
                RequestP.scg_usu_codigo = Usuario;
                RequestP.scg_per_codigo = Perfil.scg_per_codigo;
                RequestP.environment = _provider.Const.ENVIRONMENT;
                RequestP.token = /*user.*/id_token;

                var PerfilProgramas = await _consultaGSAPerfilProgramasCommand.ExecuteAsync(RequestP);

                if (PerfilProgramas == null)
                    throw new ServiceException("Servicio no retorno datos de perfil usuario") { Codigo = StatusCodes.Status400BadRequest };

                List<PerfilProgramasBean> PermisosPerfiles = PerfilProgramas.ToList();
                #endregion
                List<PermisoMenuType> PerfilFinal = new List<PermisoMenuType>();
                foreach (PerfilProgramasBean MultiPerfil in PermisosPerfiles)
                {
                    #region Perfil Controles
                    GetPerfilDetControles RequestC = new GetPerfilDetControles();
                    RequestC.scg_app_codigo = _provider.Const.COD_APP;
                    RequestC.scg_prg_codigo = MultiPerfil.scg_prg_codigo;
                    RequestC.scg_per_codigo = Perfil.scg_per_codigo;
                    RequestC.environment = _provider.Const.ENVIRONMENT;
                    RequestC.token = /*user.*/id_token;

                    var PerfilControles = await _consultaGSAPerfilDetControlesCommand.ExecuteAsync(RequestC);

                    if (PerfilControles == null)
                        throw new ServiceException("Servicio no retorno datos de controles") { Codigo = StatusCodes.Status400BadRequest };

                    #endregion

                    var Final = Converts.ConvertLegadoToType(MultiPerfil);
                    Final.Controles = Converts.ConvertLegadoToListType(PerfilControles.ToList());

                    PerfilFinal.Add(Final);
                }

                #endregion

                return PerfilFinal;//Converts.ConvertLegadoToType(PermisosPerfiles);

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }

        public async Task<List<PermisoMenuType>> PermisoMenu2(string Usuario)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                (string id_token, SeguridadResponseType Seguridad) = await _validarTokenCommand.ExecuteAsync(_provider.Const.COD_APP, _provider.Const.COD_REC_AU);
                //var Seguridad = await Consultar_Prm_Seguridad(_provider.Const.COD_APP, _provider.Const.COD_REC_AU);

                //User user = await GetToken(Seguridad.tokenuser, Seguridad.tokenpass, Seguridad.aud_user, Seguridad.aud_pass);


                #region Perfil Usuario
                GetPerfilUsuario RequestPU = new GetPerfilUsuario();
                RequestPU.environment = _provider.Const.ENVIRONMENT;
                RequestPU.scg_usu_codigo = Usuario;
                RequestPU.scg_app_codigo = _provider.Const.COD_APP;
                RequestPU.token = /*user.*/id_token;

                var PerfilUsuario = await _consultaGSAPerfilUsuarioCommand.ExecuteAsync(RequestPU);

                if (PerfilUsuario == null)
                    throw new ServiceException("Servicio no retorno datos de perfil usuario") { Codigo = StatusCodes.Status400BadRequest };

                PerfilUsuario = PerfilUsuario.Take(1).ToArray();

                List<PerfilProgramasBean> PermisosPerfiles = new List<PerfilProgramasBean>();
                foreach (var Perfil in PerfilUsuario)
                {
                    #region Perfil Programas
                    GetPerfilProgramas RequestP = new GetPerfilProgramas();
                    RequestP.scg_usu_codigo = Usuario;
                    RequestP.scg_per_codigo = Perfil.scg_per_codigo;
                    RequestP.environment = _provider.Const.ENVIRONMENT;
                    RequestP.token = /*user.*/id_token;

                    var PerfilProgramas = await _consultaGSAPerfilProgramasCommand.ExecuteAsync(RequestP);

                    if (PerfilProgramas == null)
                        throw new ServiceException("Servicio no retorno datos de perfil usuario") { Codigo = StatusCodes.Status400BadRequest };

                    PermisosPerfiles.AddRange(PerfilProgramas);
                    #endregion




                }

                #endregion

                return Converts.ConvertLegadoToType(PermisosPerfiles);

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }

        public async Task<PermisoMenuType> PermisoMenu(string Usuario, string Path)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {

                (string id_token, SeguridadResponseType Seguridad) = await _validarTokenCommand.ExecuteAsync(_provider.Const.COD_APP, _provider.Const.COD_REC_AU);
                //var Seguridad = await Consultar_Prm_Seguridad(_provider.Const.COD_APP, _provider.Const.COD_REC_AU);

                //User user = await GetToken(Seguridad.tokenuser, Seguridad.tokenpass, Seguridad.aud_user, Seguridad.aud_pass);


                #region Perfil Usuario
                GetPerfilUsuario RequestPU = new GetPerfilUsuario();
                RequestPU.environment = _provider.Const.ENVIRONMENT;
                RequestPU.scg_usu_codigo = Usuario;
                RequestPU.scg_app_codigo = _provider.Const.COD_APP;
                RequestPU.token = /*user.*/id_token;

                var PerfilUsuario = await _consultaGSAPerfilUsuarioCommand.ExecuteAsync(RequestPU);

                if (PerfilUsuario == null)
                    throw new ServiceException("Servicio no retorno datos de perfil usuario") { Codigo = StatusCodes.Status400BadRequest };

                PerfilUsuario = PerfilUsuario.Take(1).ToArray();

                List<PerfilProgramasBean> PermisosPerfiles = new List<PerfilProgramasBean>();
                foreach (var Perfil in PerfilUsuario)
                {
                    #region Perfil Programas
                    GetPerfilProgramas RequestP = new GetPerfilProgramas();
                    RequestP.scg_usu_codigo = Usuario;
                    RequestP.scg_per_codigo = Perfil.scg_per_codigo;
                    RequestP.environment = _provider.Const.ENVIRONMENT;
                    RequestP.token = /*user.*/id_token;

                    var PerfilProgramas = await _consultaGSAPerfilProgramasCommand.ExecuteAsync(RequestP);

                    if (PerfilProgramas == null)
                        throw new ServiceException("Servicio no retorno datos de perfil usuario") { Codigo = StatusCodes.Status400BadRequest };

                    var PerfilProgamaPath = PerfilProgramas.ToList().Find(x => x.scg_prg_path == Path);

                    if (PerfilProgamaPath != null)
                        PermisosPerfiles.Add(PerfilProgamaPath);
                    #endregion
                }
                #endregion



                if (PermisosPerfiles == null || PermisosPerfiles.Count == 0)
                    throw new ServiceException("Servicio no retorno datos de el path enviado") { Codigo = StatusCodes.Status400BadRequest };

                var MultiPerfil = PermisosPerfiles.FirstOrDefault() ?? new PerfilProgramasBean();//Converts.ConvertLegadoToTypeMultiPerfil(PermisosPerfiles);

                #region Perfil Controles
                GetPerfilDetControles RequestC = new GetPerfilDetControles();
                RequestC.scg_app_codigo = _provider.Const.COD_APP;
                RequestC.scg_prg_codigo = MultiPerfil.scg_prg_codigo;
                RequestC.scg_per_codigo = PerfilUsuario.First().scg_per_codigo;
                RequestC.environment = _provider.Const.ENVIRONMENT;
                RequestC.token = /*user.*/id_token;

                var PerfilControles = await _consultaGSAPerfilDetControlesCommand.ExecuteAsync(RequestC);

                if (PerfilControles == null)
                    throw new ServiceException("Servicio no retorno datos de controles") { Codigo = StatusCodes.Status400BadRequest };


                #endregion
                var PerfilFinal = Converts.ConvertLegadoToType(MultiPerfil);
                PerfilFinal.Controles = Converts.ConvertLegadoToListType(PerfilControles.ToList());

                return PerfilFinal;

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }


        public async Task<List<PermisoPerfilType>> PermisoMenuControles(string Usuario, string CodPerfil)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Service");

            try
            {
                (string id_token, SeguridadResponseType Seguridad) = await _validarTokenCommand.ExecuteAsync(_provider.Const.COD_APP, _provider.Const.COD_REC_AU);
                //var Seguridad = await Consultar_Prm_Seguridad(_provider.Const.COD_APP, _provider.Const.COD_REC_AU);

                //User user = await GetToken(Seguridad.tokenuser, Seguridad.tokenpass, Seguridad.aud_user, Seguridad.aud_pass);


                #region Perfil Usuario

                GetPerfilUsuario RequestPU = new GetPerfilUsuario();
                RequestPU.environment = _provider.Const.ENVIRONMENT;
                RequestPU.scg_usu_codigo = Usuario;
                RequestPU.scg_app_codigo = _provider.Const.COD_APP;
                RequestPU.token = /*user.*/id_token;

                var PerfilUser = await _consultaGSAPerfilUsuarioCommand.ExecuteAsync(RequestPU);

                List<PerfilUsuarioBean> PerfilUsuario = PerfilUser.ToList();

                if (PerfilUsuario == null)
                    throw new ServiceException("Servicio no retorno datos de perfil usuario") { Codigo = StatusCodes.Status400BadRequest };

                //Filtrar por Perfil
                if (!string.IsNullOrEmpty(CodPerfil))
                    PerfilUsuario = PerfilUsuario.Where(x => x.scg_per_codigo.Equals(CodPerfil)).ToList();

                List<PerfilUsuarioBean> PerfilUsuarioFiltro = new List<PerfilUsuarioBean>();
                PerfilUsuarioFiltro.Add(PerfilUsuario.FirstOrDefault());


                List<PermisoPerfilType> ListaPermisoPerfilType = new List<PermisoPerfilType>();

                foreach (var Perfil in PerfilUsuarioFiltro)
                {
                    PermisoPerfilType PermisoPerfilType = new PermisoPerfilType();
                    PermisoPerfilType.Codigo = Perfil.scg_per_codigo;
                    PermisoPerfilType.Programas = new List<PermisoMenuType>();

                    #region Perfil Programas
                    GetPerfilProgramas RequestP = new GetPerfilProgramas();
                    RequestP.scg_usu_codigo = Usuario;
                    RequestP.scg_per_codigo = Perfil.scg_per_codigo;
                    RequestP.environment = _provider.Const.ENVIRONMENT;
                    RequestP.token = /*user.*/id_token;

                    var PerfilProgramas = await _consultaGSAPerfilProgramasCommand.ExecuteAsync(RequestP);

                    if (PerfilProgramas == null)
                        throw new ServiceException("Servicio no retorno datos de perfil usuario") { Codigo = StatusCodes.Status400BadRequest };

                    foreach (var Programa in PerfilProgramas)
                    {
                        #region Perfil Controles
                        GetPerfilDetControles RequestC = new GetPerfilDetControles();
                        RequestC.scg_app_codigo = _provider.Const.COD_APP;
                        RequestC.scg_prg_codigo = Programa.scg_prg_codigo;
                        RequestC.scg_per_codigo = Perfil.scg_per_codigo;
                        RequestC.environment = _provider.Const.ENVIRONMENT;
                        RequestC.token = /*user.*/id_token;

                        var PerfilControles = await _consultaGSAPerfilDetControlesCommand.ExecuteAsync(RequestC);

                        if (PerfilControles == null)
                            throw new ServiceException("Servicio no retorno datos de controles") { Codigo = StatusCodes.Status400BadRequest };

                        #endregion

                        //Mapper
                        PermisoMenuType PerfilProgramaUnidad = Converts.ConvertLegadoToType(Programa);
                        PerfilProgramaUnidad.Controles = Converts.ConvertLegadoToListType(PerfilControles.ToList());

                        //Nivel 2
                        PermisoPerfilType.Programas.Add(PerfilProgramaUnidad);
                    }

                    #endregion

                    ListaPermisoPerfilType.Add(PermisoPerfilType);
                }

                #endregion

                return ListaPermisoPerfilType;

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
            }
        }



        //private async Task<User> GetToken(string tokenuser, string tokenpass, string aud_user, string aud_pass)
        //{

        //    try
        //    {

        //        var content = await _generarTokenCommand.ExecuteAsync(tokenuser, tokenpass, "password", aud_user, aud_pass);


        //        return JsonSerializer.Deserialize<User>(content) ?? new User();


        //    }
        //    catch (Exception)
        //    {
        //        throw new ServiceException("Error al consumir soffid");
        //    }
        //}

        private async Task<Retorno> GetVault(string secretkeypass, string id_token, string folder)
        {

            try
            {

                var Key = $"{{\"secretkeypass\":\"{secretkeypass}\"}}";
                var data = $"{{\"token\": \"{id_token}\", \"folder\": \"{folder}\", \"params\":{Key}}}";

                var content = await _generarVaultCommand.ExecuteAsync(data);

                return JsonSerializer.Deserialize<Retorno>(content) ?? new Retorno();

            }
            catch (Exception)
            {
                throw new ServiceException("Error al consumir soffid");
            }
        }

        //private async Task<SeguridadResponseType> Consultar_Prm_Seguridad(string COD_APP, string COD_REC)
        //{
        //    try
        //    {
        //        SeguridadResponseType Seguridad = new SeguridadResponseType();

        //        _validarVariablesCommand.Execute(COD_APP, COD_REC, _provider.Const.URL_GSA_GPS, _provider.Const.URL_SOFFID);

        //        var _requestQueryResult = await _consultaPrmSeguridadCommand.ExecuteAsync(COD_APP, COD_REC);

        //        _logger.LogInformation($"Response de servicio de Seguridad {_requestQueryResult.Result}");

        //        XmlDocument xmlDocument = new XmlDocument();
        //        xmlDocument.LoadXml(_requestQueryResult.Result);
        //        string text8 = xmlDocument.GetElementsByTagName("mensaje").Item(0)!.InnerText.Trim();
        //        XmlNodeList xmlNodeList = xmlDocument.DocumentElement!.SelectNodes("*[local-name()='data']");
        //        foreach (XmlNode item in xmlNodeList)
        //        {
        //            XmlNodeList xmlNodeList2 = item.SelectNodes("*[local-name()='gps_sdt_get_parametrosItem']");
        //            foreach (XmlNode item2 in xmlNodeList2)
        //            {
        //                string innerText = item2.SelectSingleNode("*[local-name()='codigo']")!.InnerText;
        //                string innerText2 = item2.SelectSingleNode("*[local-name()='descripcion']")!.InnerText;
        //                string innerText3 = item2.SelectSingleNode("*[local-name()='valor']")!.InnerText;
        //                if (innerText.Trim().Equals("SEGPAR003"))
        //                {
        //                    Seguridad.tokenuser = innerText3;
        //                }

        //                if (innerText.Trim().Equals("SEGPAR004"))
        //                {
        //                    Seguridad.tokenpass = Converts.Base64Decode(innerText3);
        //                }

        //                if (innerText.Trim().Equals("SEGPAR005"))
        //                {
        //                    Seguridad.folder = innerText3;
        //                }

        //                if (innerText.Trim().Equals("SEGPAR001"))
        //                {
        //                    Seguridad.aud_user = innerText3;
        //                }

        //                if (innerText.Trim().Equals("SEGPAR002"))
        //                {
        //                    Seguridad.aud_pass = Converts.Base64Decode(innerText3);
        //                }

        //                if (innerText.Trim().Equals("SEGPAR007"))
        //                {
        //                    Seguridad.secretkeypass = innerText3;
        //                }
        //            }
        //        }
        //        _logger.LogInformation($"Response de servicio de Seguridad Json: {JsonSerializer.Serialize(Seguridad)}");

        //        return Seguridad;
        //    }
        //    catch (ServiceException ex)
        //    {
        //        _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} {ex.Message}");
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
        //        throw;
        //    }
        //    finally
        //    {
        //        _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Service");
        //    }
        //}



    }
}
