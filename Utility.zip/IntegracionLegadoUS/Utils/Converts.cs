﻿using GSAInterfaceWS;
using ReyBanPac.IntegracionLegadoUS.Controllers.Dto;
using ReyBanPac.ModeloCanonico.Type;
using System.Text;

namespace ReyBanPac.IntegracionLegadoUS.Utils
{
    public static class Converts
    {
        public static string Base64Decode(string base64EncodedData)
        {
            byte[] bytes = Convert.FromBase64String(base64EncodedData);
            return Encoding.UTF8.GetString(bytes);
        }


        public static PermisoMenuType ConvertLegadoToType(PerfilProgramasBean Lista)
        {
            PermisoMenuType Type = new PermisoMenuType()
            {
                Codigo = Lista.scg_prg_objeto,
                Consulta = Lista.scg_acc_consultar.Value,
                Eliminar = Lista.scg_acc_anular.Value,
                Exportar = Lista.scg_acc_imprimir.Value,
                Modificar = Lista.scg_acc_modificar.Value,
                Nombre = Lista.scg_prg_descripcion,
                Nuevo = Lista.scg_acc_nuevo.Value,
                Procesar = Lista.scg_acc_procesar.Value,
                Visualizar = Lista.scg_acc_consultar.Value,
            };


            return Type;
        }

        public static List<PermisoMenuType> ConvertLegadoToType(List<PerfilProgramasBean> Lista)
        {

            List<PermisoMenuType> ListaPerfiles = new List<PermisoMenuType>();

            foreach (var perfil in Lista)
                ListaPerfiles.Add(ConvertLegadoToType(perfil));
            return ListaPerfiles;
        }


        public static PerfilProgramasBean ConvertLegadoToTypeMultiPerfil(List<PerfilProgramasBean> Lista)
        {

            PerfilProgramasBean ListaPerfiles = new PerfilProgramasBean();
            ListaPerfiles.scg_prg_objeto = Lista.First().scg_prg_objeto;
            ListaPerfiles.scg_prg_descripcion = Lista.First().scg_prg_descripcion;
            ListaPerfiles.scg_prg_path = Lista.First().scg_prg_path;
            ListaPerfiles.scg_prg_programa = Lista.First().scg_prg_programa;
            ListaPerfiles.message = Lista.First().message;
            ListaPerfiles.scg_prg_codigo = Lista.First().scg_prg_codigo;
            ListaPerfiles.scg_acc_consultar = Lista.Any(x => x.scg_acc_consultar == true);
            ListaPerfiles.scg_acc_anular = Lista.Any(x => x.scg_acc_anular == true);
            ListaPerfiles.scg_acc_imprimir = Lista.Any(x => x.scg_acc_imprimir == true);
            ListaPerfiles.scg_acc_modificar = Lista.Any(x => x.scg_acc_modificar == true);
            ListaPerfiles.scg_acc_nuevo = Lista.Any(x => x.scg_acc_nuevo == true);
            ListaPerfiles.scg_acc_procesar = Lista.Any(x => x.scg_acc_procesar == true);
            return ListaPerfiles;
        }

        public static PermisoMenuControlesType ConvertLegadoToType(GetPerfilDetControlesBean Lista)
        {
            PermisoMenuControlesType Type = new PermisoMenuControlesType()
            {
                Codigo = Lista.scg_prgcont_codigo_control,
                Modificar = Lista.scg_acc_prgcont_modificar.Value,
                Visualizar = Lista.scg_acc_prgcont_visualizar.Value,
                Habilitar = Lista.scg_acc_prgcont_habilitar.Value
            };


            return Type;
        }

        public static List<PermisoMenuControlesType> ConvertLegadoToListType(List<GetPerfilDetControlesBean> Lista)
        {

            List<PermisoMenuControlesType> ListaPerfiles = new List<PermisoMenuControlesType>();

            if (Lista != null)
            {
                Lista = Lista.OrderBy(x => x.scg_prgcont_codigo_control).ToList();
                foreach (var perfil in Lista)
                    ListaPerfiles.Add(ConvertLegadoToType(perfil));
            }
            return ListaPerfiles;
        }
    }
}
