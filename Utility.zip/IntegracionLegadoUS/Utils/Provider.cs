﻿using ReyBanPac.IntegracionLegadoUS.Constans;

namespace ReyBanPac.IntegracionLegadoUS.Utils
{
    public class Provider
    {
        public Constan Const { get; }
        public UrlService Api { get; }

        public readonly string HostApi;


        public Provider()
        {
            string? environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            string appconfig = string.IsNullOrEmpty(environment) ? "appsettings.json" : $"appsettings.{environment}.json";

            var builder = new ConfigurationBuilder()
                .AddJsonFile(appconfig, optional: true, reloadOnChange: true);
            var config = builder.Build();

            Api = config.GetSection("ApiUrls").Get<UrlService>();
            HostApi = config.GetSection("Parametros:HostApi").Get<string>();
            Const = config.GetSection("Parametros").Get<Constan>();
        }
    }
}
