using integracionlegadous.service.command;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.OpenApi.Models;
using ReyBanPac.transferenciaarchivous.service.command.business;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Controllers.Contract;
using ReyBanPac.TransferenciaArchivoUS.Controllers.Impl;
using ReyBanPac.TransferenciaArchivoUS.Service.Contract;
using ReyBanPac.TransferenciaArchivoUS.Service.Impl;
using ReyBanPac.TransferenciaArchivoUS.Utils;

var builder = WebApplication.CreateBuilder(args);

#region Cors

// Configurar la politica CORS con la configuracion cargada
builder.Services.AddCors(options =>
{
    options.AddPolicy("NUXT", builder =>
    {
        builder.AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader();
    });
});
#endregion
#region Logger File

var DirLogs = builder.Configuration.GetSection("Parametros:DirLogs").Value;
builder.Logging.AddFile($"{DirLogs}Logs_{General.Nombre_Servicio}{General.Tipo_Servicio}-{{Date}}.txt");

#endregion


// Add services to the container.
builder.Services.AddScoped<IController, ControllerImpl>();
builder.Services.AddScoped<IService, ServiceImpl>();
builder.Services.AddSingleton<Provider>();
builder.Services.AddTransient<InsertarArchivoConsentimientoCommand>();
builder.Services.AddTransient<InsertarArchivoSFTPCommand>();
builder.Services.AddTransient<ConsultarCredencialCommand>();
builder.Services.AddTransient<InsertarArchivoCompartidaCommand>();
builder.Services.AddTransient<EliminarArchivoCompartidaCommand>();
builder.Services.AddTransient<ConsultarRegistroConsentimientoCommand>();
builder.Services.AddTransient<RenombrarArchivoCommand>();
builder.Services.AddTransient<EliminarArchivoSFTPCommand>();





builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = General.Nombre_Servicio + "-" + General.Tipo_Servicio, Version = "v1" });
	
});

builder.Services.Configure<IISServerOptions>(options =>
{
    options.MaxRequestBodySize = builder.Configuration.GetValue<long>("Parametros:MaxFileSizeMB") * 1024 * 1024;
});

builder.Services.Configure<KestrelServerOptions>(options =>
{
    options.Limits.MaxRequestBodySize = builder.Configuration.GetValue<long>("Parametros:MaxFileSizeMB") * 1024 * 1024;
});

builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = builder.Configuration.GetValue<long>("Parametros:MaxFileSizeMB") * 1024 * 1024;
});

var app = builder.Build();

// Configure the HTTP request pipeline.


app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("v1/swagger.json", General.Nombre_Servicio + "-" + General.Tipo_Servicio + " v1");
});



app.UseCors("NUXT");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
