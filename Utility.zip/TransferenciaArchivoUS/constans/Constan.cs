﻿namespace ReyBanPac.transferenciaarchivous.constans
{
    public class Constan
    {

        public long MaxFileSizeMB { get; set; } = 0;
        public string SftpHost { get; set; } = string.Empty;
        public string SftPort { get; set; } = string.Empty;
        public string SftpDir { get; set; } = string.Empty;
        public string RemHost { get; set; } = string.Empty;
        public string RemDir { get; set; } = string.Empty;
        public string RemDom { get; set; } = string.Empty;
        public string COD_APP { get; set; } = string.Empty;
        public string COD_REC { get; set; } = string.Empty;
    }
}
