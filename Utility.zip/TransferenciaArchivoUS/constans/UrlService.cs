﻿namespace ReyBanPac.TransferenciaArchivoUS.Constans
{
    public class UrlService
    {
        public string CONSULTAR { get; set; } = string.Empty;
        public string CREAR_ARCHIVO { get; set; } = string.Empty;

        public string CONSULTAR_REGISTRO { get; set; } = string.Empty;
        

    }
}
