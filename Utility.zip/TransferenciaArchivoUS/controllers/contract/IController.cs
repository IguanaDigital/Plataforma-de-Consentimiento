﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.TransferenciaArchivoUS.controllers.dto;

namespace ReyBanPac.TransferenciaArchivoUS.Controllers.Contract
{
    public interface IController
    {
        //public Task<IActionResult> Upload(IFormFile file);
        public Task<ActionResult<Object>> Upload(List<IFormFile> file, int Id);

    }
}
