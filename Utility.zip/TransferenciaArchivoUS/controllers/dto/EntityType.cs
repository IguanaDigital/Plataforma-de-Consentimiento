﻿using System.Text.Json.Serialization;

namespace ReyBanPac.TransferenciaArchivoUS.controllers.dto
{
    public class EntityType
    {
        [JsonPropertyName("Usuario")]
        public string Usuario { get; set; }

        [JsonPropertyName("Clave")]
        public string Clave { get; set; }

        [JsonPropertyName("Identificador")]
        public string Identificador { get; set; }

        public EntityType()
        {
            Usuario = string.Empty;
            Clave = string.Empty;
            Identificador = string.Empty;
        }
    }
}
