﻿using System.Text.Json.Serialization;

namespace ReyBanPac.TransferenciaArchivoUS.controllers.dto
{
    public class RespuestaType
    {
        [JsonPropertyName("Token")]
        public string Token { get; set; }

        [JsonPropertyName("Permisos")]
        public List<PermisoDispositivoType> Permisos { get; set; }


        public RespuestaType()
        {
            Token = string.Empty;
            Permisos = new List<PermisoDispositivoType>();
        }

    }
    public class PermisoDispositivoType
    {

        [JsonPropertyName("Identificador")]
        public string Identificador { get; set; }

        [JsonPropertyName("Id_Hacienda")]
        public int Id_Hacienda { get; set; }

        [JsonPropertyName("Id_Dispositivo")]
        public int Id_Dispositivo { get; set; }

        [JsonPropertyName("Id_Encuesta")]
        public int Id_Encuesta { get; set; }

        [JsonPropertyName("Fecha_Inicio")]
        public DateTime Fecha_Inicio { get; set; }

        [JsonPropertyName("Fecha_Final")]
        public DateTime Fecha_Final { get; set; }

        [JsonPropertyName("Estado")]
        public string Estado { get; set; }

        public PermisoDispositivoType()
        {

            Identificador = string.Empty;
            Estado = string.Empty;
        }
    }


}
