﻿using Microsoft.AspNetCore.Mvc;

using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Controllers.Contract;
using ReyBanPac.TransferenciaArchivoUS.controllers.dto;
using ReyBanPac.TransferenciaArchivoUS.Service.Contract;
using ReyBanPac.TransferenciaArchivoUS.Utils;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.TransferenciaArchivoUS.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService Svc;
        private readonly IConfiguration _config;


        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger, IConfiguration config)
        {
            Svc = Servicio;
            _logger = logger;
            _config = config;
        }

        [HttpPost("upload/{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.FILE)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> Upload(List<IFormFile> file, int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Controller", General.Nombre_Servicio);


            try
            {
                await Svc.Upload(file, Id);
                return Ok("Archivo subido con éxito.");

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje: {Message}", General.Nombre_Servicio, ex.Message);
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Controller", General.Nombre_Servicio);
            }
        }

    }
}
