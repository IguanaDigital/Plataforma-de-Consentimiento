﻿using integracionlegadous.service.command;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Utils;


namespace ReyBanPac.transferenciaarchivous.service.command.business
{
    public class RenombrarArchivoCommand
    {
        private readonly ILogger<RenombrarArchivoCommand> _logger;
        private readonly Provider Provider;
        public RenombrarArchivoCommand(Provider _provider, ILogger<RenombrarArchivoCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public  string Execute(string FileName, RegistroConsentimientoHaciendaType Registro)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Command", General.Nombre_Servicio);
            try
            {
                //Obtenemos el tipo de Archivo
                var TipoArchivo = FileName.Split("._")[1];

                return $"{Registro.Id_Haciendad}_{Registro.Id_Persona}_{Registro.Id_Encuesta}_{Registro.Fecha.ToString("yyyyMMdd")}_{TipoArchivo}";

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Command", General.Nombre_Servicio);
            }
        }
    }
}
