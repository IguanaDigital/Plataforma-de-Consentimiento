﻿
using System.Text;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Utils;

namespace integracionlegadous.service.command
{
    public class ConsultarCredencialCommand
    {
        private readonly ILogger<ConsultarCredencialCommand> _logger;
        private readonly Provider Provider;
        public ConsultarCredencialCommand(Provider _provider, ILogger<ConsultarCredencialCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync()
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Command", General.Nombre_Servicio);
            try
            {
                using (var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient()))
                {
                    var Url = string.Concat(Provider.HostApi, Provider.Api.CONSULTAR.Replace("{COD_APP}",Provider.Const.COD_APP).Replace("{COD_REC}",Provider.Const.COD_REC));

                    var Response = await client.GetAsync(Url);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Servicio no disponible", General.Nombre_Servicio);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Command", General.Nombre_Servicio);
            }
        }
    }
}
