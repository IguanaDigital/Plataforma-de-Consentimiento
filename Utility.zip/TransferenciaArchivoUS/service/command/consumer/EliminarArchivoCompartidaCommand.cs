﻿
using System.Text;
using Microsoft.Extensions.Hosting;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Utils;
using Renci.SshNet;
using Renci.SshNet.Async;
using Renci.SshNet.Sftp;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using Microsoft.Win32.SafeHandles;
using SimpleImpersonation;
using System.Security.Principal;

namespace integracionlegadous.service.command
{
    public class EliminarArchivoCompartidaCommand
    {
        private readonly ILogger<EliminarArchivoCompartidaCommand> _logger;
        private readonly Provider Provider;
        public EliminarArchivoCompartidaCommand(Provider _provider, ILogger<EliminarArchivoCompartidaCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string localFilePath, CredencialType sftpCredencial)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Command", General.Nombre_Servicio);
            try
            {

                string fileName = Path.GetFileName(localFilePath);

                string remotePath = @$"\\{Provider.Const.RemHost}\{Provider.Const.RemDir}\";
                var credentials = new UserCredentials(Provider.Const.RemDom, sftpCredencial.User, Utils.Base64Decode(sftpCredencial.Pass));
                using SafeAccessTokenHandle userHandle = credentials.LogonUser(LogonType.Interactive);  // or another LogonType


                string remoteFilePath = $"{remotePath}{fileName}";


                WindowsIdentity.RunImpersonated(userHandle, () =>
                {
                    File.Delete(remoteFilePath);
                    _logger.LogInformation($"Archivo {fileName} eliminado exitosamente en {remotePath}.");
                });

                return $"Archivo {fileName} eliminado exitosamente en {remotePath}.";

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;

            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Command", General.Nombre_Servicio);
            }
        }

        // Función para verificar si un archivo existe en el servidor remoto
        static bool FileExists(SshClient client, string filePath)
        {
            using (var sshCommand = client.CreateCommand($"test -e {filePath}"))
            {
                sshCommand.Execute();
                return string.IsNullOrEmpty(sshCommand.Error);
            }
        }

        // Función para verificar si un directorio existe en el servidor remoto
        static bool DirectoryExists(SshClient client, string directoryPath)
        {
            using (var sshCommand = client.CreateCommand($"test -d {directoryPath}"))
            {
                sshCommand.Execute();
                return string.IsNullOrEmpty(sshCommand.Error);
            }
        }
    }
}
