﻿
using System.Text;
using Microsoft.Extensions.Hosting;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Utils;
using Renci.SshNet;
using Renci.SshNet.Async;
using Renci.SshNet.Sftp;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace integracionlegadous.service.command
{
    public class EliminarArchivoSFTPCommand
    {
        private readonly ILogger<EliminarArchivoSFTPCommand> _logger;
        private readonly Provider Provider;
        public EliminarArchivoSFTPCommand(Provider _provider, ILogger<EliminarArchivoSFTPCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string fileName, CredencialType sftpCredencial)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Command", General.Nombre_Servicio);
            try
            {

                using (var client = new SftpClient(Provider.Const.SftpHost, int.Parse(Provider.Const.SftPort), sftpCredencial.User, Utils.Base64Decode(sftpCredencial.Pass)))
                {
                    client.Connect();

                    if (!client.IsConnected)
                    {
                        _logger.LogError("No se pudo establecer la conexión SSH.");
                        throw new ServiceException("Error al establecer la conexión SSH.") { Codigo = StatusCodes.Status400BadRequest };
                    }

                    if (!client.Exists(Provider.Const.SftpDir))
                    {
                        _logger.LogError($"El directorio remoto {Provider.Const.SftpDir} no existe.");
                        throw new ServiceException($"El directorio remoto {Provider.Const.SftpDir} no existe.") { Codigo = StatusCodes.Status400BadRequest };
                    }

                    string remoteFilePath = $"{Provider.Const.SftpDir}/{fileName}";

                    // Verificar la existencia del archivo en el servidor SFTP
                    if (client.Exists(remoteFilePath))
                    {
                        // Eliminar el archivo si existe
                        client.DeleteFile(remoteFilePath);
                        _logger.LogInformation($"Archivo {fileName} eliminado exitosamente del servidor SFTP.");
                        return $"Archivo {fileName} eliminado exitosamente del servidor SFTP.";
                    }
                    else
                    {
                        _logger.LogInformation($"El archivo {fileName} no existe en el servidor SFTP.");
                        return $"El archivo {fileName} no existe en el servidor SFTP.";
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;

            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Command", General.Nombre_Servicio);
            }
        }
    }
}
