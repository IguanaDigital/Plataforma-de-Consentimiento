﻿
using System.Text;
using Microsoft.Extensions.Hosting;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Utils;
using Renci.SshNet;
using Renci.SshNet.Async;
using Renci.SshNet.Sftp;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;
using System;
using System.IO;
using System.Net;
using System.Diagnostics;
using SimpleImpersonation;
using Microsoft.Win32.SafeHandles;
using System.Security.Principal;
using System.Runtime.InteropServices;

namespace integracionlegadous.service.command
{
    public class InsertarArchivoCompartidaCommand
    {
        private readonly ILogger<InsertarArchivoCompartidaCommand> _logger;
        private readonly Provider Provider;
        public InsertarArchivoCompartidaCommand(Provider _provider, ILogger<InsertarArchivoCompartidaCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }



        public async Task<string> ExecuteAsync(string localFilePath, CredencialType sftpCredencial)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Command", General.Nombre_Servicio);
            try
            {

                string fileName = Path.GetFileName(localFilePath);

                string remotePath = @$"\\{Provider.Const.RemHost}\{Provider.Const.RemDir}\";
                var credentials = new UserCredentials(Provider.Const.RemDom, sftpCredencial.User,Utils.Base64Decode(sftpCredencial.Pass));
                using SafeAccessTokenHandle userHandle = credentials.LogonUser(LogonType.Interactive);  // or another LogonType


                string remoteFilePath = $"{remotePath}{fileName}";

                

                WindowsIdentity.RunImpersonated(userHandle, () =>
                {
                    File.Copy(localFilePath, remoteFilePath,true);
                    _logger.LogInformation($"Archivo {fileName} subido exitosamente a {remotePath}.");
                });

                return $"Archivo {fileName} subido exitosamente a {remotePath}.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Command", General.Nombre_Servicio);
            }
        }

    }
}
