﻿
using System.Text;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Utils;

namespace integracionlegadous.service.command
{
    public class InsertarArchivoConsentimientoCommand
    {
        private readonly ILogger<InsertarArchivoConsentimientoCommand> _logger;
        private readonly Provider Provider;
        public InsertarArchivoConsentimientoCommand(Provider _provider, ILogger<InsertarArchivoConsentimientoCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string Parametro)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Command", General.Nombre_Servicio);
            try
            {

                using (var client = new HttpClient(ReyBanPac.ModeloCanonico.Utils.Utils.OffSSLClient()))
                {
                    var Content = new StringContent(Parametro, Encoding.UTF8, "application/json");
                    var Url = string.Concat(Provider.HostApi, Provider.Api.CREAR_ARCHIVO);

                    var Response = await client.PostAsync(Url, Content);

                    Response.EnsureSuccessStatusCode();

                    return await Response.Content.ReadAsStringAsync();

                }

            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Servicio no disponible", General.Nombre_Servicio);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Command", General.Nombre_Servicio);
            }
        }
    }
}
