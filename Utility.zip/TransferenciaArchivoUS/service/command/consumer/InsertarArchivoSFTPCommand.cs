﻿
using System.Text;
using Microsoft.Extensions.Hosting;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.Utils;
using Renci.SshNet;
using Renci.SshNet.Async;
using Renci.SshNet.Sftp;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace integracionlegadous.service.command
{
    public class InsertarArchivoSFTPCommand
    {
        private readonly ILogger<InsertarArchivoSFTPCommand> _logger;
        private readonly Provider Provider;
        public InsertarArchivoSFTPCommand(Provider _provider, ILogger<InsertarArchivoSFTPCommand> logger)
        {
            _logger = logger;
            Provider = _provider;
        }

        public async Task<string> ExecuteAsync(string localFilePath, CredencialType sftpCredencial)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Command", General.Nombre_Servicio);
            try
            {

                using (var client = new SftpClient(Provider.Const.SftpHost, int.Parse(Provider.Const.SftPort), sftpCredencial.User, Utils.Base64Decode(sftpCredencial.Pass)))
                {
                    client.Connect();

                    if (!client.IsConnected)
                    {
                        _logger.LogError("No se pudo establecer la conexión SSH.");
                        throw new ServiceException("Error al establecer la conexión SSH.") { Codigo = StatusCodes.Status400BadRequest };
                    }

                    if (!client.Exists(Provider.Const.SftpDir))
                    {
                        _logger.LogError($"El directorio remoto {Provider.Const.SftpDir} no existe.");
                        throw new ServiceException($"El directorio remoto {Provider.Const.SftpDir} no existe.") { Codigo = StatusCodes.Status400BadRequest };
                    }

                    string fileName = Path.GetFileName(localFilePath);
                    string remoteFilePath = $"{Provider.Const.SftpDir}/{fileName}";

                    using (var fileStream = new FileStream(localFilePath, FileMode.Open))
                    {
                        await client.UploadAsync(fileStream, remoteFilePath);
                    }

                    _logger.LogInformation($"Archivo {fileName} subido exitosamente a {Provider.Const.SftpDir}.");
                    return $"Archivo {fileName} subido exitosamente a {Provider.Const.SftpDir}.";
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Command", General.Nombre_Servicio);
            }
        }
    }
}
