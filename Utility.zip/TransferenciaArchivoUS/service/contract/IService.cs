﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.TransferenciaArchivoUS.controllers.dto;

namespace ReyBanPac.TransferenciaArchivoUS.Service.Contract
{
    public interface IService
    {
        public Task<string> Upload(List<IFormFile> sFiles, int Id);

    }
}
