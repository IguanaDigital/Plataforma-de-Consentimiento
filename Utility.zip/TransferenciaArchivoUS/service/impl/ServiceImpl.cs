﻿using integracionlegadous.service.command;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using System.Text.Json;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.TransferenciaArchivoUS.Constans;
using ReyBanPac.TransferenciaArchivoUS.controllers.dto;
using ReyBanPac.TransferenciaArchivoUS.Service.Contract;
using ReyBanPac.TransferenciaArchivoUS.Utils;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.transferenciaarchivous.service.command.business;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.TransferenciaArchivoUS.Service.Impl
{
    public class ServiceImpl : IService
    {
        private readonly ILogger<ServiceImpl> _logger;
        private readonly Provider Provider;

        private readonly InsertarArchivoConsentimientoCommand _insertarArchivoConsentimientoCommand;
        //private readonly InsertarArchivoSFTPCommand _insertarArchivosSFTPCommand;
        private readonly ConsultarCredencialCommand _consultarCredencialCommand;
        private readonly ConsultarRegistroConsentimientoCommand _consultarRegistroConsentimientoCommand;
        private readonly RenombrarArchivoCommand _renombrarArchivoCommand;
        //private readonly EliminarArchivoSFTPCommand _eliminarArchivoSftpCommand;
        private readonly InsertarArchivoCompartidaCommand _insertarArchivoCompartidaCommand;
        private readonly EliminarArchivoCompartidaCommand _eliminarArchivoCompartidaCommand;

        public ServiceImpl(ILogger<ServiceImpl> logger,
                            Provider _provider,
                            InsertarArchivoConsentimientoCommand insertarArchivoConsentimientoCommand,
                            //InsertarArchivoSFTPCommand insertarArchivoSftpCommand,
                            ConsultarCredencialCommand consultarCredencialCommand,
                            ConsultarRegistroConsentimientoCommand consultarRegistroConsentimientoCommand,
                            RenombrarArchivoCommand renombrarArchivoCommand,
                            //EliminarArchivoSFTPCommand eliminarArchivoSftpCommand,
                            InsertarArchivoCompartidaCommand insertarArchivoCompartidaCommand,
                            EliminarArchivoCompartidaCommand eliminarArchivoCompartidaCommand)
        {
            _logger = logger;
            Provider = _provider;
            _insertarArchivoConsentimientoCommand = insertarArchivoConsentimientoCommand;
            //_insertarArchivosSFTPCommand = insertarArchivoSftpCommand;
            _consultarCredencialCommand = consultarCredencialCommand;
            _consultarRegistroConsentimientoCommand = consultarRegistroConsentimientoCommand;
            _renombrarArchivoCommand = renombrarArchivoCommand;
            //_eliminarArchivoSftpCommand = eliminarArchivoSftpCommand;
            _insertarArchivoCompartidaCommand = insertarArchivoCompartidaCommand;
            _eliminarArchivoCompartidaCommand = eliminarArchivoCompartidaCommand;
        }

        public async Task<string> Upload(List<IFormFile> sFiles, int Id)
        {
            _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Inicio Service", General.Nombre_Servicio);
            string resultado = string.Empty;
            try
            {
                #region Validar Carga Archivos

                if (sFiles == null || sFiles.Count == 0)
                {
                    throw new ServiceException("No se ha proporcionado ningún archivo") { Codigo = StatusCodes.Status400BadRequest };
                }

                if (sFiles.Count != 2)
                {
                    throw new ServiceException("Solo se permite subir dos archivos") { Codigo = StatusCodes.Status400BadRequest };
                }
                #endregion

                #region Consultar Consentimiento

                RegistroConsentimientoHaciendaType Registro = new RegistroConsentimientoHaciendaType();
                try
                {
                    //Consumir servicio para subir archivo
                    var Json = await _consultarRegistroConsentimientoCommand.ExecuteAsync(Id.ToString());

                    //Mapping
                    Registro = JsonSerializer.Deserialize<RegistroConsentimientoHaciendaType>(Json) ?? new RegistroConsentimientoHaciendaType();

                    if (Registro.Id == 0)
                        throw new ServiceException($"No se pudo obtener el registro de consentimineto") { Codigo = StatusCodes.Status400BadRequest };

                }
                catch (ServiceException ex)
                {
                    _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  {Message}", General.Nombre_Servicio, ex.Message);
                    throw;
                }

                #endregion

                foreach (var file in sFiles)
                {
                    CredencialType sftpCredencial = new CredencialType();
                    string FileReName = String.Empty;
                    string filePath = String.Empty;
                    try
                    {
                        #region Validar Archivos


                        if (file == null || file.Length == 0)
                        {
                            throw new ServiceException("No se ha proporcionado ningún archivo o el archivo está vacío.")
                            { Codigo = StatusCodes.Status400BadRequest };
                        }


                        if (file.Length > (Provider.Const.MaxFileSizeMB * 1024 * 1024))
                        {
                            throw new ServiceException(
                                    $"El archivo excede el tamaño máximo permitido de {Provider.Const.MaxFileSizeMB} MB.")
                            { Codigo = StatusCodes.Status400BadRequest };
                        }

                        #endregion

                        #region Renombrar Archivo
                        FileReName = file.FileName;

                        try
                        {
                            FileReName = _renombrarArchivoCommand.Execute(file.FileName, Registro);
                        }
                        catch (ServiceException ex)
                        {
                            _logger.LogError(ex,
                                "Servicio: {Nombre_Servicio} Mensaje:  {Message}",
                                General.Nombre_Servicio,

                                ex.Message);
                            throw;
                        }

                        #endregion

                        #region Cargar Archivo al Servidor Local

                        var directoryPath = Path.Combine(Directory.GetCurrentDirectory(), "uploads");
                        filePath = Path.Combine(Directory.GetCurrentDirectory(), "uploads", FileReName);

                        // Verificar si el directorio "uploads" existe; si no, créalo.
                        if (!Directory.Exists(directoryPath))
                        {
                            Directory.CreateDirectory(directoryPath);
                        }

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                             file.CopyTo(stream);
                        }

                        #endregion

                        #region Consultar Credencial

                        try
                        {
                            //Consumir servicio para subir archivo
                            var Json = await _consultarCredencialCommand.ExecuteAsync();

                            //Mapping
                            sftpCredencial = JsonSerializer.Deserialize<CredencialType>(Json) ?? new CredencialType();

                            if (string.IsNullOrEmpty(sftpCredencial.Pass))
                                throw new ServiceException($"No se pudo obtener la credencial del SFTP")
                                { Codigo = StatusCodes.Status400BadRequest };

                        }
                        catch (ServiceException ex)
                        {
                            _logger.LogError(ex,
                                "Servicio: {Nombre_Servicio} Mensaje:  {Message}",
                                General.Nombre_Servicio,

                                ex.Message);
                            throw;
                        }

                        #endregion

                        #region Insertar Archivos SFTP

                        //try
                        //{
                        //    //Consumir servicio para subir archivo
                        //    await _insertarArchivosSFTPCommand.ExecuteAsync(filePath, sftpCredencial);

                        //}
                        //catch (ServiceException ex)
                        //{
                        //    _logger.LogError(ex,
                        //        "Servicio: {Nombre_Servicio} Mensaje:  {Message}",
                        //        General.Nombre_Servicio,
                        //        
                        //        ex.Message);
                        //    throw;
                        //}

                        #endregion

                        #region Insertar Archivos Compartida

                        try
                        {
                            //Consumir servicio para subir archivo
                            resultado= await _insertarArchivoCompartidaCommand.ExecuteAsync(filePath, sftpCredencial);

                        }
                        catch (ServiceException ex)
                        {
                            _logger.LogError(ex,
                                "Servicio: {Nombre_Servicio} Mensaje:  {Message}",
                                General.Nombre_Servicio,
                                ex.Message);
                            throw;
                        }

                        #endregion

                        #region Insertar Archivos


                        try
                        {
                            string remotePath = @$"\\{Provider.Const.RemHost}\{Provider.Const.RemDir}\";

                            ArchivoConsentimientoType Archivo = new ArchivoConsentimientoType()
                            {
                                Id_Consentimiento = Id,
                                Dir_Archivo = @$"{remotePath}{FileReName}",
                                Estado = Estados.ACTIVO,
                                Fecha_Transferencia = DateTime.Now,
                                Nombre_Archivo = FileReName,
                                MD5 = ""
                            };


                            //Consumir servicio para obtener la informacion
                            await _insertarArchivoConsentimientoCommand.ExecuteAsync(JsonSerializer.Serialize(Archivo));

                        }
                        catch (ServiceException ex)
                        {
                            _logger.LogError(ex,
                                "Servicio: {Nombre_Servicio} Mensaje:  {Message}",
                                General.Nombre_Servicio,

                                ex.Message);

                            throw;
                        }


                        #endregion
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  {Message}", General.Nombre_Servicio, ex.Message);

                        #region Eliminar Archivo SFTP

                        //try
                        //{
                        //    try
                        //    {
                        //        //Consumir servicio para eliminar archivo
                        //        await _eliminarArchivoSftpCommand.ExecuteAsync(FileReName, sftpCredencial);

                        //    }
                        //    catch (ServiceException ex1)
                        //    {
                        //        _logger.LogError(ex1,
                        //            "Servicio: {Nombre_Servicio} Mensaje:  {Message}",
                        //            General.Nombre_Servicio,

                        //            ex1.Message);
                        //    }
                        //}
                        //catch (Exception ex1)
                        //{
                        //    _logger.LogError(ex1, "Servicio: {Nombre_Servicio} Mensaje:  {Message}", General.Nombre_Servicio,  ex1.Message);
                        //}

                        #endregion

                        #region Eliminar Archivo Compartida

                        try
                        {
                            try
                            {
                                //Consumir servicio para eliminar archivo
                                await _eliminarArchivoCompartidaCommand.ExecuteAsync(filePath, sftpCredencial);

                            }
                            catch (ServiceException ex1)
                            {
                                _logger.LogError(ex1,
                                    "Servicio: {Nombre_Servicio} Mensaje:  {Message}",
                                    General.Nombre_Servicio,

                                    ex1.Message);
                            }
                        }
                        catch (Exception ex1)
                        {
                            _logger.LogError(ex1, "Servicio: {Nombre_Servicio} Mensaje:  {Message}", General.Nombre_Servicio, ex1.Message);
                        }

                        #endregion

                        throw;
                    }
                    finally
                    {
                        #region Eliminar Archivo Local

                        try
                        {
                            if (Directory.Exists(filePath))
                            {
                                Directory.Delete(filePath);
                                _logger.LogInformation($"El archivo {filePath} fueron eliminados con éxito.");
                            }
                            else
                            {
                                _logger.LogInformation($"El directorio {filePath} no existe.");
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  {Message}", General.Nombre_Servicio, ex.Message);
                        }

                        #endregion
                    }


                }

                return resultado;

            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje: {Message}", General.Nombre_Servicio, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Servicio: {Nombre_Servicio} Mensaje:  Error Interno del Servidor", General.Nombre_Servicio);
                throw;
            }
            finally
            {
                _logger.LogInformation("Servicio: {Nombre_Servicio} Mensaje: Fin Service", General.Nombre_Servicio);
            }
        }


    }
}
