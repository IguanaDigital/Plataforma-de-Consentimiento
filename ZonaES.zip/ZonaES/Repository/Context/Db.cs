﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ZonaES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<ZonaModel> Models => Set<ZonaModel>();
        public DbSet<EmpleadoHaciendaModel> EmpleadoHaciendaModel => Set<EmpleadoHaciendaModel>();
        public DbSet<HaciendaModel> HaciendaModel => Set<HaciendaModel>();
        public DbSet<PermisoDispositivoModel> PermisoDispositivoModel => Set<PermisoDispositivoModel>();
        public DbSet<EncuestaModel> EncuestaModel => Set<EncuestaModel>();
    }
}
