﻿using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ZonaES.Service.Contract
{
    public interface IService
    {
        public Task<List<ZonaType>> Consultar();

        public Task<List<ZonaType>> ConsultarPorEncuestaId(int Id_Encuesta);

        public Task<ZonaType> ConsultarPorId(string Id);

    }
}
