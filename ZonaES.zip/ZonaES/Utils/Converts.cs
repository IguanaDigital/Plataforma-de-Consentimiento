﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ZonaES.Utils
{
    public static class Converts
    {
        public static ZonaType ConvertirModelAType(ZonaModel Model)
        {
            ZonaType EntityType = new ZonaType();

            if (Model != null)
            {
                EntityType.Id = Model.Id;
                EntityType.Nombre = Model.Nombre;
                EntityType.Ubicacion = Model.Ubicacion;
                EntityType.Estado = Model.Estado;
            }

            return EntityType;
        }

        public static ZonaModel ConvertirTypeAModel(ZonaType EntityType)
        {
            ZonaModel Model = new ZonaModel();
            if (EntityType != null)
            {
                Model.Id = EntityType.Id;
                Model.Nombre = EntityType.Nombre;
                Model.Ubicacion = EntityType.Ubicacion;
                Model.Estado = EntityType.Estado;
            }

            return Model;
        }

        public static List<ZonaType> ConvertirListModelToListType(List<ZonaModel> ListadoModel)
        {
            List<ZonaType> ListadoType = new List<ZonaType>();
            if (ListadoModel != null)
            {
                foreach (ZonaModel Item in ListadoModel)
                {
                    ListadoType.Add(ConvertirModelAType(Item));
                }
            }
            return ListadoType;
        }
    }
}
